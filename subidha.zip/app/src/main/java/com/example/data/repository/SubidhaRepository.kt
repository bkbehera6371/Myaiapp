package com.example.data.repository

import com.example.data.dao.SubidhaDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class MemberFinancialSummary(
    val memberId: String,
    val totalSavingsDeposited: Double,
    val totalSavingsWithdrawn: Double,
    val currentSavingsBalance: Double,
    val totalMonthlyFeesPaid: Double,
    val totalLateFinesPaid: Double,
    val totalLoansTaken: Double,
    val totalPrincipalRepaid: Double,
    val totalInterestPaid: Double,
    val totalOverdueInterestPaid: Double,
    val outstandingLoan: Double,
    val totalInterestDistributionReceived: Double,
    val additionalSharesCount: Int,
    val additionalSharesValue: Double,
    val pendingDuesCount: Int
)

data class ExitSettlementSummary(
    val memberId: String,
    val memberName: String,
    val joiningDate: Long,
    val isTwoYearCompleted: Boolean,
    val savingsRefundable: Double,
    val outstandingLoanPrincipal: Double,
    val outstandingInterest: Double,
    val outstandingFeesAndFines: Double,
    val netSettlementPayable: Double,
    val nonRefundableMembershipFee: Double = 500.0,
    val nonRefundableMonthlyFees: Double,
    val eligibleForInterestPool: Boolean
)

data class SocietyDashboardSummary(
    val totalMembers: Int,
    val activeMembers: Int,
    val membersCompletedTwoYears: Int,
    val membersPendingTwoYears: Int,
    val totalSavings: Double,
    val totalLoanDisbursed: Double,
    val totalOutstandingLoan: Double,
    val thisMonthMemberFeeCollection: Double,
    val thisMonthSavingsCollection: Double,
    val thisMonthLoanCollection: Double,
    val thisMonthInterestCollection: Double,
    val pendingPaymentsAmount: Double,
    val overdueLoansCount: Int,
    val totalInterestPool: Double
)

class SubidhaRepository(private val dao: SubidhaDao) {

    // --- Users & Auth ---
    suspend fun getUserByUsername(username: String): UserEntity? = dao.getUserByUsername(username)
    suspend fun getUserByMobile(mobile: String): UserEntity? = dao.getUserByMobile(mobile)
    fun getAllUsers(): Flow<List<UserEntity>> = dao.getAllUsersFlow()
    suspend fun insertUser(user: UserEntity) = dao.insertUser(user)

    // --- Members ---
    fun getAllMembers(): Flow<List<MemberEntity>> = dao.getAllMembersFlow()
    fun getMemberByIdFlow(id: String): Flow<MemberEntity?> = dao.getMemberByIdFlow(id)
    suspend fun getMemberById(id: String): MemberEntity? = dao.getMemberById(id)
    suspend fun updateMember(member: MemberEntity) = dao.updateMember(member)

    suspend fun registerMember(
        fullName: String,
        guardianName: String,
        dob: String,
        gender: String,
        mobileNumber: String,
        whatsappNumber: String,
        address: String,
        nomineeName: String,
        nomineeRelation: String,
        nomineeMobile: String,
        nomineeAge: Int,
        paymentMode: String = "CASH",
        createdBy: String = "Admin"
    ): MemberEntity {
        val existing = dao.getAllMembersFlow().first()
        val nextSeq = existing.size + 1
        val memberId = String.format(Locale.getDefault(), "SUB-%03d", nextSeq)
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val membershipNumber = String.format(Locale.getDefault(), "MEM-%d-%03d", currentYear, nextSeq)

        val joiningDate = System.currentTimeMillis()
        // 2-Year completion date: precisely 2 years from joining
        val cal = Calendar.getInstance()
        cal.timeInMillis = joiningDate
        cal.add(Calendar.YEAR, 2)
        val twoYearCompletionDate = cal.timeInMillis

        val member = MemberEntity(
            id = memberId,
            membershipNumber = membershipNumber,
            fullName = fullName.trim(),
            guardianName = guardianName.trim(),
            dob = dob,
            gender = gender,
            mobileNumber = mobileNumber.trim(),
            whatsappNumber = whatsappNumber.trim().ifEmpty { mobileNumber.trim() },
            address = address.trim(),
            nomineeName = nomineeName.trim(),
            nomineeRelation = nomineeRelation.trim(),
            nomineeMobile = nomineeMobile.trim(),
            nomineeAge = nomineeAge,
            joiningDate = joiningDate,
            accountStatus = "ACTIVE",
            twoYearCompletionDate = twoYearCompletionDate,
            additionalShareCount = 0,
            isTwoYearCompleted = false
        )
        dao.insertMember(member)

        // Transaction for ₹500 One-Time Membership Fee
        val txnId = "TXN-REG-" + System.currentTimeMillis().toString().takeLast(6)
        val recNo = "REC-REG-" + System.currentTimeMillis().toString().takeLast(6)
        val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date(joiningDate))

        dao.insertTransaction(
            TransactionEntity(
                id = txnId,
                memberId = memberId,
                category = "MEMBERSHIP_FEE",
                amount = 500.0,
                type = "CREDIT",
                date = joiningDate,
                monthYear = monthYear,
                paymentMode = paymentMode,
                receiptNumber = recNo,
                remarks = "One-Time Society Membership Fee (₹500)",
                createdBy = createdBy
            )
        )

        // Generate automatic receipt
        dao.insertReceipt(
            ReceiptEntity(
                receiptNumber = recNo,
                memberId = memberId,
                memberName = fullName,
                date = joiningDate,
                monthYear = monthYear,
                transactionType = "One-Time Membership Fee",
                amount = 500.0,
                paymentMode = paymentMode,
                remarks = "Official Admission Receipt. Membership Number: $membershipNumber",
                transactionId = txnId
            )
        )

        // Audit Log
        dao.insertAuditLog(
            AuditLogEntity(
                user = createdBy,
                transactionId = txnId,
                action = "CREATE",
                newValue = memberId,
                reason = "New member registered: $fullName ($memberId)"
            )
        )

        return member
    }

    // --- Monthly Fees ---
    fun getFeesForMonth(monthYear: String): Flow<List<MonthlyFeeEntity>> = dao.getFeesForMonthFlow(monthYear)
    fun getFeesForMember(memberId: String): Flow<List<MonthlyFeeEntity>> = dao.getFeesForMemberFlow(memberId)

    suspend fun generateMonthlyDuesForActiveMembers(monthYear: String, user: String = "Admin"): Int {
        val members = dao.getAllMembersFlow().first().filter { it.accountStatus == "ACTIVE" }
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 10)
        val dueDate = cal.timeInMillis

        var generatedCount = 0
        for (member in members) {
            val existing = dao.getMonthlyFee(member.id, monthYear)
            if (existing == null) {
                dao.insertMonthlyFee(
                    MonthlyFeeEntity(
                        memberId = member.id,
                        monthYear = monthYear,
                        feeAmount = 200.0,
                        lateFine = 0.0,
                        status = "PENDING",
                        dueDate = dueDate
                    )
                )
                generatedCount++
            }
        }

        if (generatedCount > 0) {
            dao.insertAuditLog(
                AuditLogEntity(
                    user = user,
                    action = "CREATE",
                    reason = "Generated ₹200 monthly dues for $generatedCount members for $monthYear"
                )
            )
        }
        return generatedCount
    }

    suspend fun applyLateFines(monthYear: String, user: String = "Admin"): Int {
        val fees = dao.getFeesForMonthFlow(monthYear).first()
        var fineAppliedCount = 0

        for (fee in fees) {
            if (fee.status == "PENDING" && fee.lateFine == 0.0) {
                dao.updateMonthlyFee(
                    fee.copy(
                        lateFine = 20.0,
                        status = "OVERDUE"
                    )
                )
                fineAppliedCount++
            }
        }

        if (fineAppliedCount > 0) {
            dao.insertAuditLog(
                AuditLogEntity(
                    user = user,
                    action = "UPDATE",
                    reason = "Applied ₹20 late fine to $fineAppliedCount overdue members for $monthYear"
                )
            )
        }
        return fineAppliedCount
    }

    suspend fun payMonthlyMemberFee(
        feeId: Long,
        paymentMode: String = "CASH",
        remarks: String = "",
        user: String = "Admin"
    ): ReceiptEntity? {
        val fee = dao.getFeeById(feeId) ?: return null
        val member = dao.getMemberById(fee.memberId) ?: return null
        val now = System.currentTimeMillis()

        val txnIdFee = "TXN-MFEE-" + now.toString().takeLast(6)
        val recNo = "REC-MFEE-" + now.toString().takeLast(6)

        // 1. Transaction for ₹200 Monthly Member Fee
        dao.insertTransaction(
            TransactionEntity(
                id = txnIdFee,
                memberId = member.id,
                category = "MONTHLY_MEMBER_FEE",
                amount = fee.feeAmount,
                type = "CREDIT",
                date = now,
                monthYear = fee.monthYear,
                paymentMode = paymentMode,
                receiptNumber = recNo,
                remarks = "Monthly Member Fee for ${fee.monthYear}",
                createdBy = user
            )
        )

        // 2. If late fine > 0, separate transaction for ₹20 Late Fine
        var txnIdFine: String? = null
        if (fee.lateFine > 0.0) {
            txnIdFine = "TXN-FINE-" + (now + 1).toString().takeLast(6)
            dao.insertTransaction(
                TransactionEntity(
                    id = txnIdFine,
                    memberId = member.id,
                    category = "LATE_FINE",
                    amount = fee.lateFine,
                    type = "CREDIT",
                    date = now,
                    monthYear = fee.monthYear,
                    paymentMode = paymentMode,
                    receiptNumber = recNo,
                    remarks = "Late Fine for ${fee.monthYear}",
                    createdBy = user
                )
            )
        }

        // Update fee entity
        dao.updateMonthlyFee(
            fee.copy(
                status = "PAID",
                paidDate = now,
                receiptNumber = recNo,
                transactionId = txnIdFee
            )
        )

        val totalAmount = fee.feeAmount + fee.lateFine
        val receiptRemarks = if (fee.lateFine > 0) {
            "Member Fee: ₹${fee.feeAmount.toInt()} + Late Fine: ₹${fee.lateFine.toInt()}. $remarks".trim()
        } else {
            "Monthly Member Fee: ₹${fee.feeAmount.toInt()}. $remarks".trim()
        }

        val receipt = ReceiptEntity(
            receiptNumber = recNo,
            memberId = member.id,
            memberName = member.fullName,
            date = now,
            monthYear = fee.monthYear,
            transactionType = "Monthly Member Fee",
            amount = totalAmount,
            paymentMode = paymentMode,
            remarks = receiptRemarks,
            transactionId = txnIdFee
        )
        dao.insertReceipt(receipt)

        // Update Monthly Hisab
        updateMonthlyHisabForMember(member.id, fee.monthYear)

        return receipt
    }

    // --- Savings ---
    fun getSavingsForMember(memberId: String): Flow<List<SavingsTransactionEntity>> = dao.getSavingsForMemberFlow(memberId)
    fun getAllSavings(): Flow<List<SavingsTransactionEntity>> = dao.getAllSavingsFlow()

    suspend fun addSavingsTransaction(
        memberId: String,
        type: String, // "DEPOSIT", "WITHDRAWAL", "ADJUSTMENT"
        amount: Double,
        paymentMode: String = "CASH",
        remarks: String = "",
        user: String = "Admin"
    ): ReceiptEntity? {
        val member = dao.getMemberById(memberId) ?: return null
        val now = System.currentTimeMillis()
        val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date(now))
        val txnId = "TXN-SAV-" + now.toString().takeLast(6)
        val recNo = "REC-SAV-" + now.toString().takeLast(6)

        val savTxn = SavingsTransactionEntity(
            memberId = memberId,
            transactionId = txnId,
            type = type,
            amount = amount,
            date = now,
            monthYear = monthYear,
            paymentMode = paymentMode,
            receiptNumber = recNo,
            remarks = remarks,
            createdBy = user
        )
        dao.insertSavingsTransaction(savTxn)

        val category = if (type == "WITHDRAWAL") "SAVINGS_WITHDRAWAL" else "SAVINGS_DEPOSIT"
        val crDrType = if (type == "WITHDRAWAL") "DEBIT" else "CREDIT"

        dao.insertTransaction(
            TransactionEntity(
                id = txnId,
                memberId = memberId,
                category = category,
                amount = amount,
                type = crDrType,
                date = now,
                monthYear = monthYear,
                paymentMode = paymentMode,
                receiptNumber = recNo,
                remarks = "Savings $type: $remarks",
                createdBy = user
            )
        )

        val receipt = ReceiptEntity(
            receiptNumber = recNo,
            memberId = memberId,
            memberName = member.fullName,
            date = now,
            monthYear = monthYear,
            transactionType = "Savings $type",
            amount = amount,
            paymentMode = paymentMode,
            remarks = "Savings $type. $remarks",
            transactionId = txnId
        )
        dao.insertReceipt(receipt)

        updateMonthlyHisabForMember(memberId, monthYear)
        return receipt
    }

    // --- Additional Membership / Shares ---
    fun getAdditionalMembershipsForMember(memberId: String): Flow<List<AdditionalMembershipEntity>> =
        dao.getAdditionalMembershipsForMemberFlow(memberId)

    suspend fun buyAdditionalMembership(
        memberId: String,
        count: Int,
        pricePerMembership: Double = 500.0,
        paymentMode: String = "CASH",
        remarks: String = "",
        user: String = "Admin"
    ): ReceiptEntity? {
        val member = dao.getMemberById(memberId) ?: return null
        val now = System.currentTimeMillis()
        val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date(now))
        val totalValue = count * pricePerMembership

        val txnId = "TXN-SHR-" + now.toString().takeLast(6)
        val recNo = "REC-SHR-" + now.toString().takeLast(6)

        val item = AdditionalMembershipEntity(
            memberId = memberId,
            count = count,
            pricePerMembership = pricePerMembership,
            totalMembershipValue = totalValue,
            purchaseDate = now,
            receiptNumber = recNo,
            transactionId = txnId,
            remarks = remarks
        )
        dao.insertAdditionalMembership(item)

        // Update member's additional share count
        dao.updateMember(member.copy(additionalShareCount = member.additionalShareCount + count))

        // Ledger entry (Maintained separately from Savings and Monthly Fee!)
        dao.insertTransaction(
            TransactionEntity(
                id = txnId,
                memberId = memberId,
                category = "ADDITIONAL_MEMBERSHIP",
                amount = totalValue,
                type = "CREDIT",
                date = now,
                monthYear = monthYear,
                paymentMode = paymentMode,
                receiptNumber = recNo,
                remarks = "Purchased $count Additional Shares @ ₹$pricePerMembership each",
                createdBy = user
            )
        )

        val receipt = ReceiptEntity(
            receiptNumber = recNo,
            memberId = memberId,
            memberName = member.fullName,
            date = now,
            monthYear = monthYear,
            transactionType = "Additional Membership / Shares",
            amount = totalValue,
            paymentMode = paymentMode,
            remarks = "Purchased $count Additional Share(s). $remarks",
            transactionId = txnId
        )
        dao.insertReceipt(receipt)

        updateMonthlyHisabForMember(memberId, monthYear)
        return receipt
    }

    // --- Loans ---
    fun getAllLoans(): Flow<List<LoanEntity>> = dao.getAllLoansFlow()
    fun getLoansForMember(memberId: String): Flow<List<LoanEntity>> = dao.getLoansForMemberFlow(memberId)
    fun getEmisForLoan(loanId: String): Flow<List<LoanEmiEntity>> = dao.getEmisForLoanFlow(loanId)
    suspend fun getEmisForLoanList(loanId: String): List<LoanEmiEntity> = dao.getEmisForLoan(loanId)
    fun getLoanAgreement(loanId: String): Flow<LoanAgreementEntity?> = dao.getLoanAgreementFlow(loanId)

    suspend fun applyLoan(
        memberId: String,
        amount: Double = 5000.0,
        tenureMonths: Int = 12,
        interestRateMonthly: Double = 2.0,
        interestMethod: String = "REDUCING_BALANCE",
        user: String = "Admin"
    ): LoanEntity? {
        val member = dao.getMemberById(memberId) ?: return null
        val existingLoans = dao.getLoansForMemberFlow(memberId).first()
        val nextCycle = existingLoans.size + 1

        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val loanId = String.format(Locale.getDefault(), "LOAN-%d-%03d", currentYear, (existingLoans.size + 1))
        val now = System.currentTimeMillis()

        // Calculate standard EMI
        val principalPerMonth = amount / tenureMonths
        val initialInterest = amount * (interestRateMonthly / 100.0)
        val approxEmi = principalPerMonth + initialInterest

        val loan = LoanEntity(
            id = loanId,
            memberId = memberId,
            loanAmount = amount,
            loanDate = now,
            interestRateMonthly = interestRateMonthly,
            tenureMonths = tenureMonths,
            emiMonthly = approxEmi,
            status = "PENDING_SIGNATURE",
            interestCalculationMethod = interestMethod,
            cycleYear = nextCycle
        )
        dao.insertLoan(loan)

        // Create Agreement in PENDING status
        dao.insertLoanAgreement(
            LoanAgreementEntity(
                loanId = loanId,
                memberId = memberId,
                termsVersion = "v1.0",
                signatureStatus = "PENDING"
            )
        )

        // Pre-create 12-month EMI schedule
        val emis = mutableListOf<LoanEmiEntity>()
        var remainingPrincipal = amount
        val cal = Calendar.getInstance()
        cal.timeInMillis = now

        for (i in 1..tenureMonths) {
            cal.add(Calendar.MONTH, 1)
            cal.set(Calendar.DAY_OF_MONTH, 10)
            val emiDueDate = cal.timeInMillis

            val monthlyInterest = if (interestMethod == "REDUCING_BALANCE") {
                remainingPrincipal * (interestRateMonthly / 100.0)
            } else {
                amount * (interestRateMonthly / 100.0)
            }
            val totalEmi = principalPerMonth + monthlyInterest

            emis.add(
                LoanEmiEntity(
                    loanId = loanId,
                    memberId = memberId,
                    emiNumber = i,
                    dueDate = emiDueDate,
                    principalAmount = principalPerMonth,
                    normalInterest = monthlyInterest,
                    overdueInterest = 0.0,
                    totalEmi = totalEmi,
                    amountPaid = 0.0,
                    balance = totalEmi,
                    status = "PENDING"
                )
            )

            if (interestMethod == "REDUCING_BALANCE") {
                remainingPrincipal -= principalPerMonth
            }
        }
        dao.insertLoanEmis(emis)

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = loanId,
                action = "CREATE",
                reason = "Loan $loanId of ₹${amount.toInt()} applied for ${member.fullName} ($memberId). Awaiting digital agreement signature."
            )
        )

        return loan
    }

    suspend fun signLoanAgreementAndDisburse(
        loanId: String,
        signatureData: String,
        user: String = "Admin"
    ): Boolean {
        val loan = dao.getLoanById(loanId) ?: return false
        val member = dao.getMemberById(loan.memberId) ?: return false
        val now = System.currentTimeMillis()
        val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date(now))

        // 1. Sign agreement
        dao.insertLoanAgreement(
            LoanAgreementEntity(
                loanId = loanId,
                memberId = loan.memberId,
                termsVersion = "v1.0",
                signatureStatus = "SIGNED",
                signatureTimestamp = now,
                signatureData = signatureData
            )
        )

        // 2. Disburse loan
        dao.updateLoan(
            loan.copy(
                status = "ACTIVE",
                disbursementDate = now
            )
        )

        // 3. Central Transaction: LOAN_DISBURSEMENT (Debit)
        val txnId = "TXN-DISB-" + now.toString().takeLast(6)
        val recNo = "REC-DISB-" + now.toString().takeLast(6)

        dao.insertTransaction(
            TransactionEntity(
                id = txnId,
                memberId = loan.memberId,
                category = "LOAN_DISBURSEMENT",
                amount = loan.loanAmount,
                type = "DEBIT",
                date = now,
                monthYear = monthYear,
                paymentMode = "BANK_TRANSFER",
                receiptNumber = recNo,
                remarks = "Disbursed ₹${loan.loanAmount.toInt()} for Loan $loanId to ${member.fullName}",
                createdBy = user
            )
        )

        dao.insertReceipt(
            ReceiptEntity(
                receiptNumber = recNo,
                memberId = loan.memberId,
                memberName = member.fullName,
                date = now,
                monthYear = monthYear,
                transactionType = "Loan Disbursement",
                amount = loan.loanAmount,
                paymentMode = "BANK_TRANSFER",
                remarks = "Loan $loanId Disbursed. 12-Month EMI Schedule Activated.",
                transactionId = txnId
            )
        )

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = loanId,
                action = "DISBURSE",
                reason = "Loan agreement digitally signed by ${member.fullName}. Disbursed ₹${loan.loanAmount.toInt()}."
            )
        )

        updateMonthlyHisabForMember(loan.memberId, monthYear)
        return true
    }

    suspend fun payLoanEmi(
        emiId: Long,
        paymentMode: String = "CASH",
        remarks: String = "",
        user: String = "Admin"
    ): ReceiptEntity? {
        val emi = dao.getEmiById(emiId) ?: return null
        val loan = dao.getLoanById(emi.loanId) ?: return null
        val member = dao.getMemberById(emi.memberId) ?: return null
        val now = System.currentTimeMillis()
        val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date(now))

        val recNo = "REC-EMI-" + now.toString().takeLast(6)

        // 1. Separate transaction: PRINCIPAL_REPAYMENT
        val txnPrin = "TXN-PRIN-" + now.toString().takeLast(6)
        dao.insertTransaction(
            TransactionEntity(
                id = txnPrin,
                memberId = member.id,
                category = "PRINCIPAL_REPAYMENT",
                amount = emi.principalAmount,
                type = "CREDIT",
                date = now,
                monthYear = monthYear,
                paymentMode = paymentMode,
                receiptNumber = recNo,
                remarks = "Loan ${loan.id} EMI #${emi.emiNumber} Principal",
                createdBy = user
            )
        )

        // 2. Separate transaction: NORMAL_INTEREST (2% per month)
        val txnInt = "TXN-INT-" + (now + 1).toString().takeLast(6)
        dao.insertTransaction(
            TransactionEntity(
                id = txnInt,
                memberId = member.id,
                category = "NORMAL_INTEREST",
                amount = emi.normalInterest,
                type = "CREDIT",
                date = now,
                monthYear = monthYear,
                paymentMode = paymentMode,
                receiptNumber = recNo,
                remarks = "Loan ${loan.id} EMI #${emi.emiNumber} Normal Interest (2%)",
                createdBy = user
            )
        )

        // 3. If overdue interest exists (3% per month), separate transaction
        if (emi.overdueInterest > 0.0) {
            val txnOverdue = "TXN-ODINT-" + (now + 2).toString().takeLast(6)
            dao.insertTransaction(
                TransactionEntity(
                    id = txnOverdue,
                    memberId = member.id,
                    category = "OVERDUE_INTEREST",
                    amount = emi.overdueInterest,
                    type = "CREDIT",
                    date = now,
                    monthYear = monthYear,
                    paymentMode = paymentMode,
                    receiptNumber = recNo,
                    remarks = "Loan ${loan.id} EMI #${emi.emiNumber} Overdue Interest (3%)",
                    createdBy = user
                )
            )
        }

        // Update EMI entity
        val totalPaidForEmi = emi.principalAmount + emi.normalInterest + emi.overdueInterest
        dao.updateLoanEmi(
            emi.copy(
                status = "PAID",
                amountPaid = totalPaidForEmi,
                balance = 0.0,
                paidDate = now,
                receiptNumber = recNo,
                transactionId = txnPrin
            )
        )

        // Check if all EMIs for this loan are now paid
        val allLoanEmis = dao.getEmisForLoan(loan.id)
        val unPaidEmis = allLoanEmis.filter { it.id != emi.id && it.status != "PAID" }
        if (unPaidEmis.isEmpty()) {
            dao.updateLoan(
                loan.copy(
                    status = "CLOSED",
                    closedDate = now
                )
            )
        }

        val receipt = ReceiptEntity(
            receiptNumber = recNo,
            memberId = member.id,
            memberName = member.fullName,
            date = now,
            monthYear = monthYear,
            transactionType = "Loan EMI Repayment",
            amount = totalPaidForEmi,
            paymentMode = paymentMode,
            remarks = "Loan ${loan.id} EMI #${emi.emiNumber} (Principal: ₹${emi.principalAmount.toInt()}, Interest: ₹${emi.normalInterest.toInt()}${if (emi.overdueInterest > 0) ", Overdue Int: ₹${emi.overdueInterest.toInt()}" else ""}). $remarks".trim(),
            transactionId = txnPrin
        )
        dao.insertReceipt(receipt)

        updateMonthlyHisabForMember(member.id, monthYear)
        return receipt
    }

    // --- Financial Summary & Hisab ---
    suspend fun getMemberFinancialSummary(memberId: String): MemberFinancialSummary {
        val txns = dao.getTransactionsForMemberFlow(memberId).first()
        val emis = dao.getAllEmisForMemberFlow(memberId).first()
        val shares = dao.getAdditionalMembershipsForMemberFlow(memberId).first()
        val fees = dao.getFeesForMemberFlow(memberId).first()

        var totalSavingsDeposited = 0.0
        var totalSavingsWithdrawn = 0.0
        var totalMonthlyFeesPaid = 0.0
        var totalLateFinesPaid = 0.0
        var totalLoanTaken = 0.0
        var totalPrincipalRepaid = 0.0
        var totalInterestPaid = 0.0
        var totalOverdueInterestPaid = 0.0
        var totalInterestDistribution = 0.0

        for (t in txns) {
            when (t.category) {
                "SAVINGS_DEPOSIT" -> totalSavingsDeposited += t.amount
                "SAVINGS_WITHDRAWAL" -> totalSavingsWithdrawn += t.amount
                "MONTHLY_MEMBER_FEE" -> totalMonthlyFeesPaid += t.amount
                "LATE_FINE" -> totalLateFinesPaid += t.amount
                "LOAN_DISBURSEMENT" -> totalLoanTaken += t.amount
                "PRINCIPAL_REPAYMENT" -> totalPrincipalRepaid += t.amount
                "NORMAL_INTEREST" -> totalInterestPaid += t.amount
                "OVERDUE_INTEREST" -> totalOverdueInterestPaid += t.amount
                "INTEREST_DISTRIBUTION" -> totalInterestDistribution += t.amount
            }
        }

        val currentSavings = totalSavingsDeposited - totalSavingsWithdrawn
        val outstandingLoan = (totalLoanTaken - totalPrincipalRepaid).coerceAtLeast(0.0)
        val pendingDuesCount = fees.count { it.status == "PENDING" || it.status == "OVERDUE" } +
                emis.count { it.status == "OVERDUE" }

        val shareCount = shares.sumOf { it.count }
        val shareValue = shares.sumOf { it.totalMembershipValue }

        return MemberFinancialSummary(
            memberId = memberId,
            totalSavingsDeposited = totalSavingsDeposited,
            totalSavingsWithdrawn = totalSavingsWithdrawn,
            currentSavingsBalance = currentSavings,
            totalMonthlyFeesPaid = totalMonthlyFeesPaid,
            totalLateFinesPaid = totalLateFinesPaid,
            totalLoansTaken = totalLoanTaken,
            totalPrincipalRepaid = totalPrincipalRepaid,
            totalInterestPaid = totalInterestPaid,
            totalOverdueInterestPaid = totalOverdueInterestPaid,
            outstandingLoan = outstandingLoan,
            totalInterestDistributionReceived = totalInterestDistribution,
            additionalSharesCount = shareCount,
            additionalSharesValue = shareValue,
            pendingDuesCount = pendingDuesCount
        )
    }

    suspend fun updateMonthlyHisabForMember(memberId: String, monthYear: String) {
        val txns = dao.getTransactionsForMemberFlow(memberId).first()
        val txnsInMonth = txns.filter { it.monthYear == monthYear }

        val savingsDepositsInMonth = txnsInMonth.filter { it.category == "SAVINGS_DEPOSIT" }.sumOf { it.amount }
        val savingsWithdrawalsInMonth = txnsInMonth.filter { it.category == "SAVINGS_WITHDRAWAL" }.sumOf { it.amount }
        val feePaidInMonth = txnsInMonth.filter { it.category == "MONTHLY_MEMBER_FEE" }.sumOf { it.amount }
        val finePaidInMonth = txnsInMonth.filter { it.category == "LATE_FINE" }.sumOf { it.amount }
        val prinPaidInMonth = txnsInMonth.filter { it.category == "PRINCIPAL_REPAYMENT" }.sumOf { it.amount }
        val intPaidInMonth = txnsInMonth.filter { it.category == "NORMAL_INTEREST" }.sumOf { it.amount }
        val odIntPaidInMonth = txnsInMonth.filter { it.category == "OVERDUE_INTEREST" }.sumOf { it.amount }
        val sharePaidInMonth = txnsInMonth.filter { it.category == "ADDITIONAL_MEMBERSHIP" }.sumOf { it.amount }

        val totalPaidInMonth = savingsDepositsInMonth + feePaidInMonth + finePaidInMonth +
                prinPaidInMonth + intPaidInMonth + odIntPaidInMonth + sharePaidInMonth

        val summary = getMemberFinancialSummary(memberId)
        val closingSavings = summary.currentSavingsBalance
        val closingLoan = summary.outstandingLoan
        val openingSavings = closingSavings - savingsDepositsInMonth + savingsWithdrawalsInMonth

        val existing = dao.getMonthlyHisab(memberId, monthYear)
        if (existing == null) {
            dao.insertMonthlyHisab(
                MonthlyHisabEntity(
                    memberId = memberId,
                    monthYear = monthYear,
                    openingSavings = openingSavings,
                    monthlyMemberFee = 200.0,
                    savingsDeposit = savingsDepositsInMonth,
                    savingsWithdrawal = savingsWithdrawalsInMonth,
                    additionalMembership = sharePaidInMonth,
                    loanEmi = prinPaidInMonth + intPaidInMonth + odIntPaidInMonth,
                    principalPaid = prinPaidInMonth,
                    interestPaid = intPaidInMonth,
                    overdueInterestPaid = odIntPaidInMonth,
                    lateFine = finePaidInMonth,
                    totalPaid = totalPaidInMonth,
                    closingSavings = closingSavings,
                    closingLoan = closingLoan,
                    pendingAmount = if (feePaidInMonth == 0.0) 200.0 else 0.0
                )
            )
        } else {
            dao.updateMonthlyHisab(
                existing.copy(
                    openingSavings = openingSavings,
                    savingsDeposit = savingsDepositsInMonth,
                    savingsWithdrawal = savingsWithdrawalsInMonth,
                    additionalMembership = sharePaidInMonth,
                    loanEmi = prinPaidInMonth + intPaidInMonth + odIntPaidInMonth,
                    principalPaid = prinPaidInMonth,
                    interestPaid = intPaidInMonth,
                    overdueInterestPaid = odIntPaidInMonth,
                    lateFine = finePaidInMonth,
                    totalPaid = totalPaidInMonth,
                    closingSavings = closingSavings,
                    closingLoan = closingLoan,
                    pendingAmount = if (feePaidInMonth == 0.0) 200.0 else 0.0,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    // --- 2-Year Interest Pool & Distribution ---
    suspend fun calculateTotalLoanInterestCollected(): Double {
        val txns = dao.getAllTransactionsFlow().first()
        return txns.filter { it.category == "NORMAL_INTEREST" || it.category == "OVERDUE_INTEREST" }.sumOf { it.amount }
    }

    fun getAllInterestDistributions(): Flow<List<InterestDistributionEntity>> = dao.getAllInterestDistributionsFlow()
    fun getDistributionsForMember(memberId: String): Flow<List<InterestDistributionEntity>> =
        dao.getInterestDistributionsForMemberFlow(memberId)

    suspend fun executeInterestDistribution(
        cycleName: String,
        distributablePool: Double,
        user: String = "Admin"
    ): Int {
        val members = dao.getAllMembersFlow().first()
        val now = System.currentTimeMillis()

        // Eligible members: must be ACTIVE and either isTwoYearCompleted == true OR joiningDate <= now - 2 years
        val twoYearsMillis = 2L * 365 * 24 * 3600 * 1000
        val eligibleMembers = members.filter {
            it.accountStatus == "ACTIVE" && (it.isTwoYearCompleted || (now - it.joiningDate) >= twoYearsMillis)
        }

        if (eligibleMembers.isEmpty()) return 0

        val perMemberAmount = distributablePool / eligibleMembers.size
        val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date(now))

        for (member in eligibleMembers) {
            val txnId = "TXN-DIST-" + System.currentTimeMillis().toString().takeLast(6)
            val recNo = "REC-DIST-" + System.currentTimeMillis().toString().takeLast(6)

            // Insert Distribution Entity
            dao.insertInterestDistribution(
                InterestDistributionEntity(
                    cycleName = cycleName,
                    distributionDate = now,
                    totalInterestPool = distributablePool,
                    eligibleMemberCount = eligibleMembers.size,
                    distributionPerMember = perMemberAmount,
                    memberId = member.id,
                    transactionId = txnId
                )
            )

            // Insert Central Transaction
            dao.insertTransaction(
                TransactionEntity(
                    id = txnId,
                    memberId = member.id,
                    category = "INTEREST_DISTRIBUTION",
                    amount = perMemberAmount,
                    type = "CREDIT",
                    date = now,
                    monthYear = monthYear,
                    paymentMode = "BANK_TRANSFER",
                    receiptNumber = recNo,
                    remarks = "Equal share of 2-Year Loan Interest Pool: $cycleName",
                    createdBy = user
                )
            )

            // Receipt
            dao.insertReceipt(
                ReceiptEntity(
                    receiptNumber = recNo,
                    memberId = member.id,
                    memberName = member.fullName,
                    date = now,
                    monthYear = monthYear,
                    transactionType = "Interest Distribution Benefit",
                    amount = perMemberAmount,
                    paymentMode = "BANK_TRANSFER",
                    remarks = "2-Year Cycle Loan Interest Distribution ($cycleName)",
                    transactionId = txnId
                )
            )

            // Ensure member entity has isTwoYearCompleted = true
            if (!member.isTwoYearCompleted) {
                dao.updateMember(member.copy(isTwoYearCompleted = true))
            }
        }

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                action = "DISTRIBUTION",
                reason = "Executed $cycleName interest pool of ₹${distributablePool.toInt()} equally across ${eligibleMembers.size} eligible members (₹${perMemberAmount.toInt()} each)."
            )
        )

        return eligibleMembers.size
    }

    // --- Early Exit Settlement Calculation ---
    suspend fun calculateExitSettlement(memberId: String): ExitSettlementSummary? {
        val member = dao.getMemberById(memberId) ?: return null
        val summary = getMemberFinancialSummary(memberId)
        val now = System.currentTimeMillis()
        val twoYearsMillis = 2L * 365 * 24 * 3600 * 1000
        val isTwoYears = member.isTwoYearCompleted || (now - member.joiningDate) >= twoYearsMillis

        val outstandingFees = dao.getFeesForMemberFlow(memberId).first()
            .filter { it.status == "PENDING" || it.status == "OVERDUE" }
            .sumOf { it.feeAmount + it.lateFine }

        val netPayable = summary.currentSavingsBalance - summary.outstandingLoan - outstandingFees

        return ExitSettlementSummary(
            memberId = memberId,
            memberName = member.fullName,
            joiningDate = member.joiningDate,
            isTwoYearCompleted = isTwoYears,
            savingsRefundable = summary.currentSavingsBalance,
            outstandingLoanPrincipal = summary.outstandingLoan,
            outstandingInterest = 0.0,
            outstandingFeesAndFines = outstandingFees,
            netSettlementPayable = netPayable,
            nonRefundableMembershipFee = 500.0,
            nonRefundableMonthlyFees = summary.totalMonthlyFeesPaid,
            eligibleForInterestPool = isTwoYears
        )
    }

    suspend fun processMemberExit(memberId: String, reason: String, user: String = "Admin"): Boolean {
        val member = dao.getMemberById(memberId) ?: return false
        val settlement = calculateExitSettlement(memberId) ?: return false
        val now = System.currentTimeMillis()
        val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date(now))

        dao.updateMember(
            member.copy(
                accountStatus = "EXITED",
                exitDate = now,
                exitSettlementAmount = settlement.netSettlementPayable,
                exitRemarks = reason
            )
        )

        val txnId = "TXN-EXIT-" + now.toString().takeLast(6)
        val recNo = "REC-EXIT-" + now.toString().takeLast(6)

        dao.insertTransaction(
            TransactionEntity(
                id = txnId,
                memberId = memberId,
                category = "OTHER_EXPENSE",
                amount = settlement.netSettlementPayable.coerceAtLeast(0.0),
                type = "DEBIT",
                date = now,
                monthYear = monthYear,
                paymentMode = "BANK_TRANSFER",
                receiptNumber = recNo,
                remarks = "Early Exit Final Settlement: $reason",
                createdBy = user
            )
        )

        dao.insertReceipt(
            ReceiptEntity(
                receiptNumber = recNo,
                memberId = memberId,
                memberName = member.fullName,
                date = now,
                monthYear = monthYear,
                transactionType = "Member Exit Settlement",
                amount = settlement.netSettlementPayable,
                paymentMode = "BANK_TRANSFER",
                remarks = "Final Society Exit Settlement. Account Closed.",
                transactionId = txnId
            )
        )

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = txnId,
                action = "EXIT",
                oldValue = "ACTIVE",
                newValue = "EXITED",
                reason = "Member $memberId (${member.fullName}) exited society. Net settlement: ₹${settlement.netSettlementPayable.toInt()}. Reason: $reason"
            )
        )

        return true
    }

    // --- Dashboard Aggregations ---
    suspend fun getDashboardSummary(currentMonth: String): SocietyDashboardSummary {
        val members = dao.getAllMembersFlow().first()
        val txns = dao.getAllTransactionsFlow().first()
        val loans = dao.getAllLoansFlow().first()
        val emis = dao.getAllLoansFlow().first().flatMap { dao.getEmisForLoan(it.id) }
        val fees = dao.getFeesForMonthFlow(currentMonth).first()

        val totalMembers = members.size
        val activeMembers = members.count { it.accountStatus == "ACTIVE" }
        val now = System.currentTimeMillis()
        val twoYearsMillis = 2L * 365 * 24 * 3600 * 1000
        val completed2Years = members.count { it.isTwoYearCompleted || (now - it.joiningDate) >= twoYearsMillis }
        val pending2Years = activeMembers - completed2Years

        val totalSavingsDeposited = txns.filter { it.category == "SAVINGS_DEPOSIT" }.sumOf { it.amount }
        val totalSavingsWithdrawn = txns.filter { it.category == "SAVINGS_WITHDRAWAL" }.sumOf { it.amount }
        val totalSavings = totalSavingsDeposited - totalSavingsWithdrawn

        val totalLoanDisbursed = txns.filter { it.category == "LOAN_DISBURSEMENT" }.sumOf { it.amount }
        val totalPrincipalRepaid = txns.filter { it.category == "PRINCIPAL_REPAYMENT" }.sumOf { it.amount }
        val totalOutstandingLoan = (totalLoanDisbursed - totalPrincipalRepaid).coerceAtLeast(0.0)

        val txnsInMonth = txns.filter { it.monthYear == currentMonth }
        val thisMonthFee = txnsInMonth.filter { it.category == "MONTHLY_MEMBER_FEE" }.sumOf { it.amount }
        val thisMonthSav = txnsInMonth.filter { it.category == "SAVINGS_DEPOSIT" }.sumOf { it.amount }
        val thisMonthLoan = txnsInMonth.filter { it.category == "PRINCIPAL_REPAYMENT" }.sumOf { it.amount }
        val thisMonthInt = txnsInMonth.filter { it.category == "NORMAL_INTEREST" || it.category == "OVERDUE_INTEREST" }.sumOf { it.amount }

        val pendingFeeAmount = fees.filter { it.status == "PENDING" || it.status == "OVERDUE" }.sumOf { it.feeAmount + it.lateFine }
        val overdueEmis = emis.filter { it.status == "OVERDUE" }
        val overdueLoansCount = overdueEmis.map { it.loanId }.distinct().size

        val totalInterestPool = calculateTotalLoanInterestCollected()

        return SocietyDashboardSummary(
            totalMembers = totalMembers,
            activeMembers = activeMembers,
            membersCompletedTwoYears = completed2Years,
            membersPendingTwoYears = pending2Years.coerceAtLeast(0),
            totalSavings = totalSavings,
            totalLoanDisbursed = totalLoanDisbursed,
            totalOutstandingLoan = totalOutstandingLoan,
            thisMonthMemberFeeCollection = thisMonthFee,
            thisMonthSavingsCollection = thisMonthSav,
            thisMonthLoanCollection = thisMonthLoan,
            thisMonthInterestCollection = thisMonthInt,
            pendingPaymentsAmount = pendingFeeAmount + overdueEmis.sumOf { it.totalEmi },
            overdueLoansCount = overdueLoansCount,
            totalInterestPool = totalInterestPool
        )
    }

    // --- Receipts, Transactions, Audit, Rules ---
    fun getAllTransactions(): Flow<List<TransactionEntity>> = dao.getAllTransactionsFlow()
    fun getTransactionsForMember(memberId: String): Flow<List<TransactionEntity>> = dao.getTransactionsForMemberFlow(memberId)

    fun getAllReceipts(): Flow<List<ReceiptEntity>> = dao.getAllReceiptsFlow()
    fun getReceiptsForMember(memberId: String): Flow<List<ReceiptEntity>> = dao.getReceiptsForMemberFlow(memberId)
    suspend fun getReceiptByNumber(receiptNumber: String): ReceiptEntity? = dao.getReceiptByNumber(receiptNumber)

    fun getAllAuditLogs(): Flow<List<AuditLogEntity>> = dao.getAllAuditLogsFlow()
    fun getAllRules(): Flow<List<SocietyRuleEntity>> = dao.getAllRulesFlow()

    suspend fun updateSocietyRule(ruleKey: String, newValue: String, reason: String, user: String = "Admin") {
        val old = dao.getRuleByKey(ruleKey)
        if (old != null) {
            dao.insertRule(old.copy(ruleValue = newValue, lastUpdated = System.currentTimeMillis()))
            dao.insertAuditLog(
                AuditLogEntity(
                    user = user,
                    action = "RULE_CHANGE",
                    oldValue = "${old.ruleName} = ${old.ruleValue}",
                    newValue = "${old.ruleName} = $newValue",
                    reason = reason
                )
            )
        }
    }

    // --- Database Backup Export & Restore ---
    suspend fun exportDatabaseBackup(): String {
        val root = JSONObject()
        val membersArr = JSONArray()
        dao.getAllMembersFlow().first().forEach { m ->
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("name", m.fullName)
            obj.put("membershipNo", m.membershipNumber)
            obj.put("mobile", m.mobileNumber)
            obj.put("joiningDate", m.joiningDate)
            obj.put("status", m.accountStatus)
            membersArr.put(obj)
        }
        root.put("members", membersArr)

        val txnsArr = JSONArray()
        dao.getAllTransactionsFlow().first().forEach { t ->
            val obj = JSONObject()
            obj.put("id", t.id)
            obj.put("category", t.category)
            obj.put("amount", t.amount)
            obj.put("memberId", t.memberId)
            obj.put("date", t.date)
            txnsArr.put(obj)
        }
        root.put("transactions", txnsArr)
        root.put("backupDate", System.currentTimeMillis())
        root.put("version", "SUBIDHA-1.0")

        return root.toString(2)
    }

    // --- Admin Management: Member Deletion ---
    suspend fun deleteMemberPermanently(memberId: String, user: String, reason: String): Boolean {
        val member = dao.getMemberById(memberId) ?: return false
        dao.deleteMonthlyFeesByMember(memberId)
        dao.deleteSavingsByMember(memberId)
        dao.deleteAdditionalMembershipsByMember(memberId)
        dao.deleteLoansByMember(memberId)
        dao.deleteLoanEmisByMember(memberId)
        dao.deleteLoanAgreementsByMember(memberId)
        dao.deleteTransactionsByMember(memberId)
        dao.deleteMonthlyAccountsByMember(memberId)
        dao.deleteReceiptsByMember(memberId)
        dao.deleteInterestDistributionsByMember(memberId)
        dao.deleteMemberById(memberId)

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = memberId,
                action = "DELETE_MEMBER",
                oldValue = "Member: ${member.fullName} (${member.id})",
                newValue = "DELETED_PERMANENTLY",
                reason = reason
            )
        )
        return true
    }

    // --- Manual Monthly Member Collection ---
    suspend fun recordManualMonthlyCollection(
        memberId: String,
        monthYear: String,
        monthlyMemberFee: Double,
        savings: Double,
        loanInterest: Double,
        refund: Double,
        fine: Double,
        otherPayment: Double,
        paymentDate: Long,
        paymentMode: String,
        remarks: String,
        user: String
    ): ReceiptEntity? {
        val member = dao.getMemberById(memberId) ?: return null
        val totalAmount = monthlyMemberFee + savings + loanInterest + refund + fine + otherPayment
        val now = System.currentTimeMillis()
        val recNo = "REC-MC-" + now.toString().takeLast(6)

        // 1. Monthly fee entry
        val existingFee = dao.getMonthlyFee(memberId, monthYear)
        if (existingFee != null) {
            dao.updateMonthlyFee(
                existingFee.copy(
                    feeAmount = monthlyMemberFee,
                    lateFine = fine,
                    status = if (totalAmount > 0) "PAID" else "PENDING",
                    paidDate = if (totalAmount > 0) paymentDate else null,
                    receiptNumber = if (totalAmount > 0) recNo else existingFee.receiptNumber
                )
            )
        } else {
            val dueCalendar = Calendar.getInstance()
            dueCalendar.timeInMillis = paymentDate
            dueCalendar.set(Calendar.DAY_OF_MONTH, 10)
            dao.insertMonthlyFee(
                MonthlyFeeEntity(
                    memberId = memberId,
                    monthYear = monthYear,
                    feeAmount = monthlyMemberFee,
                    lateFine = fine,
                    status = if (totalAmount > 0) "PAID" else "PENDING",
                    dueDate = dueCalendar.timeInMillis,
                    paidDate = if (totalAmount > 0) paymentDate else null,
                    receiptNumber = if (totalAmount > 0) recNo else null
                )
            )
        }

        // 2. Savings Deposit if > 0
        if (savings > 0) {
            val txnSav = "TXN-SAV-" + now.toString().takeLast(6)
            dao.insertSavingsTransaction(
                SavingsTransactionEntity(
                    memberId = memberId,
                    transactionId = txnSav,
                    type = "DEPOSIT",
                    amount = savings,
                    date = paymentDate,
                    monthYear = monthYear,
                    paymentMode = paymentMode,
                    receiptNumber = recNo,
                    remarks = "Monthly Collection Savings: $remarks",
                    createdBy = user
                )
            )
            dao.insertTransaction(
                TransactionEntity(
                    id = txnSav,
                    memberId = memberId,
                    category = "SAVINGS_DEPOSIT",
                    amount = savings,
                    type = "CREDIT",
                    date = paymentDate,
                    monthYear = monthYear,
                    paymentMode = paymentMode,
                    receiptNumber = recNo,
                    remarks = "Monthly Savings: $remarks",
                    createdBy = user
                )
            )
        }

        // 3. Monthly Member Fee Txn
        if (monthlyMemberFee > 0) {
            val txnFee = "TXN-MFEE-" + now.toString().takeLast(6)
            dao.insertTransaction(
                TransactionEntity(
                    id = txnFee,
                    memberId = memberId,
                    category = "MONTHLY_MEMBER_FEE",
                    amount = monthlyMemberFee,
                    type = "CREDIT",
                    date = paymentDate,
                    monthYear = monthYear,
                    paymentMode = paymentMode,
                    receiptNumber = recNo,
                    remarks = "Monthly Member Fee ($monthYear)",
                    createdBy = user
                )
            )
        }

        // 4. Loan Interest Txn
        if (loanInterest > 0) {
            val txnInt = "TXN-INT-" + (now + 1).toString().takeLast(6)
            dao.insertTransaction(
                TransactionEntity(
                    id = txnInt,
                    memberId = memberId,
                    category = "NORMAL_INTEREST",
                    amount = loanInterest,
                    type = "CREDIT",
                    date = paymentDate,
                    monthYear = monthYear,
                    paymentMode = paymentMode,
                    receiptNumber = recNo,
                    remarks = "Monthly Loan Interest ($monthYear)",
                    createdBy = user
                )
            )
        }

        // 5. Loan Refund Txn
        if (refund > 0) {
            val txnRef = "TXN-REF-" + (now + 2).toString().takeLast(6)
            dao.insertTransaction(
                TransactionEntity(
                    id = txnRef,
                    memberId = memberId,
                    category = "PRINCIPAL_REPAYMENT",
                    amount = refund,
                    type = "CREDIT",
                    date = paymentDate,
                    monthYear = monthYear,
                    paymentMode = paymentMode,
                    receiptNumber = recNo,
                    remarks = "Loan Refund ($monthYear): $remarks",
                    createdBy = user
                )
            )

            // Also allocate to active loan if available
            val loans = dao.getLoansForMemberFlow(memberId).first()
            val activeLoan = loans.firstOrNull { it.status == "ACTIVE" || it.status == "OVERDUE" }
            if (activeLoan != null) {
                val totalRefunds = dao.getTransactionsForMemberFlow(memberId).first()
                    .filter { it.category == "PRINCIPAL_REPAYMENT" }
                    .sumOf { it.amount }
                if (totalRefunds >= activeLoan.loanAmount) {
                    dao.updateLoan(activeLoan.copy(status = "CLOSED", closedDate = paymentDate))
                }
            }
        }

        // 6. Fine Txn
        if (fine > 0) {
            val txnFine = "TXN-FINE-" + (now + 3).toString().takeLast(6)
            dao.insertTransaction(
                TransactionEntity(
                    id = txnFine,
                    memberId = memberId,
                    category = "LATE_FINE",
                    amount = fine,
                    type = "CREDIT",
                    date = paymentDate,
                    monthYear = monthYear,
                    paymentMode = paymentMode,
                    receiptNumber = recNo,
                    remarks = "Late Collection Fine ($monthYear)",
                    createdBy = user
                )
            )
        }

        // 7. Other payment
        if (otherPayment > 0) {
            val txnOther = "TXN-OTH-" + (now + 4).toString().takeLast(6)
            dao.insertTransaction(
                TransactionEntity(
                    id = txnOther,
                    memberId = memberId,
                    category = "OTHER_INCOME",
                    amount = otherPayment,
                    type = "CREDIT",
                    date = paymentDate,
                    monthYear = monthYear,
                    paymentMode = paymentMode,
                    receiptNumber = recNo,
                    remarks = "Other Payment ($monthYear): $remarks",
                    createdBy = user
                )
            )
        }

        // Update Monthly Hisab
        updateMonthlyHisabForMember(memberId, monthYear)

        val receipt = ReceiptEntity(
            receiptNumber = recNo,
            societyName = "KM STAFF SOCIETY",
            memberId = member.id,
            memberName = member.fullName,
            date = paymentDate,
            monthYear = monthYear,
            transactionType = "Monthly Member Collection",
            amount = totalAmount,
            paymentMode = paymentMode,
            remarks = "Fee: ₹${monthlyMemberFee.toInt()}, Savings: ₹${savings.toInt()}, Interest: ₹${loanInterest.toInt()}, Refund: ₹${refund.toInt()}, Fine: ₹${fine.toInt()}${if (otherPayment > 0) ", Other: ₹${otherPayment.toInt()}" else ""}. $remarks".trim(),
            transactionId = recNo,
            authorizedSignature = "Hon. Secretary, KM STAFF SOCIETY"
        )
        dao.insertReceipt(receipt)

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = recNo,
                action = "MONTHLY_COLLECTION",
                newValue = "Total: ₹$totalAmount for ${member.fullName} ($monthYear)",
                reason = "Manual Monthly Member Collection recorded"
            )
        )
        return receipt
    }

    // --- Manual Refund Entry ---
    suspend fun recordManualRefund(
        memberId: String,
        loanId: String?,
        refundAmount: Double,
        refundDate: Long,
        refundType: String, // "Loan Refund", "Principal Refund", "Other Refund"
        paymentMode: String,
        remarks: String,
        user: String
    ): ReceiptEntity? {
        val member = dao.getMemberById(memberId) ?: return null
        val now = System.currentTimeMillis()
        val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date(refundDate))
        val recNo = "REC-REF-" + now.toString().takeLast(6)
        val txnId = "TXN-REF-" + now.toString().takeLast(6)

        val category = when (refundType) {
            "Principal Refund" -> "PRINCIPAL_REPAYMENT"
            "Loan Refund" -> "PRINCIPAL_REPAYMENT"
            else -> "OTHER_INCOME"
        }

        dao.insertTransaction(
            TransactionEntity(
                id = txnId,
                memberId = memberId,
                category = category,
                amount = refundAmount,
                type = "CREDIT",
                date = refundDate,
                monthYear = monthYear,
                paymentMode = paymentMode,
                receiptNumber = recNo,
                referenceId = loanId,
                remarks = "$refundType: $remarks",
                createdBy = user
            )
        )

        if (!loanId.isNullOrEmpty()) {
            val loan = dao.getLoanById(loanId)
            if (loan != null) {
                val totalRefunds = dao.getTransactionsForMemberFlow(memberId).first()
                    .filter { (it.referenceId == loanId || it.category == "PRINCIPAL_REPAYMENT") }
                    .sumOf { it.amount }
                if (totalRefunds >= loan.loanAmount) {
                    dao.updateLoan(loan.copy(status = "CLOSED", closedDate = refundDate))
                }
            }
        }

        val receipt = ReceiptEntity(
            receiptNumber = recNo,
            societyName = "KM STAFF SOCIETY",
            memberId = member.id,
            memberName = member.fullName,
            date = refundDate,
            monthYear = monthYear,
            transactionType = refundType,
            amount = refundAmount,
            paymentMode = paymentMode,
            remarks = "Refund recorded for ${loanId ?: "General"}. $remarks".trim(),
            transactionId = txnId,
            authorizedSignature = "Hon. Secretary, KM STAFF SOCIETY"
        )
        dao.insertReceipt(receipt)

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = txnId,
                action = "RECORD_REFUND",
                newValue = "Refund ₹$refundAmount ($refundType) for ${member.fullName}",
                reason = "Manual refund recorded"
            )
        )

        updateMonthlyHisabForMember(memberId, monthYear)
        return receipt
    }

    // --- Manual Loan Creation, Editing & Deletion ---
    suspend fun recordManualLoan(
        memberId: String,
        loanAmount: Double,
        loanDate: Long,
        interestRateMonthly: Double = 2.0,
        tenureMonths: Int = 12,
        dueDateDay: Int = 10,
        remarks: String = "",
        user: String = "Admin"
    ): LoanEntity? {
        val member = dao.getMemberById(memberId) ?: return null
        val existingLoans = dao.getAllLoansFlow().first()
        val nextSeq = existingLoans.size + 1
        val loanId = String.format(Locale.getDefault(), "LOAN-%03d", nextSeq)
        val monthYear = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date(loanDate))

        val loan = LoanEntity(
            id = loanId,
            memberId = memberId,
            loanAmount = loanAmount,
            loanDate = loanDate,
            interestRateMonthly = interestRateMonthly,
            tenureMonths = tenureMonths,
            emiMonthly = loanAmount / tenureMonths,
            dueDateDay = dueDateDay,
            status = "ACTIVE",
            interestCalculationMethod = "REDUCING_BALANCE",
            cycleYear = 1,
            disbursementDate = loanDate,
            closedDate = null
        )
        dao.insertLoan(loan)

        val txnId = "TXN-DISB-" + System.currentTimeMillis().toString().takeLast(6)
        dao.insertTransaction(
            TransactionEntity(
                id = txnId,
                memberId = memberId,
                category = "LOAN_DISBURSEMENT",
                amount = loanAmount,
                type = "DEBIT",
                date = loanDate,
                monthYear = monthYear,
                paymentMode = "CASH",
                referenceId = loanId,
                remarks = "Loan Disbursed $loanId: $remarks",
                createdBy = user
            )
        )

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = loanId,
                action = "CREATE_LOAN",
                newValue = "Loan $loanId of ₹${loanAmount.toInt()} issued to ${member.fullName}",
                reason = remarks.ifBlank { "Manual loan entry" }
            )
        )

        updateMonthlyHisabForMember(memberId, monthYear)
        return loan
    }

    suspend fun editLoan(
        loanId: String,
        newAmount: Double,
        newDate: Long,
        newInterestRate: Double,
        newTenure: Int,
        newDueDay: Int,
        reason: String,
        user: String
    ): Boolean {
        val oldLoan = dao.getLoanById(loanId) ?: return false
        val updated = oldLoan.copy(
            loanAmount = newAmount,
            loanDate = newDate,
            interestRateMonthly = newInterestRate,
            tenureMonths = newTenure,
            dueDateDay = newDueDay
        )
        dao.updateLoan(updated)

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = loanId,
                action = "EDIT_LOAN",
                oldValue = "Amount: ₹${oldLoan.loanAmount}, Rate: ${oldLoan.interestRateMonthly}%, Tenure: ${oldLoan.tenureMonths}",
                newValue = "Amount: ₹$newAmount, Rate: $newInterestRate%, Tenure: $newTenure",
                reason = reason
            )
        )
        return true
    }

    suspend fun deleteLoan(loanId: String, user: String, reason: String): Boolean {
        val loan = dao.getLoanById(loanId) ?: return false
        dao.deleteLoanEmisByLoanId(loanId)
        dao.deleteLoanById(loanId)

        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = loanId,
                action = "DELETE_LOAN",
                oldValue = "Loan $loanId: ₹${loan.loanAmount} for ${loan.memberId}",
                newValue = "DELETED",
                reason = reason
            )
        )
        return true
    }

    // --- Month Status & Month Closing ---
    suspend fun closeMonth(monthYear: String, user: String): Boolean {
        val now = System.currentTimeMillis()
        dao.insertRule(
            SocietyRuleEntity(
                ruleKey = "month_status_$monthYear",
                ruleName = "Status of $monthYear",
                ruleValue = "CLOSED",
                description = "Closed by $user on ${Date(now)}",
                lastUpdated = now
            )
        )
        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = monthYear,
                action = "CLOSE_MONTH",
                newValue = "MONTH STATUS = CLOSED for $monthYear",
                reason = "Admin confirmed month closing"
            )
        )
        return true
    }

    suspend fun reopenMonth(monthYear: String, user: String, reason: String): Boolean {
        val now = System.currentTimeMillis()
        dao.insertRule(
            SocietyRuleEntity(
                ruleKey = "month_status_$monthYear",
                ruleName = "Status of $monthYear",
                ruleValue = "OPEN",
                description = "Reopened by $user on ${Date(now)}",
                lastUpdated = now
            )
        )
        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = monthYear,
                action = "REOPEN_MONTH",
                oldValue = "CLOSED",
                newValue = "OPEN",
                reason = reason
            )
        )
        return true
    }

    suspend fun isMonthClosed(monthYear: String): Boolean {
        val rule = dao.getRuleByKey("month_status_$monthYear")
        return rule?.ruleValue == "CLOSED"
    }

    suspend fun getManualEligibility(memberId: String): Double? {
        val rule = dao.getRuleByKey("manual_eligibility_$memberId")
        return rule?.ruleValue?.toDoubleOrNull()
    }

    suspend fun setManualEligibility(memberId: String, amount: Double?, user: String) {
        if (amount == null || amount <= 0) {
            dao.insertRule(
                SocietyRuleEntity(
                    ruleKey = "manual_eligibility_$memberId",
                    ruleName = "Manual Loan Eligibility",
                    ruleValue = "",
                    description = "Cleared by $user",
                    lastUpdated = System.currentTimeMillis()
                )
            )
        } else {
            dao.insertRule(
                SocietyRuleEntity(
                    ruleKey = "manual_eligibility_$memberId",
                    ruleName = "Manual Loan Eligibility",
                    ruleValue = amount.toString(),
                    description = "Set by $user",
                    lastUpdated = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun deleteMonthlyFee(feeId: Long, user: String, reason: String): Boolean {
        val fee = dao.getFeeById(feeId) ?: return false
        dao.deleteMonthlyFeeById(feeId)
        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = feeId.toString(),
                action = "DELETE_MONTHLY_FEE",
                oldValue = "Fee ID $feeId (${fee.memberId} - ${fee.monthYear} - ₹${fee.feeAmount})",
                newValue = "DELETED",
                reason = reason
            )
        )
        return true
    }

    suspend fun deleteTransaction(txnId: String, user: String, reason: String): Boolean {
        val txn = dao.getTransactionById(txnId) ?: return false
        dao.deleteTransactionById(txnId)
        dao.insertAuditLog(
            AuditLogEntity(
                user = user,
                transactionId = txnId,
                action = "DELETE_TRANSACTION",
                oldValue = "Txn $txnId: ₹${txn.amount} (${txn.category})",
                newValue = "DELETED",
                reason = reason
            )
        )
        return true
    }
}


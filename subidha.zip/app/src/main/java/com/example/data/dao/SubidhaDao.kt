package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SubidhaDao {

    // --- Users ---
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE mobileNumber = :mobile LIMIT 1")
    suspend fun getUserByMobile(mobile: String): UserEntity?

    @Query("SELECT * FROM users")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    // --- Members ---
    @Query("SELECT * FROM members ORDER BY joiningDate DESC")
    fun getAllMembersFlow(): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    suspend fun getMemberById(id: String): MemberEntity?

    @Query("SELECT * FROM members WHERE id = :id LIMIT 1")
    fun getMemberByIdFlow(id: String): Flow<MemberEntity?>

    @Query("SELECT COUNT(*) FROM members")
    fun getTotalMembersCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM members WHERE accountStatus = 'ACTIVE'")
    fun getActiveMembersCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: MemberEntity)

    @Update
    suspend fun updateMember(member: MemberEntity)

    // --- Monthly Member Fees ---
    @Query("SELECT * FROM monthly_member_fees WHERE monthYear = :monthYear ORDER BY memberId ASC")
    fun getFeesForMonthFlow(monthYear: String): Flow<List<MonthlyFeeEntity>>

    @Query("SELECT * FROM monthly_member_fees WHERE memberId = :memberId ORDER BY monthYear DESC")
    fun getFeesForMemberFlow(memberId: String): Flow<List<MonthlyFeeEntity>>

    @Query("SELECT * FROM monthly_member_fees WHERE memberId = :memberId AND monthYear = :monthYear LIMIT 1")
    suspend fun getMonthlyFee(memberId: String, monthYear: String): MonthlyFeeEntity?

    @Query("SELECT * FROM monthly_member_fees WHERE id = :id LIMIT 1")
    suspend fun getFeeById(id: Long): MonthlyFeeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMonthlyFee(fee: MonthlyFeeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMonthlyFees(fees: List<MonthlyFeeEntity>)

    @Update
    suspend fun updateMonthlyFee(fee: MonthlyFeeEntity)

    // --- Savings ---
    @Query("SELECT * FROM savings_transactions WHERE memberId = :memberId ORDER BY date DESC")
    fun getSavingsForMemberFlow(memberId: String): Flow<List<SavingsTransactionEntity>>

    @Query("SELECT * FROM savings_transactions ORDER BY date DESC")
    fun getAllSavingsFlow(): Flow<List<SavingsTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavingsTransaction(transaction: SavingsTransactionEntity): Long

    // --- Additional Membership / Shares ---
    @Query("SELECT * FROM additional_memberships WHERE memberId = :memberId ORDER BY purchaseDate DESC")
    fun getAdditionalMembershipsForMemberFlow(memberId: String): Flow<List<AdditionalMembershipEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdditionalMembership(membership: AdditionalMembershipEntity): Long

    // --- Loans ---
    @Query("SELECT * FROM loans ORDER BY loanDate DESC")
    fun getAllLoansFlow(): Flow<List<LoanEntity>>

    @Query("SELECT * FROM loans WHERE memberId = :memberId ORDER BY loanDate DESC")
    fun getLoansForMemberFlow(memberId: String): Flow<List<LoanEntity>>

    @Query("SELECT * FROM loans WHERE id = :id LIMIT 1")
    suspend fun getLoanById(id: String): LoanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoan(loan: LoanEntity)

    @Update
    suspend fun updateLoan(loan: LoanEntity)

    // --- Loan EMIs ---
    @Query("SELECT * FROM loan_emis WHERE loanId = :loanId ORDER BY emiNumber ASC")
    fun getEmisForLoanFlow(loanId: String): Flow<List<LoanEmiEntity>>

    @Query("SELECT * FROM loan_emis WHERE loanId = :loanId ORDER BY emiNumber ASC")
    suspend fun getEmisForLoan(loanId: String): List<LoanEmiEntity>

    @Query("SELECT * FROM loan_emis WHERE memberId = :memberId ORDER BY dueDate ASC")
    fun getAllEmisForMemberFlow(memberId: String): Flow<List<LoanEmiEntity>>

    @Query("SELECT * FROM loan_emis WHERE id = :id LIMIT 1")
    suspend fun getEmiById(id: Long): LoanEmiEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoanEmis(emis: List<LoanEmiEntity>)

    @Update
    suspend fun updateLoanEmi(emi: LoanEmiEntity)

    // --- Loan Agreements ---
    @Query("SELECT * FROM loan_agreements WHERE loanId = :loanId LIMIT 1")
    suspend fun getLoanAgreement(loanId: String): LoanAgreementEntity?

    @Query("SELECT * FROM loan_agreements WHERE loanId = :loanId LIMIT 1")
    fun getLoanAgreementFlow(loanId: String): Flow<LoanAgreementEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoanAgreement(agreement: LoanAgreementEntity)

    // --- Central Transactions ---
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    fun getAllTransactionsFlow(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE memberId = :memberId ORDER BY date DESC")
    fun getTransactionsForMemberFlow(memberId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getTransactionById(id: String): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    // --- Monthly Hisab ---
    @Query("SELECT * FROM monthly_accounts WHERE memberId = :memberId ORDER BY monthYear DESC")
    fun getMonthlyHisabForMemberFlow(memberId: String): Flow<List<MonthlyHisabEntity>>

    @Query("SELECT * FROM monthly_accounts WHERE memberId = :memberId AND monthYear = :monthYear LIMIT 1")
    suspend fun getMonthlyHisab(memberId: String, monthYear: String): MonthlyHisabEntity?

    @Query("SELECT * FROM monthly_accounts WHERE monthYear = :monthYear")
    fun getMonthlyHisabForMonthFlow(monthYear: String): Flow<List<MonthlyHisabEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMonthlyHisab(hisab: MonthlyHisabEntity)

    @Update
    suspend fun updateMonthlyHisab(hisab: MonthlyHisabEntity)

    // --- Receipts ---
    @Query("SELECT * FROM receipts ORDER BY date DESC")
    fun getAllReceiptsFlow(): Flow<List<ReceiptEntity>>

    @Query("SELECT * FROM receipts WHERE receiptNumber = :receiptNumber LIMIT 1")
    suspend fun getReceiptByNumber(receiptNumber: String): ReceiptEntity?

    @Query("SELECT * FROM receipts WHERE memberId = :memberId ORDER BY date DESC")
    fun getReceiptsForMemberFlow(memberId: String): Flow<List<ReceiptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: ReceiptEntity)

    // --- Interest Distribution ---
    @Query("SELECT * FROM interest_distributions ORDER BY distributionDate DESC")
    fun getAllInterestDistributionsFlow(): Flow<List<InterestDistributionEntity>>

    @Query("SELECT * FROM interest_distributions WHERE memberId = :memberId ORDER BY distributionDate DESC")
    fun getInterestDistributionsForMemberFlow(memberId: String): Flow<List<InterestDistributionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInterestDistribution(distribution: InterestDistributionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInterestDistributions(distributions: List<InterestDistributionEntity>)

    // --- Income & Expenses ---
    @Query("SELECT * FROM income_expenses ORDER BY date DESC")
    fun getAllIncomeExpensesFlow(): Flow<List<IncomeExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncomeExpense(item: IncomeExpenseEntity)

    // --- Society Rules ---
    @Query("SELECT * FROM society_rules")
    fun getAllRulesFlow(): Flow<List<SocietyRuleEntity>>

    @Query("SELECT * FROM society_rules WHERE ruleKey = :key LIMIT 1")
    suspend fun getRuleByKey(key: String): SocietyRuleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: SocietyRuleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRules(rules: List<SocietyRuleEntity>)

    // --- Audit Logs ---
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllAuditLogsFlow(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)

    // --- Deletion & Admin Management Queries ---
    @Query("DELETE FROM members WHERE id = :id")
    suspend fun deleteMemberById(id: String)

    @Query("DELETE FROM monthly_member_fees WHERE memberId = :memberId")
    suspend fun deleteMonthlyFeesByMember(memberId: String)

    @Query("DELETE FROM savings_transactions WHERE memberId = :memberId")
    suspend fun deleteSavingsByMember(memberId: String)

    @Query("DELETE FROM additional_memberships WHERE memberId = :memberId")
    suspend fun deleteAdditionalMembershipsByMember(memberId: String)

    @Query("DELETE FROM loans WHERE memberId = :memberId")
    suspend fun deleteLoansByMember(memberId: String)

    @Query("DELETE FROM loan_emis WHERE memberId = :memberId")
    suspend fun deleteLoanEmisByMember(memberId: String)

    @Query("DELETE FROM loan_agreements WHERE memberId = :memberId")
    suspend fun deleteLoanAgreementsByMember(memberId: String)

    @Query("DELETE FROM transactions WHERE memberId = :memberId")
    suspend fun deleteTransactionsByMember(memberId: String)

    @Query("DELETE FROM monthly_accounts WHERE memberId = :memberId")
    suspend fun deleteMonthlyAccountsByMember(memberId: String)

    @Query("DELETE FROM receipts WHERE memberId = :memberId")
    suspend fun deleteReceiptsByMember(memberId: String)

    @Query("DELETE FROM interest_distributions WHERE memberId = :memberId")
    suspend fun deleteInterestDistributionsByMember(memberId: String)

    @Query("DELETE FROM loans WHERE id = :loanId")
    suspend fun deleteLoanById(loanId: String)

    @Query("DELETE FROM loan_emis WHERE loanId = :loanId")
    suspend fun deleteLoanEmisByLoanId(loanId: String)

    @Query("DELETE FROM monthly_member_fees WHERE id = :id")
    suspend fun deleteMonthlyFeeById(id: Long)

    @Query("DELETE FROM monthly_accounts WHERE id = :id")
    suspend fun deleteMonthlyHisabById(id: Long)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: String)
}


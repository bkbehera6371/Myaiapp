package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val username: String,
    val passwordHash: String,
    val fullName: String,
    val role: String, // "ADMIN" or "STAFF"
    val mobileNumber: String,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "members")
data class MemberEntity(
    @PrimaryKey val id: String, // e.g. "SUB-001"
    val membershipNumber: String, // e.g. "MEM-2024-001"
    val fullName: String,
    val guardianName: String,
    val photoUri: String = "",
    val dob: String,
    val gender: String, // "Male", "Female", "Other"
    val mobileNumber: String,
    val whatsappNumber: String,
    val address: String,
    val nomineeName: String,
    val nomineeRelation: String,
    val nomineeMobile: String,
    val nomineeAge: Int,
    val joiningDate: Long, // timestamp in millis
    val accountStatus: String = "ACTIVE", // "ACTIVE", "INACTIVE", "EXITED"
    val twoYearCompletionDate: Long, // joiningDate + 2 years (millis)
    val additionalShareCount: Int = 0,
    val isTwoYearCompleted: Boolean = false,
    val exitDate: Long? = null,
    val exitSettlementAmount: Double? = null,
    val exitRemarks: String? = null
)

@Entity(tableName = "monthly_member_fees")
data class MonthlyFeeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val memberId: String,
    val monthYear: String, // e.g. "2026-09"
    val feeAmount: Double = 200.0,
    val lateFine: Double = 0.0,
    val status: String = "PENDING", // "PAID", "PENDING", "OVERDUE"
    val dueDate: Long, // typically 10th of that month
    val paidDate: Long? = null,
    val receiptNumber: String? = null,
    val transactionId: String? = null
)

@Entity(tableName = "savings_transactions")
data class SavingsTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val memberId: String,
    val transactionId: String,
    val type: String, // "DEPOSIT", "WITHDRAWAL", "ADJUSTMENT"
    val amount: Double,
    val date: Long,
    val monthYear: String,
    val paymentMode: String, // "CASH", "UPI", "BANK_TRANSFER"
    val receiptNumber: String,
    val remarks: String,
    val createdBy: String
)

@Entity(tableName = "additional_memberships")
data class AdditionalMembershipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val memberId: String,
    val count: Int,
    val pricePerMembership: Double,
    val totalMembershipValue: Double,
    val purchaseDate: Long,
    val receiptNumber: String,
    val transactionId: String,
    val remarks: String = ""
)

@Entity(tableName = "loans")
data class LoanEntity(
    @PrimaryKey val id: String, // e.g. "LOAN-001"
    val memberId: String,
    val loanAmount: Double = 5000.0,
    val loanDate: Long,
    val interestRateMonthly: Double = 2.0, // 2% per month
    val tenureMonths: Int = 12,
    val emiMonthly: Double,
    val dueDateDay: Int = 10,
    val status: String = "ACTIVE", // "APPLIED", "APPROVED", "DISBURSED", "ACTIVE", "OVERDUE", "CLOSED", "PENDING_SIGNATURE"
    val interestCalculationMethod: String = "REDUCING_BALANCE", // "REDUCING_BALANCE", "FLAT"
    val cycleYear: Int = 1, // 1 for Year 1, 2 for Year 2, 3 for Year 3
    val disbursementDate: Long? = null,
    val closedDate: Long? = null
)

@Entity(tableName = "loan_emis")
data class LoanEmiEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val loanId: String,
    val memberId: String,
    val emiNumber: Int, // 1 to 12
    val dueDate: Long,
    val principalAmount: Double,
    val normalInterest: Double, // 2% per month
    val overdueInterest: Double = 0.0, // 3% per month if overdue
    val totalEmi: Double,
    val amountPaid: Double = 0.0,
    val balance: Double,
    val status: String = "PENDING", // "PENDING", "PAID", "OVERDUE"
    val paidDate: Long? = null,
    val receiptNumber: String? = null,
    val transactionId: String? = null
)

@Entity(tableName = "loan_agreements")
data class LoanAgreementEntity(
    @PrimaryKey val loanId: String,
    val memberId: String,
    val termsVersion: String = "v1.0",
    val signatureStatus: String = "PENDING", // "PENDING", "SIGNED"
    val signatureTimestamp: Long? = null,
    val signatureData: String = "" // digital signature name or svg/encoded touch data
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String, // e.g. "TXN-20260901-001"
    val memberId: String? = null,
    val category: String, // "MEMBERSHIP_FEE", "MONTHLY_MEMBER_FEE", "SAVINGS_DEPOSIT", "SAVINGS_WITHDRAWAL", "ADDITIONAL_MEMBERSHIP", "LOAN_DISBURSEMENT", "PRINCIPAL_REPAYMENT", "NORMAL_INTEREST", "OVERDUE_INTEREST", "LATE_FINE", "OTHER_INCOME", "OTHER_EXPENSE", "INTEREST_DISTRIBUTION"
    val amount: Double,
    val type: String, // "CREDIT", "DEBIT"
    val date: Long,
    val monthYear: String,
    val paymentMode: String = "CASH", // "CASH", "UPI", "BANK_TRANSFER"
    val receiptNumber: String? = null,
    val referenceId: String? = null,
    val remarks: String = "",
    val createdBy: String = "Admin"
)

@Entity(tableName = "monthly_accounts")
data class MonthlyHisabEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val memberId: String,
    val monthYear: String, // "2026-09"
    val openingSavings: Double = 0.0,
    val monthlyMemberFee: Double = 200.0,
    val savingsDeposit: Double = 0.0,
    val savingsWithdrawal: Double = 0.0,
    val additionalMembership: Double = 0.0,
    val loanEmi: Double = 0.0,
    val principalPaid: Double = 0.0,
    val interestPaid: Double = 0.0,
    val overdueInterestPaid: Double = 0.0,
    val lateFine: Double = 0.0,
    val otherCharges: Double = 0.0,
    val totalPaid: Double = 0.0,
    val closingSavings: Double = 0.0,
    val closingLoan: Double = 0.0,
    val pendingAmount: Double = 0.0,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "receipts")
data class ReceiptEntity(
    @PrimaryKey val receiptNumber: String, // e.g. "REC-202609-001"
    val societyName: String = "SUBIDHA SOCIETY",
    val memberId: String,
    val memberName: String,
    val date: Long,
    val monthYear: String,
    val transactionType: String,
    val amount: Double,
    val paymentMode: String,
    val remarks: String,
    val transactionId: String,
    val authorizedSignature: String = "Hon. Secretary, SUBIDHA"
)

@Entity(tableName = "interest_distributions")
data class InterestDistributionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cycleName: String, // e.g. "2-Year Cycle 2024-2026"
    val distributionDate: Long,
    val totalInterestPool: Double,
    val eligibleMemberCount: Int,
    val distributionPerMember: Double,
    val memberId: String,
    val transactionId: String,
    val status: String = "COMPLETED"
)

@Entity(tableName = "income_expenses")
data class IncomeExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // "INCOME" or "EXPENSE"
    val category: String,
    val amount: Double,
    val date: Long,
    val paymentMode: String,
    val description: String,
    val createdBy: String
)

@Entity(tableName = "society_rules")
data class SocietyRuleEntity(
    @PrimaryKey val ruleKey: String,
    val ruleName: String,
    val ruleValue: String,
    val description: String,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val user: String,
    val timestamp: Long = System.currentTimeMillis(),
    val transactionId: String? = null,
    val action: String, // "CREATE", "UPDATE", "REVERSAL", "RULE_CHANGE", "EXIT"
    val oldValue: String? = null,
    val newValue: String? = null,
    val reason: String
)

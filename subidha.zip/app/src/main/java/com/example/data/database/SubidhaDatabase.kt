package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.SubidhaDao
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

@Database(
    entities = [
        UserEntity::class,
        MemberEntity::class,
        MonthlyFeeEntity::class,
        SavingsTransactionEntity::class,
        AdditionalMembershipEntity::class,
        LoanEntity::class,
        LoanEmiEntity::class,
        LoanAgreementEntity::class,
        TransactionEntity::class,
        MonthlyHisabEntity::class,
        ReceiptEntity::class,
        InterestDistributionEntity::class,
        IncomeExpenseEntity::class,
        SocietyRuleEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SubidhaDatabase : RoomDatabase() {

    abstract fun subidhaDao(): SubidhaDao

    companion object {
        @Volatile
        private var INSTANCE: SubidhaDatabase? = null

        fun getDatabase(context: Context): SubidhaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SubidhaDatabase::class.java,
                    "subidha_society_database.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    populateInitialData(database.subidhaDao())
                }
            }
        }

        private suspend fun populateInitialData(dao: SubidhaDao) {
            // 1. Users
            dao.insertUser(
                UserEntity(
                    username = "admin",
                    passwordHash = "admin123",
                    fullName = "Bikash Kumar (President)",
                    role = "ADMIN",
                    mobileNumber = "9876543210"
                )
            )
            dao.insertUser(
                UserEntity(
                    username = "staff",
                    passwordHash = "staff123",
                    fullName = "Ramesh Sen (Cashier)",
                    role = "STAFF",
                    mobileNumber = "9876543211"
                )
            )

            // 2. Society Rules
            val rules = listOf(
                SocietyRuleEntity("membership_fee", "One-Time Membership Fee", "500", "One-time registration fee for joining SUBIDHA Society"),
                SocietyRuleEntity("monthly_fee", "Monthly Member Fee", "200", "Fixed monthly society membership contribution"),
                SocietyRuleEntity("collection_window", "Collection Window", "1st to 10th", "Monthly collection window for member fees"),
                SocietyRuleEntity("late_fine", "Monthly Late Fine", "20", "Fine applicable after 10th of the month"),
                SocietyRuleEntity("loan_amount", "Standard Loan Amount", "5000", "Maximum standard member loan amount"),
                SocietyRuleEntity("loan_tenure", "Loan Tenure (Months)", "12", "Repayment schedule duration"),
                SocietyRuleEntity("normal_interest_rate", "Normal Loan Interest (%/Mo)", "2", "Normal monthly reducing balance interest rate"),
                SocietyRuleEntity("overdue_interest_rate", "Overdue Interest Rate (%/Mo)", "3", "Overdue interest rate for delayed installments"),
                SocietyRuleEntity("two_year_cycle", "Membership Completion Cycle", "2 Years", "Duration to qualify for equal loan-interest distribution"),
                SocietyRuleEntity("interest_method", "Interest Calculation Method", "REDUCING_BALANCE", "Calculation method: REDUCING_BALANCE or FLAT")
            )
            dao.insertRules(rules)

            // Current timestamp in Sept 2026
            val cal = Calendar.getInstance()
            val now = cal.timeInMillis

            // 2 years ago: Sept 2024
            cal.add(Calendar.YEAR, -2)
            val twoYearsAgo = cal.timeInMillis

            // 1.5 years ago: March 2025
            cal.timeInMillis = now
            cal.add(Calendar.MONTH, -18)
            val oneAndHalfYearAgo = cal.timeInMillis

            // 3 months ago: June 2026
            cal.timeInMillis = now
            cal.add(Calendar.MONTH, -3)
            val threeMonthsAgo = cal.timeInMillis

            // 3. Members
            val m1 = MemberEntity(
                id = "SUB-001",
                membershipNumber = "MEM-2024-001",
                fullName = "Rajesh Sharma",
                guardianName = "Gopal Sharma",
                dob = "1985-04-12",
                gender = "Male",
                mobileNumber = "9812345670",
                whatsappNumber = "9812345670",
                address = "Flat 102, Shanti Kunj, Ward 4",
                nomineeName = "Pooja Sharma",
                nomineeRelation = "Wife",
                nomineeMobile = "9812345679",
                nomineeAge = 36,
                joiningDate = twoYearsAgo,
                accountStatus = "ACTIVE",
                twoYearCompletionDate = twoYearsAgo + (2L * 365 * 24 * 3600 * 1000),
                additionalShareCount = 1,
                isTwoYearCompleted = true
            )

            val m2 = MemberEntity(
                id = "SUB-002",
                membershipNumber = "MEM-2025-014",
                fullName = "Anita Roy",
                guardianName = "Subhash Roy",
                dob = "1990-08-22",
                gender = "Female",
                mobileNumber = "9823456781",
                whatsappNumber = "9823456781",
                address = "House 45, Green Park Society",
                nomineeName = "Subhash Roy",
                nomineeRelation = "Husband",
                nomineeMobile = "9823456780",
                nomineeAge = 38,
                joiningDate = oneAndHalfYearAgo,
                accountStatus = "ACTIVE",
                twoYearCompletionDate = oneAndHalfYearAgo + (2L * 365 * 24 * 3600 * 1000),
                additionalShareCount = 0,
                isTwoYearCompleted = false
            )

            val m3 = MemberEntity(
                id = "SUB-003",
                membershipNumber = "MEM-2024-009",
                fullName = "Deepak Das",
                guardianName = "Biresh Das",
                dob = "1982-11-05",
                gender = "Male",
                mobileNumber = "9834567892",
                whatsappNumber = "9834567892",
                address = "Plot 12, Netaji Road",
                nomineeName = "Kavita Das",
                nomineeRelation = "Wife",
                nomineeMobile = "9834567890",
                nomineeAge = 39,
                joiningDate = twoYearsAgo - (30L * 24 * 3600 * 1000),
                accountStatus = "ACTIVE",
                twoYearCompletionDate = twoYearsAgo,
                additionalShareCount = 2,
                isTwoYearCompleted = true
            )

            val m4 = MemberEntity(
                id = "SUB-004",
                membershipNumber = "MEM-2026-032",
                fullName = "Manoj Verma",
                guardianName = "Ratan Verma",
                dob = "1994-02-17",
                gender = "Male",
                mobileNumber = "9845678903",
                whatsappNumber = "9845678903",
                address = "B-8, Railway Colony",
                nomineeName = "Sunita Verma",
                nomineeRelation = "Mother",
                nomineeMobile = "9845678904",
                nomineeAge = 54,
                joiningDate = threeMonthsAgo,
                accountStatus = "ACTIVE",
                twoYearCompletionDate = threeMonthsAgo + (2L * 365 * 24 * 3600 * 1000),
                additionalShareCount = 0,
                isTwoYearCompleted = false
            )

            dao.insertMember(m1)
            dao.insertMember(m2)
            dao.insertMember(m3)
            dao.insertMember(m4)

            // 4. Initial Membership Fee Transactions (₹500 each)
            listOf(m1, m2, m3, m4).forEachIndexed { index, m ->
                val txnId = "TXN-REG-00${index + 1}"
                val recNo = "REC-REG-00${index + 1}"
                dao.insertTransaction(
                    TransactionEntity(
                        id = txnId,
                        memberId = m.id,
                        category = "MEMBERSHIP_FEE",
                        amount = 500.0,
                        type = "CREDIT",
                        date = m.joiningDate,
                        monthYear = "Registration",
                        paymentMode = "CASH",
                        receiptNumber = recNo,
                        remarks = "One-Time Membership Fee ₹500",
                        createdBy = "Admin"
                    )
                )
                dao.insertReceipt(
                    ReceiptEntity(
                        receiptNumber = recNo,
                        memberId = m.id,
                        memberName = m.fullName,
                        date = m.joiningDate,
                        monthYear = "Joining",
                        transactionType = "One-Time Membership Fee",
                        amount = 500.0,
                        paymentMode = "CASH",
                        remarks = "Registration Fee paid. Welcome to SUBIDHA.",
                        transactionId = txnId
                    )
                )
            }

            // 5. Savings for Members
            // Member 1 savings deposit ₹5,000
            val sTxn1 = "TXN-SAV-001"
            dao.insertSavingsTransaction(
                SavingsTransactionEntity(
                    memberId = "SUB-001",
                    transactionId = sTxn1,
                    type = "DEPOSIT",
                    amount = 5000.0,
                    date = twoYearsAgo + (10L * 24 * 3600 * 1000),
                    monthYear = "2024-10",
                    paymentMode = "CASH",
                    receiptNumber = "REC-SAV-001",
                    remarks = "Initial Savings Deposit",
                    createdBy = "Admin"
                )
            )
            dao.insertTransaction(
                TransactionEntity(
                    id = sTxn1,
                    memberId = "SUB-001",
                    category = "SAVINGS_DEPOSIT",
                    amount = 5000.0,
                    type = "CREDIT",
                    date = twoYearsAgo + (10L * 24 * 3600 * 1000),
                    monthYear = "2024-10",
                    paymentMode = "CASH",
                    receiptNumber = "REC-SAV-001",
                    remarks = "Savings Deposit",
                    createdBy = "Admin"
                )
            )

            // Member 2 savings deposit ₹3,000
            val sTxn2 = "TXN-SAV-002"
            dao.insertSavingsTransaction(
                SavingsTransactionEntity(
                    memberId = "SUB-002",
                    transactionId = sTxn2,
                    type = "DEPOSIT",
                    amount = 3000.0,
                    date = oneAndHalfYearAgo + (10L * 24 * 3600 * 1000),
                    monthYear = "2025-04",
                    paymentMode = "UPI",
                    receiptNumber = "REC-SAV-002",
                    remarks = "Monthly Savings Accumulation",
                    createdBy = "Admin"
                )
            )
            dao.insertTransaction(
                TransactionEntity(
                    id = sTxn2,
                    memberId = "SUB-002",
                    category = "SAVINGS_DEPOSIT",
                    amount = 3000.0,
                    type = "CREDIT",
                    date = oneAndHalfYearAgo + (10L * 24 * 3600 * 1000),
                    monthYear = "2025-04",
                    paymentMode = "UPI",
                    receiptNumber = "REC-SAV-002",
                    remarks = "Savings Deposit",
                    createdBy = "Admin"
                )
            )

            // Member 3 savings deposit ₹6,000
            val sTxn3 = "TXN-SAV-003"
            dao.insertSavingsTransaction(
                SavingsTransactionEntity(
                    memberId = "SUB-003",
                    transactionId = sTxn3,
                    type = "DEPOSIT",
                    amount = 6000.0,
                    date = twoYearsAgo + (5L * 24 * 3600 * 1000),
                    monthYear = "2024-09",
                    paymentMode = "BANK_TRANSFER",
                    receiptNumber = "REC-SAV-003",
                    remarks = "Fixed Society Savings",
                    createdBy = "Admin"
                )
            )
            dao.insertTransaction(
                TransactionEntity(
                    id = sTxn3,
                    memberId = "SUB-003",
                    category = "SAVINGS_DEPOSIT",
                    amount = 6000.0,
                    type = "CREDIT",
                    date = twoYearsAgo + (5L * 24 * 3600 * 1000),
                    monthYear = "2024-09",
                    paymentMode = "BANK_TRANSFER",
                    receiptNumber = "REC-SAV-003",
                    remarks = "Savings Deposit",
                    createdBy = "Admin"
                )
            )

            // 6. Loans & EMIs
            // Anita Roy (SUB-002) has an Active Loan of ₹5,000 taken 6 months ago
            cal.timeInMillis = now
            cal.add(Calendar.MONTH, -6)
            val loan2Date = cal.timeInMillis

            val loan2 = LoanEntity(
                id = "LOAN-2026-002",
                memberId = "SUB-002",
                loanAmount = 5000.0,
                loanDate = loan2Date,
                interestRateMonthly = 2.0,
                tenureMonths = 12,
                emiMonthly = 472.0,
                status = "ACTIVE",
                cycleYear = 1,
                disbursementDate = loan2Date
            )
            dao.insertLoan(loan2)

            // Insert Agreement
            dao.insertLoanAgreement(
                LoanAgreementEntity(
                    loanId = loan2.id,
                    memberId = "SUB-002",
                    termsVersion = "v1.0",
                    signatureStatus = "SIGNED",
                    signatureTimestamp = loan2Date,
                    signatureData = "Anita Roy"
                )
            )

            // Loan 2 disbursement transaction
            dao.insertTransaction(
                TransactionEntity(
                    id = "TXN-DISB-002",
                    memberId = "SUB-002",
                    category = "LOAN_DISBURSEMENT",
                    amount = 5000.0,
                    type = "DEBIT",
                    date = loan2Date,
                    monthYear = "2026-03",
                    paymentMode = "BANK_TRANSFER",
                    receiptNumber = "REC-DISB-002",
                    remarks = "Loan Disbursed to Anita Roy",
                    createdBy = "Admin"
                )
            )

            // Create 12 EMIs for Loan 2
            val emis = mutableListOf<LoanEmiEntity>()
            var balanceRemaining = 5000.0
            val principalPerMonth = 5000.0 / 12.0
            for (i in 1..12) {
                cal.timeInMillis = loan2Date
                cal.add(Calendar.MONTH, i)
                val emiDueDate = cal.timeInMillis
                val normalInt = balanceRemaining * 0.02
                val totalEmi = principalPerMonth + normalInt

                val isPaid = i <= 5
                val isOverdue = i == 6
                val status = when {
                    isPaid -> "PAID"
                    isOverdue -> "OVERDUE"
                    else -> "PENDING"
                }

                val emi = LoanEmiEntity(
                    loanId = loan2.id,
                    memberId = "SUB-002",
                    emiNumber = i,
                    dueDate = emiDueDate,
                    principalAmount = principalPerMonth,
                    normalInterest = normalInt,
                    overdueInterest = if (isOverdue) balanceRemaining * 0.03 else 0.0,
                    totalEmi = totalEmi + if (isOverdue) balanceRemaining * 0.03 else 0.0,
                    amountPaid = if (isPaid) totalEmi else 0.0,
                    balance = if (isPaid) 0.0 else totalEmi,
                    status = status,
                    paidDate = if (isPaid) emiDueDate else null,
                    receiptNumber = if (isPaid) "REC-EMI-002-$i" else null,
                    transactionId = if (isPaid) "TXN-EMI-002-$i" else null
                )
                emis.add(emi)

                if (isPaid) {
                    balanceRemaining -= principalPerMonth
                    // Insert loan repayment transactions
                    dao.insertTransaction(
                        TransactionEntity(
                            id = "TXN-EMI-PRIN-002-$i",
                            memberId = "SUB-002",
                            category = "PRINCIPAL_REPAYMENT",
                            amount = principalPerMonth,
                            type = "CREDIT",
                            date = emiDueDate,
                            monthYear = "2026-${i + 3}",
                            paymentMode = "CASH",
                            receiptNumber = "REC-EMI-002-$i",
                            remarks = "Loan 2 EMI #$i Principal",
                            createdBy = "Admin"
                        )
                    )
                    dao.insertTransaction(
                        TransactionEntity(
                            id = "TXN-EMI-INT-002-$i",
                            memberId = "SUB-002",
                            category = "NORMAL_INTEREST",
                            amount = normalInt,
                            type = "CREDIT",
                            date = emiDueDate,
                            monthYear = "2026-${i + 3}",
                            paymentMode = "CASH",
                            receiptNumber = "REC-EMI-002-$i",
                            remarks = "Loan 2 EMI #$i Normal Interest (2%)",
                            createdBy = "Admin"
                        )
                    )
                }
            }
            dao.insertLoanEmis(emis)

            // Current Month Monthly Fees (September 2026)
            cal.timeInMillis = now
            val currentMonth = "2026-09"
            val tenthOfCurrentMonth = cal.timeInMillis

            val f1 = MonthlyFeeEntity(
                memberId = "SUB-001",
                monthYear = currentMonth,
                feeAmount = 200.0,
                lateFine = 0.0,
                status = "PAID",
                dueDate = tenthOfCurrentMonth,
                paidDate = tenthOfCurrentMonth - (5L * 24 * 3600 * 1000),
                receiptNumber = "REC-MFEE-202609-001",
                transactionId = "TXN-MFEE-202609-001"
            )
            val f2 = MonthlyFeeEntity(
                memberId = "SUB-002",
                monthYear = currentMonth,
                feeAmount = 200.0,
                lateFine = 20.0,
                status = "OVERDUE",
                dueDate = tenthOfCurrentMonth - (12L * 24 * 3600 * 1000)
            )
            val f3 = MonthlyFeeEntity(
                memberId = "SUB-003",
                monthYear = currentMonth,
                feeAmount = 200.0,
                lateFine = 0.0,
                status = "PENDING",
                dueDate = tenthOfCurrentMonth + (2L * 24 * 3600 * 1000)
            )
            val f4 = MonthlyFeeEntity(
                memberId = "SUB-004",
                monthYear = currentMonth,
                feeAmount = 200.0,
                lateFine = 0.0,
                status = "PAID",
                dueDate = tenthOfCurrentMonth,
                paidDate = tenthOfCurrentMonth - (2L * 24 * 3600 * 1000),
                receiptNumber = "REC-MFEE-202609-004",
                transactionId = "TXN-MFEE-202609-004"
            )
            dao.insertMonthlyFees(listOf(f1, f2, f3, f4))

            // Transaction for f1 & f4
            dao.insertTransaction(
                TransactionEntity(
                    id = "TXN-MFEE-202609-001",
                    memberId = "SUB-001",
                    category = "MONTHLY_MEMBER_FEE",
                    amount = 200.0,
                    type = "CREDIT",
                    date = now,
                    monthYear = currentMonth,
                    paymentMode = "CASH",
                    receiptNumber = "REC-MFEE-202609-001",
                    remarks = "September 2026 Monthly Member Fee",
                    createdBy = "Admin"
                )
            )
            dao.insertReceipt(
                ReceiptEntity(
                    receiptNumber = "REC-MFEE-202609-001",
                    memberId = "SUB-001",
                    memberName = "Rajesh Sharma",
                    date = now,
                    monthYear = currentMonth,
                    transactionType = "Monthly Member Fee",
                    amount = 200.0,
                    paymentMode = "CASH",
                    remarks = "September 2026 Monthly Member Fee ₹200",
                    transactionId = "TXN-MFEE-202609-001"
                )
            )

            // Monthly Hisab records for SUB-001
            dao.insertMonthlyHisab(
                MonthlyHisabEntity(
                    memberId = "SUB-001",
                    monthYear = currentMonth,
                    openingSavings = 5000.0,
                    monthlyMemberFee = 200.0,
                    savingsDeposit = 0.0,
                    savingsWithdrawal = 0.0,
                    additionalMembership = 0.0,
                    loanEmi = 0.0,
                    principalPaid = 0.0,
                    interestPaid = 0.0,
                    lateFine = 0.0,
                    otherCharges = 0.0,
                    totalPaid = 200.0,
                    closingSavings = 5000.0,
                    closingLoan = 0.0,
                    pendingAmount = 0.0
                )
            )

            // Audit log
            dao.insertAuditLog(
                AuditLogEntity(
                    user = "SYSTEM",
                    action = "INITIALIZE",
                    reason = "SUBIDHA Society Accounting Database initialized successfully with standard rules and starter ledgers."
                )
            )
        }
    }
}

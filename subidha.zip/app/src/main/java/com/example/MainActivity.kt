package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.example.ui.components.ReceiptDialog
import com.example.ui.components.SubidhaTopBar
import com.example.ui.screens.*
import com.example.ui.theme.SubidhaTheme
import com.example.ui.viewmodel.SubidhaViewModel
import kotlinx.coroutines.launch

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object Members : Screen("members", "Members", Icons.Default.Group)
    object MonthlyHisab : Screen("monthly_hisab", "Hisab", Icons.Default.ReceiptLong)
    object Loans : Screen("loans", "Loans", Icons.Default.AccountBalance)
    object Reports : Screen("reports", "Reports", Icons.Default.Assessment)
    object MemberRegistration : Screen("member_registration", "New Member", Icons.Default.PersonAdd)
    object MemberProfile : Screen("member_profile", "Profile", Icons.Default.Person)
    object InterestDistribution : Screen("interest_distribution", "Distribution", Icons.Default.VolunteerActivism)
    object WhatsApp : Screen("whatsapp", "WhatsApp Alerts", Icons.Default.Chat)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SubidhaTheme {
                SubidhaApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubidhaApp(viewModel: SubidhaViewModel = viewModel()) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val loginError by viewModel.loginError.collectAsStateWithLifecycle()
    val uiMessage by viewModel.uiMessage.collectAsStateWithLifecycle()
    val activeReceipt by viewModel.activeReceipt.collectAsStateWithLifecycle()

    val dashboardSummary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val allMembers by viewModel.allMembers.collectAsStateWithLifecycle()
    val selectedMember by viewModel.selectedMember.collectAsStateWithLifecycle()
    val memberSummary by viewModel.memberSummary.collectAsStateWithLifecycle()
    val memberFees by viewModel.memberFees.collectAsStateWithLifecycle()
    val memberSavings by viewModel.memberSavings.collectAsStateWithLifecycle()
    val memberLoans by viewModel.memberLoans.collectAsStateWithLifecycle()
    val memberTransactions by viewModel.memberTransactions.collectAsStateWithLifecycle()
    val memberAdditionalShares by viewModel.memberAdditionalShares.collectAsStateWithLifecycle()
    val memberHisab by viewModel.memberHisab.collectAsStateWithLifecycle()
    val memberDistributions by viewModel.memberDistributions.collectAsStateWithLifecycle()

    val monthlyFeesForSelectedMonth by viewModel.monthlyFeesForSelectedMonth.collectAsStateWithLifecycle()
    val allLoans by viewModel.allLoans.collectAsStateWithLifecycle()
    val allReceipts by viewModel.allReceipts.collectAsStateWithLifecycle()
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val allRules by viewModel.allRules.collectAsStateWithLifecycle()
    val allAuditLogs by viewModel.allAuditLogs.collectAsStateWithLifecycle()
    val allDistributions by viewModel.allDistributions.collectAsStateWithLifecycle()

    // Show Snackbar whenever uiMessage changes
    LaunchedEffect(uiMessage) {
        uiMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUiMessage()
        }
    }

    if (currentUser == null) {
        LoginScreen(
            onLogin = { user, pass -> viewModel.login(user, pass) },
            errorMessage = loginError
        )
        return
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val context = LocalContext.current
    var lastBackPressTime by remember { mutableLongStateOf(0L) }

    // Graceful back handling: double-back to exit on Dashboard to protect financial work session
    BackHandler(enabled = currentRoute == Screen.Dashboard.route) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastBackPressTime < 2000L) {
            (context as? Activity)?.finish()
        } else {
            lastBackPressTime = currentTime
            scope.launch {
                snackbarHostState.showSnackbar("Press back again to exit SUBIDHA")
            }
        }
    }

    val bottomNavScreens = listOf(
        Screen.Dashboard,
        Screen.Members,
        Screen.MonthlyHisab,
        Screen.Loans,
        Screen.Reports
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            SubidhaTopBar(
                currentUser = currentUser,
                onLogout = { viewModel.logout() }
            )
        },
        bottomBar = {
            // Show bottom navigation bar on primary screens
            if (bottomNavScreens.any { it.route == currentRoute } || currentRoute == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    bottomNavScreens.forEach { screen ->
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title, fontWeight = if (currentRoute == screen.route) FontWeight.Bold else FontWeight.Normal) },
                            selected = currentRoute == screen.route,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // 1. Dashboard
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    summary = dashboardSummary,
                    selectedMonth = selectedMonth,
                    onNavigateToMembers = { navController.navigate(Screen.Members.route) },
                    onNavigateToNewMember = { navController.navigate(Screen.MemberRegistration.route) },
                    onNavigateToMonthlyHisab = { navController.navigate(Screen.MonthlyHisab.route) },
                    onNavigateToLoans = { navController.navigate(Screen.Loans.route) },
                    onNavigateToInterestDistribution = { navController.navigate(Screen.InterestDistribution.route) },
                    onNavigateToReports = { navController.navigate(Screen.Reports.route) },
                    onGenerateMonthlyDues = { m -> viewModel.generateMonthlyDues(m) },
                    onApplyLateFines = { m -> viewModel.applyLateFines(m) }
                )
            }

            // 2. Members List
            composable(Screen.Members.route) {
                MemberListScreen(
                    members = allMembers,
                    onMemberClick = { memberId ->
                        viewModel.selectMember(memberId)
                        navController.navigate(Screen.MemberProfile.route)
                    },
                    onAddMemberClick = {
                        navController.navigate(Screen.MemberRegistration.route)
                    }
                )
            }

            // 3. Member Registration
            composable(Screen.MemberRegistration.route) {
                MemberRegistrationScreen(
                    onRegister = { fn, gn, dob, g, mob, wa, addr, nn, nr, nm, na, pm ->
                        viewModel.registerMember(
                            fullName = fn,
                            guardianName = gn,
                            dob = dob,
                            gender = g,
                            mobileNumber = mob,
                            whatsappNumber = wa,
                            address = addr,
                            nomineeName = nn,
                            nomineeRelation = nr,
                            nomineeMobile = nm,
                            nomineeAge = na,
                            paymentMode = pm,
                            onSuccess = {
                                navController.navigate(Screen.MemberProfile.route) {
                                    popUpTo(Screen.Members.route)
                                }
                            }
                        )
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            // 4. Member Profile (7-Tab Comprehensive View)
            composable(Screen.MemberProfile.route) {
                MemberProfileScreen(
                    member = selectedMember,
                    summary = memberSummary,
                    hisabList = memberHisab,
                    savingsList = memberSavings,
                    loansList = memberLoans,
                    transactionsList = memberTransactions,
                    additionalSharesList = memberAdditionalShares,
                    feesList = memberFees,
                    distributionsList = memberDistributions,
                    onBack = { navController.popBackStack() },
                    onAddSavings = { mId, type, amt, mode, rem ->
                        viewModel.addSavingsTransaction(mId, type, amt, mode, rem)
                    },
                    onBuyShares = { mId, count, price, mode, rem ->
                        viewModel.buyAdditionalShares(mId, count, price, mode, rem)
                    },
                    onApplyNewLoan = { mId, amt, tenure, rate, method ->
                        viewModel.applyLoan(mId, amt, tenure, rate, method)
                    },
                    onSignLoanAgreement = { lId, sig ->
                        viewModel.signLoanAgreementAndDisburse(lId, sig)
                    },
                    onPayLoanEmi = { emiId, mode, rem ->
                        viewModel.payLoanEmi(emiId, mode, rem)
                    },
                    onPayMonthlyFee = { feeId, mode, rem ->
                        viewModel.payMonthlyFee(feeId, mode, rem)
                    },
                    onViewReceipt = { r -> viewModel.showReceipt(r) },
                    onProcessExit = { mId, reason -> viewModel.processMemberExit(mId, reason) },
                    onGetEmisForLoan = { loanId ->
                        viewModel.repository.getEmisForLoanList(loanId)
                    }
                )
            }

            // 5. Monthly Hisab Screen
            composable(Screen.MonthlyHisab.route) {
                MonthlyHisabScreen(
                    selectedMonth = selectedMonth,
                    monthlyFees = monthlyFeesForSelectedMonth,
                    onSelectMonth = { m -> viewModel.setSelectedMonth(m) },
                    onGenerateDues = { m -> viewModel.generateMonthlyDues(m) },
                    onApplyLateFines = { m -> viewModel.applyLateFines(m) },
                    onPayFee = { feeId, mode, rem -> viewModel.payMonthlyFee(feeId, mode, rem) }
                )
            }

            // 6. Loans Screen
            composable(Screen.Loans.route) {
                LoansScreen(
                    loans = allLoans,
                    members = allMembers,
                    onSelectMember = { memberId ->
                        viewModel.selectMember(memberId)
                        navController.navigate(Screen.MemberProfile.route)
                    },
                    onSignLoanAgreement = { lId, sig ->
                        viewModel.signLoanAgreementAndDisburse(lId, sig)
                    },
                    onApplyLoan = { mId, amt, tenure, rate, method ->
                        viewModel.applyLoan(mId, amt, tenure, rate, method)
                    }
                )
            }

            // 7. Reports Screen
            composable(Screen.Reports.route) {
                ReportsScreen(
                    members = allMembers,
                    transactions = allTransactions,
                    fees = monthlyFeesForSelectedMonth,
                    loans = allLoans,
                    savings = memberSavings,
                    receipts = allReceipts
                )
            }

            // 8. 2-Year Interest Distribution Screen
            composable(Screen.InterestDistribution.route) {
                InterestDistributionScreen(
                    totalInterestPool = dashboardSummary?.totalInterestPool ?: 0.0,
                    eligibleMembers = allMembers.filter { it.isTwoYearCompleted && it.accountStatus == "ACTIVE" },
                    pastDistributions = allDistributions,
                    onExecuteDistribution = { cycle, pool ->
                        viewModel.executeInterestDistribution(cycle, pool)
                    },
                    onBack = { navController.popBackStack() }
                )
            }

            // 9. WhatsApp Screen
            composable(Screen.WhatsApp.route) {
                WhatsAppScreen(
                    members = allMembers,
                    selectedMonth = selectedMonth,
                    onBack = { navController.popBackStack() }
                )
            }

            // 10. Settings Screen
            composable(Screen.Settings.route) {
                SettingsScreen(
                    currentUser = currentUser,
                    rules = allRules,
                    auditLogs = allAuditLogs,
                    onUpdateRule = { k, v, r -> viewModel.updateSocietyRule(k, v, r) },
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }

    // Official Receipt Modal
    activeReceipt?.let { receipt ->
        ReceiptDialog(
            receipt = receipt,
            onDismiss = { viewModel.dismissReceipt() }
        )
    }
}

package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemberEntity
import com.example.ui.components.formatDate
import com.example.ui.components.formatRupee
import com.example.ui.theme.EmeraldPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatsAppScreen(
    members: List<MemberEntity>,
    selectedMonth: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedMember by remember { mutableStateOf(members.firstOrNull()) }
    var selectedTemplate by remember { mutableStateOf("MONTHLY_DUE") }

    val templates = listOf(
        Pair("MONTHLY_DUE", "Monthly Due Reminder (₹200)"),
        Pair("MEMBERSHIP_WELCOME", "New Member Welcome & Receipt"),
        Pair("OVERDUE_FINE", "Overdue Notice (+₹20 Fine)"),
        Pair("TWO_YEAR_DISTRIBUTION", "2-Year Interest Distribution")
    )

    val messageText = remember(selectedMember, selectedTemplate, selectedMonth) {
        val memberName = selectedMember?.fullName ?: "Valued Member"
        val memberId = selectedMember?.id ?: "SUB-001"
        when (selectedTemplate) {
            "MONTHLY_DUE" -> """
                *SUBIDHA SOCIETY NOTICE*
                Dear $memberName ($memberId),
                
                This is a friendly reminder that your *Monthly Member Fee of ₹200* for the month of *$selectedMonth* is now due.
                
                • Due Period: 1st to 10th of every month
                • Monthly Fee: ₹200
                • Mode: Cash / UPI / Bank Transfer
                
                _Note: To avoid a late fine of ₹20, kindly complete payment before the 10th._
                
                Thank you!
                *SUBIDHA Management*
            """.trimIndent()

            "MEMBERSHIP_WELCOME" -> """
                *WELCOME TO SUBIDHA SOCIETY*
                Dear $memberName,
                
                Congratulations! Your membership registration is confirmed.
                
                • *Member ID:* $memberId
                • *Registration Fee Paid:* ₹500
                • *Joining Date:* ${selectedMember?.let { formatDate(it.joiningDate) } ?: "Today"}
                • *2-Year Milestone:* ${selectedMember?.let { formatDate(it.twoYearCompletionDate) } ?: "24 Months"}
                
                We are excited to build our cooperative community with you!
                *SUBIDHA Administration*
            """.trimIndent()

            "OVERDUE_FINE" -> """
                *URGENT: SUBIDHA SOCIETY OVERDUE NOTICE*
                Dear $memberName ($memberId),
                
                Your Monthly Member Fee for *$selectedMonth* is overdue past the 10th of the month.
                
                • Monthly Fee: ₹200
                • Late Fine: ₹20
                • *Total Outstanding: ₹220*
                
                Please clear this immediately to keep your membership account in active standing.
                
                *SUBIDHA Accounts Desk*
            """.trimIndent()

            "TWO_YEAR_DISTRIBUTION" -> """
                *CELEBRATING 2 YEARS AT SUBIDHA!*
                Dear $memberName ($memberId),
                
                We are proud to celebrate your *2-Year Society Membership milestone*!
                
                As an eligible member completing the 2-year cycle, you are entitled to an equal share of the Society Loan Interest Income Pool.
                
                Your distribution benefit has been calculated and credited to your society account statement.
                
                Warm congratulations!
                *SUBIDHA Society Committee*
            """.trimIndent()

            else -> ""
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("WhatsApp Society Alerts", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("1. Select Member", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        var expanded by remember { mutableStateOf(false) }

                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { expanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(selectedMember?.let { "${it.fullName} (${it.id})" } ?: "Choose Member")
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            }

                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                members.forEach { m ->
                                    DropdownMenuItem(
                                        text = { Text("${m.fullName} (${m.id}) - ${m.mobileNumber}") },
                                        onClick = {
                                            selectedMember = m
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("2. Message Template", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            templates.forEach { (key, label) ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    RadioButton(
                                        selected = selectedTemplate == key,
                                        onClick = { selectedTemplate = key }
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(label, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }

            // Preview Message Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Message Preview", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Text("WhatsApp Ready", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF25D366), fontWeight = FontWeight.Bold))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = messageText,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                modifier = Modifier.padding(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val phone = selectedMember?.whatsappNumber?.ifEmpty { selectedMember?.mobileNumber } ?: ""
                                sendWhatsAppDirect(context, phone, messageText)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Send to Member via WhatsApp", color = Color.White, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }
    }
}

fun sendWhatsAppDirect(context: Context, phone: String, message: String) {
    try {
        val cleanPhone = phone.replace("+", "").replace("-", "").replace(" ", "").trim()
        val formattedPhone = if (cleanPhone.length == 10) "91$cleanPhone" else cleanPhone
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$formattedPhone&text=" + Uri.encode(message))
        val intent = Intent(Intent.ACTION_VIEW, uri)
        context.startActivity(intent)
    } catch (e: Exception) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, message)
            type = "text/plain"
        }
        context.startActivity(Intent.createChooser(sendIntent, "Send Notification"))
    }
}

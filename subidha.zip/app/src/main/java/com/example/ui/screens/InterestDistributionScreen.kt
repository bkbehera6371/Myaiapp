package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InterestDistributionEntity
import com.example.data.model.MemberEntity
import com.example.ui.components.KmSocietyLogo
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatDate
import com.example.ui.components.formatRupee
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldOnContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldTertiary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InterestDistributionScreen(
    totalInterestPool: Double,
    eligibleMembers: List<MemberEntity>,
    pastDistributions: List<InterestDistributionEntity>,
    onExecuteDistribution: (String, Double) -> Unit,
    onBack: () -> Unit
) {
    var showExecuteDialog by remember { mutableStateOf(false) }

    val eligibleCount = eligibleMembers.size
    val sharePerMember = if (eligibleCount > 0) totalInterestPool / eligibleCount else 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        KmSocietyLogo(size = 30.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("2-Year Equal Interest Distribution", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text("KM STAFF SOCIETY", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Pool Formula Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "Distributable Loan Interest Pool",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f))
                        )
                        Text(
                            text = formatRupee(totalInterestPool),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Surface(
                            color = Color.Black.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "EQUAL DISTRIBUTION FORMULA:",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "Share Per Member = Total Pool (₹${totalInterestPool.toInt()}) ÷ Eligible Members ($eligibleCount)",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "= ${formatRupee(sharePerMember)} per member",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = Color(0xFFFEF08A),
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = { showExecuteDialog = true },
                            enabled = eligibleCount > 0 && totalInterestPool > 0,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.VolunteerActivism, contentDescription = null, tint = EmeraldPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Execute Distribution to $eligibleCount Members",
                                color = EmeraldPrimary,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            // Society Rules & Eligibility Conditions
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Mandatory Distribution Rules:", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Text("• Loan Interest Income is kept strictly separate from membership fees and savings.", style = MaterialTheme.typography.bodySmall)
                        Text("• ONLY active members who have completed 2 years are eligible.", style = MaterialTheme.typography.bodySmall)
                        Text("• Members who left early or defaulted on tenure receive NO distribution.", style = MaterialTheme.typography.bodySmall)
                        Text("• Distribution is strictly equal among all eligible members.", style = MaterialTheme.typography.bodySmall)
                        Text("• Credited automatically to individual member profiles & general ledger.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // Eligible Members List
            item {
                Text(
                    text = "Eligible Members ($eligibleCount)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }

            if (eligibleMembers.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text("No members have completed the 2-year tenure yet.")
                        }
                    }
                }
            } else {
                items(eligibleMembers) { member ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(member.fullName, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                Text("${member.id} • Joined: ${formatDate(member.joiningDate)}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            }
                            StatusBadge(status = "2-Year Completed")
                        }
                    }
                }
            }

            // Past Distributions
            if (pastDistributions.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Distribution History",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                items(pastDistributions) { dist ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(dist.cycleName, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                Text("Member: ${dist.memberId} • ${formatDate(dist.distributionDate)}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            }
                            Text(formatRupee(dist.distributionPerMember), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                        }
                    }
                }
            }
        }
    }

    if (showExecuteDialog) {
        var cycleName by remember { mutableStateOf("Cycle 1 (2024-2026)") }

        AlertDialog(
            onDismissRequest = { showExecuteDialog = false },
            title = { Text("Confirm 2-Year Distribution") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Total Distributable Pool: ${formatRupee(totalInterestPool)}", fontWeight = FontWeight.Bold)
                    Text("Eligible Members: $eligibleCount")
                    Text("Amount Each: ${formatRupee(sharePerMember)}", color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = cycleName,
                        onValueChange = { cycleName = it },
                        label = { Text("Distribution Cycle Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onExecuteDistribution(cycleName, totalInterestPool)
                        showExecuteDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("Distribute Equally")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExecuteDialog = false }) { Text("Cancel") }
            }
        )
    }
}

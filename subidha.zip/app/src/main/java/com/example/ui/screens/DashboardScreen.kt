package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.SocietyDashboardSummary
import com.example.ui.components.FinancialMetricCard
import com.example.ui.components.MonthlyCollectionChart
import com.example.ui.components.formatRupee
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    summary: SocietyDashboardSummary?,
    selectedMonth: String,
    onNavigateToMembers: () -> Unit,
    onNavigateToNewMember: () -> Unit,
    onNavigateToMonthlyHisab: () -> Unit,
    onNavigateToLoans: () -> Unit,
    onNavigateToInterestDistribution: () -> Unit,
    onNavigateToReports: () -> Unit,
    onGenerateMonthlyDues: (String) -> Unit,
    onApplyLateFines: (String) -> Unit
) {
    var showMonthlyActionsDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header & Current Cycle Banner
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Society Financial Dashboard",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                            Text(
                                text = "Current Month: $selectedMonth",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                                )
                            )
                        }

                        FilledTonalButton(
                            onClick = { showMonthlyActionsDialog = true },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Monthly Run", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2-Year Interest Pool Highlight
                    Surface(
                        color = Color.Black.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "2-Year Distributable Interest Pool",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f))
                                )
                                Text(
                                    text = formatRupee(summary?.totalInterestPool ?: 0.0),
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                )
                            }

                            FilledTonalButton(
                                onClick = onNavigateToInterestDistribution,
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = GoldContainer,
                                    contentColor = GoldOnContainer
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Pool Details", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }
            }
        }

        // Quick Actions Grid
        item {
            Text(
                text = "Quick Actions",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionItem(
                    label = "New Member",
                    icon = Icons.Default.PersonAdd,
                    color = EmeraldPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToNewMember
                )
                QuickActionItem(
                    label = "Monthly Dues",
                    icon = Icons.Default.ReceiptLong,
                    color = NavySecondary,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToMonthlyHisab
                )
                QuickActionItem(
                    label = "Loans & EMI",
                    icon = Icons.Default.AccountBalance,
                    color = GoldTertiary,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToLoans
                )
                QuickActionItem(
                    label = "Reports",
                    icon = Icons.Default.Assessment,
                    color = Color(0xFF7C3AED),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToReports
                )
            }
        }

        // Alert Banners (if pending payments or overdue loans exist)
        if ((summary?.pendingPaymentsAmount ?: 0.0) > 0 || (summary?.overdueLoansCount ?: 0) > 0) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Pending Collections & Overdues",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            )
                            Text(
                                text = "Pending dues: ${formatRupee(summary?.pendingPaymentsAmount ?: 0.0)} | Overdue loans: ${summary?.overdueLoansCount ?: 0}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onErrorContainer)
                            )
                        }
                    }
                }
            }
        }

        // Collection Trends Chart
        item {
            MonthlyCollectionChart(
                memberFee = summary?.thisMonthMemberFeeCollection ?: 0.0,
                savings = summary?.thisMonthSavingsCollection ?: 0.0,
                loanRepayment = summary?.thisMonthLoanCollection ?: 0.0,
                interest = summary?.thisMonthInterestCollection ?: 0.0
            )
        }

        // Member Statistics
        item {
            Text(
                text = "Member Statistics",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Total Members",
                    value = (summary?.totalMembers ?: 0).toString(),
                    subtitle = "Active: ${summary?.activeMembers ?: 0}",
                    icon = Icons.Default.Groups,
                    color = EmeraldPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToMembers
                )
                StatCard(
                    title = "2-Year Completed",
                    value = (summary?.membersCompletedTwoYears ?: 0).toString(),
                    subtitle = "Pending: ${summary?.membersPendingTwoYears ?: 0}",
                    icon = Icons.Default.Verified,
                    color = Color(0xFF15803D),
                    modifier = Modifier.weight(1f),
                    onClick = onNavigateToMembers
                )
            }
        }

        // Society Overall Financial Position
        item {
            Text(
                text = "Society Financial Summary",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FinancialMetricCard(
                    title = "Total Society Savings Balance",
                    amount = summary?.totalSavings ?: 0.0,
                    subtitle = "Cumulative member deposits minus withdrawals",
                    icon = Icons.Default.Savings,
                    accentColor = EmeraldPrimary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FinancialMetricCard(
                        title = "Total Loan Disbursed",
                        amount = summary?.totalLoanDisbursed ?: 0.0,
                        subtitle = "Cumulative disbursements",
                        icon = Icons.Default.MonetizationOn,
                        accentColor = NavySecondary,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        title = "Outstanding Loan",
                        amount = summary?.totalOutstandingLoan ?: 0.0,
                        subtitle = "Principal balance due",
                        icon = Icons.Default.HourglassTop,
                        accentColor = GoldTertiary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // This Month's Collections Breakdown
        item {
            Text(
                text = "Collections This Month ($selectedMonth)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FinancialMetricCard(
                        title = "Member Fees (₹200)",
                        amount = summary?.thisMonthMemberFeeCollection ?: 0.0,
                        subtitle = "Fixed monthly contribution",
                        icon = Icons.Default.CardMembership,
                        accentColor = EmeraldPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        title = "Savings Deposits",
                        amount = summary?.thisMonthSavingsCollection ?: 0.0,
                        subtitle = "Deposits this month",
                        icon = Icons.Default.Savings,
                        accentColor = NavySecondary,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FinancialMetricCard(
                        title = "Loan Principal Repaid",
                        amount = summary?.thisMonthLoanCollection ?: 0.0,
                        subtitle = "Principal collected",
                        icon = Icons.Default.Payments,
                        accentColor = GoldTertiary,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        title = "Loan Interest Collected",
                        amount = summary?.thisMonthInterestCollection ?: 0.0,
                        subtitle = "Goes into 2-Yr Pool",
                        icon = Icons.Default.TrendingUp,
                        accentColor = Color(0xFF7C3AED),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    // Monthly Actions Dialog
    if (showMonthlyActionsDialog) {
        AlertDialog(
            onDismissRequest = { showMonthlyActionsDialog = false },
            title = { Text("Automatic Monthly Operations") },
            text = {
                Column {
                    Text(
                        text = "SUBIDHA monthly automated accounting rules:\n\n" +
                                "1. Generate ₹200 Monthly Member Fee for every active member.\n" +
                                "2. Collection window is 1st to 10th of every month.\n" +
                                "3. After 10th, apply ₹20 late fine for pending members.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onGenerateMonthlyDues(selectedMonth)
                        showMonthlyActionsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("Generate ₹200 Dues")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        onApplyLateFines(selectedMonth)
                        showMonthlyActionsDialog = false
                    }
                ) {
                    Text("Apply ₹20 Late Fines")
                }
            }
        )
    }
}

@Composable
fun QuickActionItem(
    label: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = 12.dp, horizontal = 6.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
            )
        }
    }
}

package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LoanEntity
import com.example.data.model.MemberEntity
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatDate
import com.example.ui.components.formatRupee
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldTertiary
import com.example.ui.theme.NavySecondary
import com.example.ui.theme.StatusOverdueRed
import com.example.ui.theme.StatusPaidGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoansScreen(
    loans: List<LoanEntity>,
    members: List<MemberEntity>,
    onSelectMember: (String) -> Unit,
    onSignLoanAgreement: (String, String) -> Unit,
    onApplyLoan: (String, Double, Int, Double, String) -> Unit
) {
    var filterStatus by remember { mutableStateOf("ALL") }
    var showNewLoanDialog by remember { mutableStateOf(false) }
    var signLoanTarget by remember { mutableStateOf<LoanEntity?>(null) }

    val memberMap = remember(members) { members.associateBy { it.id } }

    val totalDisbursed = loans.sumOf { it.loanAmount }
    val activeLoans = loans.filter { it.status == "ACTIVE" || it.status == "OVERDUE" }
    val overdueLoans = loans.filter { it.status == "OVERDUE" }

    val filteredList = loans.filter { loan ->
        when (filterStatus) {
            "ACTIVE" -> loan.status == "ACTIVE"
            "OVERDUE" -> loan.status == "OVERDUE"
            "PENDING_SIGN" -> loan.status == "PENDING_SIGNATURE"
            "CLOSED" -> loan.status == "CLOSED"
            else -> true
        }
    }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showNewLoanDialog = true },
                containerColor = GoldTertiary,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Issue Loan") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Society Loan Management", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text("Standard ₹5,000 per member per cycle • 2% normal interest • 3% overdue penalty", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline))
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Total Disbursed", style = MaterialTheme.typography.labelSmall)
                                Text(formatRupee(totalDisbursed), style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Active Accounts", style = MaterialTheme.typography.labelSmall)
                                Text("${activeLoans.size}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = NavySecondary))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Overdue Accounts", style = MaterialTheme.typography.labelSmall)
                                Text("${overdueLoans.size}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = StatusOverdueRed))
                            }
                        }
                    }
                }
            }

            // Filter chips
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        Pair("ALL", "All (${loans.size})"),
                        Pair("ACTIVE", "Active (${activeLoans.size})"),
                        Pair("PENDING_SIGN", "Pending Sign"),
                        Pair("OVERDUE", "Overdue (${overdueLoans.size})"),
                        Pair("CLOSED", "Closed")
                    ).forEach { (k, label) ->
                        FilterChip(
                            selected = filterStatus == k,
                            onClick = { filterStatus = k },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            // Loans list
            if (filteredList.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(modifier = Modifier.padding(32.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text("No loan records found")
                        }
                    }
                }
            } else {
                items(filteredList, key = { it.id }) { loan ->
                    val memberName = memberMap[loan.memberId]?.fullName ?: loan.memberId

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(loan.id, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                                    Text("$memberName (${loan.memberId})", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                                }
                                StatusBadge(status = loan.status)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text("Disbursed Amount", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                    Text(formatRupee(loan.loanAmount), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Tenure & Terms", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                    Text("${loan.tenureMonths} Mos @ 2%/mo", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (loan.status == "PENDING_SIGNATURE") {
                                    Button(
                                        onClick = { signLoanTarget = loan },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                                    ) {
                                        Icon(Icons.Default.Draw, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Sign Agreement", style = MaterialTheme.typography.labelSmall)
                                    }
                                } else {
                                    Text(
                                        text = "Agreement Signed & Disbursed",
                                        style = MaterialTheme.typography.labelSmall.copy(color = StatusPaidGreen)
                                    )
                                }

                                TextButton(onClick = { onSelectMember(loan.memberId) }) {
                                    Text("View Member Profile", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // New Loan Dialog
    if (showNewLoanDialog) {
        var selectedMemberId by remember { mutableStateOf(members.firstOrNull()?.id ?: "") }
        var amountStr by remember { mutableStateOf("5000") }
        var method by remember { mutableStateOf("REDUCING_BALANCE") }

        AlertDialog(
            onDismissRequest = { showNewLoanDialog = false },
            title = { Text("Issue Society Loan") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select Eligible Member:")
                    LazyColumn(modifier = Modifier.height(120.dp)) {
                        items(members.filter { it.accountStatus == "ACTIVE" }) { m ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedMemberId == m.id,
                                    onClick = { selectedMemberId = m.id }
                                )
                                Text("${m.fullName} (${m.id})", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("Loan Amount (₹)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = amountStr.toDoubleOrNull() ?: 5000.0
                        if (selectedMemberId.isNotEmpty()) {
                            onApplyLoan(selectedMemberId, amt, 12, 2.0, method)
                            showNewLoanDialog = false
                        }
                    }
                ) {
                    Text("Apply Loan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewLoanDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Sign Agreement Modal
    signLoanTarget?.let { loan ->
        var sigName by remember { mutableStateOf(memberMap[loan.memberId]?.fullName ?: "") }

        AlertDialog(
            onDismissRequest = { signLoanTarget = null },
            title = { Text("Sign Digital Loan Agreement") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("By signing, the member formally accepts the loan conditions and promises repayment per the 12-month schedule.")
                    OutlinedTextField(
                        value = sigName,
                        onValueChange = { sigName = it },
                        label = { Text("Full Legal Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSignLoanAgreement(loan.id, sigName)
                        signLoanTarget = null
                    }
                ) {
                    Text("Sign & Disburse")
                }
            },
            dismissButton = {
                TextButton(onClick = { signLoanTarget = null }) { Text("Cancel") }
            }
        )
    }
}

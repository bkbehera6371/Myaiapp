package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LoanEntity
import com.example.data.model.MemberEntity
import com.example.data.model.ReceiptEntity
import com.example.data.model.TransactionEntity
import com.example.ui.components.AdminPinConfirmDialog
import com.example.ui.components.KmSocietyLogo
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatDate
import com.example.ui.components.formatRupee
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoansScreen(
    loans: List<LoanEntity>,
    members: List<MemberEntity>,
    allTransactions: List<TransactionEntity> = emptyList(),
    onSelectMember: (String) -> Unit,
    onIssueLoan: (memberId: String, amount: Double, date: Long, rate: Double, tenure: Int, dueDay: Int, remarks: String) -> Unit = { _, _, _, _, _, _, _ -> },
    onEditLoan: (loanId: String, newAmount: Double, newDate: Long, newRate: Double, newTenure: Int, newDueDay: Int, reason: String) -> Unit = { _, _, _, _, _, _, _ -> },
    onDeleteLoan: (loanId: String, reason: String) -> Unit = { _, _ -> },
    onRecordRefund: (memberId: String, loanId: String?, amount: Double, date: Long, type: String, mode: String, remarks: String) -> Unit = { _, _, _, _, _, _, _ -> },
    onViewReceipt: (ReceiptEntity) -> Unit = {}
) {
    val context = LocalContext.current
    var selectedSection by remember { mutableStateOf("LOANS") } // "LOANS" or "REFUNDS"
    var filterStatus by remember { mutableStateOf("ALL") }

    var showNewLoanDialog by remember { mutableStateOf(false) }
    var loanToEdit by remember { mutableStateOf<LoanEntity?>(null) }
    var loanToDelete by remember { mutableStateOf<LoanEntity?>(null) }

    var showNewRefundDialog by remember { mutableStateOf(false) }
    var refundLoanTarget by remember { mutableStateOf<LoanEntity?>(null) }

    val memberMap = remember(members) { members.associateBy { it.id } }

    // Map refunds per loan
    val loanRefundMap = remember(allTransactions) {
        val map = mutableMapOf<String, Double>()
        allTransactions.filter { it.category == "PRINCIPAL_REPAYMENT" }.forEach { t ->
            val ref = t.referenceId
            if (!ref.isNullOrEmpty()) {
                map[ref] = (map[ref] ?: 0.0) + t.amount
            }
        }
        map
    }

    // Totals
    val totalDisbursed = loans.sumOf { it.loanAmount }
    val totalRefunded = loans.sumOf { loanRefundMap[it.id] ?: 0.0 }
    val totalOutstandingPrincipal = (totalDisbursed - totalRefunded).coerceAtLeast(0.0)
    val activeLoans = loans.filter { it.status == "ACTIVE" || it.status == "OVERDUE" }

    val filteredLoans = loans.filter { loan ->
        when (filterStatus) {
            "ACTIVE" -> loan.status == "ACTIVE"
            "OVERDUE" -> loan.status == "OVERDUE"
            "CLOSED" -> loan.status == "CLOSED"
            else -> true
        }
    }

    val allRefundTxns = remember(allTransactions) {
        allTransactions.filter { it.category == "PRINCIPAL_REPAYMENT" || it.remarks.contains("Refund", ignoreCase = true) }
    }

    Scaffold(
        floatingActionButton = {
            if (selectedSection == "LOANS") {
                ExtendedFloatingActionButton(
                    onClick = { showNewLoanDialog = true },
                    containerColor = GoldTertiary,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Issue Loan") }
                )
            } else {
                ExtendedFloatingActionButton(
                    onClick = { showNewRefundDialog = true },
                    containerColor = EmeraldPrimary,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Add Refund") }
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            KmSocietyLogo(size = 32.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("LOAN & REFUND SECTION", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text("KM STAFF SOCIETY • Manual Loan Disbursal & Principal Refund", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline))
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Stats Summary Row
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Total Disbursed", style = MaterialTheme.typography.labelSmall)
                                Text(formatRupee(totalDisbursed), style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Total Refunded", style = MaterialTheme.typography.labelSmall)
                                Text(formatRupee(totalRefunded), style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = NavySecondary))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Outstanding", style = MaterialTheme.typography.labelSmall)
                                Text(formatRupee(totalOutstandingPrincipal), style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = StatusOverdueRed))
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Switch between Loans & Refunds
                        TabRow(
                            selectedTabIndex = if (selectedSection == "LOANS") 0 else 1,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clip(RoundedCornerShape(12.dp))
                        ) {

                            Tab(
                                selected = selectedSection == "LOANS",
                                onClick = { selectedSection = "LOANS" },
                                text = { Text("Loans Register (${loans.size})", fontWeight = FontWeight.Bold) }
                            )
                            Tab(
                                selected = selectedSection == "REFUNDS",
                                onClick = { selectedSection = "REFUNDS" },
                                text = { Text("Refunds History (${allRefundTxns.size})", fontWeight = FontWeight.Bold) }
                            )
                        }
                    }
                }
            }

            if (selectedSection == "LOANS") {
                // Filters for Loans
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("ALL", "ACTIVE", "OVERDUE", "CLOSED").forEach { st ->
                            FilterChip(
                                selected = filterStatus == st,
                                onClick = { filterStatus = st },
                                label = { Text(st, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                if (filteredLoans.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(modifier = Modifier.padding(32.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text("No loan accounts found.")
                            }
                        }
                    }
                } else {
                    items(filteredLoans, key = { it.id }) { loan ->
                        val member = memberMap[loan.memberId]
                        val refunded = loanRefundMap[loan.id] ?: 0.0
                        val outstandingPrincipal = (loan.loanAmount - refunded).coerceAtLeast(0.0)
                        val normalInterest = loan.loanAmount * (loan.interestRateMonthly / 100.0)
                        val totalOutstanding = outstandingPrincipal + normalInterest

                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = loan.id,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                                        )
                                        Text(
                                            text = "${member?.fullName ?: loan.memberId} (${loan.memberId})",
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                                        )
                                    }
                                    StatusBadge(status = loan.status)
                                }

                                Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)

                                // Calculations grid
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Original Loan", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                        Text(formatRupee(loan.loanAmount), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                    }
                                    Column {
                                        Text("Total Refunded", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                        Text(formatRupee(refunded), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = StatusPaidGreen))
                                    }
                                    Column {
                                        Text("Outst. Principal", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                        Text(formatRupee(outstandingPrincipal), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = StatusOverdueRed))
                                    }
                                    Column {
                                        Text("Interest (${loan.interestRateMonthly.toInt()}%)", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                        Text(formatRupee(normalInterest), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Date: ${formatDate(loan.loanDate)} • Due: ${loan.dueDateDay}th of month",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline)
                                    )
                                    Text(
                                        text = "Total Outst: ${formatRupee(totalOutstanding)}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Action Buttons: Add Refund, Edit Loan, Delete Loan
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { loanToDelete = loan }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Delete", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                                    }

                                    OutlinedButton(
                                        onClick = { loanToEdit = loan },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Edit", style = MaterialTheme.typography.labelSmall)
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    if (loan.status != "CLOSED") {
                                        Button(
                                            onClick = { refundLoanTarget = loan },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.CurrencyRupee, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Add Refund", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // REFUNDS HISTORY LIST
                if (allRefundTxns.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(modifier = Modifier.padding(32.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text("No refund transactions recorded yet.")
                            }
                        }
                    }
                } else {
                    items(allRefundTxns, key = { it.id }) { txn ->
                        val member = memberMap[txn.memberId]
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(EmeraldPrimary.copy(alpha = 0.12f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Payment, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(20.dp))
                                }
                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = member?.fullName ?: (txn.memberId ?: "Society Member"),
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${txn.id} • ${formatDate(txn.date)} • ${txn.paymentMode}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline)
                                    )
                                    if (txn.remarks.isNotBlank()) {
                                        Text(
                                            text = txn.remarks,
                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                                        )
                                    }
                                }

                                Text(
                                    text = formatRupee(txn.amount),
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = StatusPaidGreen)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Issue Manual Loan
    if (showNewLoanDialog) {
        ManualLoanEntryDialog(
            members = members.filter { it.accountStatus == "ACTIVE" },
            onDismiss = { showNewLoanDialog = false },
            onSave = { mId, amt, date, rate, tenure, dueDay, remarks ->
                onIssueLoan(mId, amt, date, rate, tenure, dueDay, remarks)
                showNewLoanDialog = false
            }
        )
    }

    // Modal: Edit Loan
    loanToEdit?.let { loan ->
        EditLoanDialog(
            loan = loan,
            onDismiss = { loanToEdit = null },
            onSave = { amt, date, rate, tenure, dueDay, reason ->
                onEditLoan(loan.id, amt, date, rate, tenure, dueDay, reason)
                loanToEdit = null
            }
        )
    }

    // Modal: Delete Loan
    loanToDelete?.let { loan ->
        AdminPinConfirmDialog(
            title = "Delete Loan: ${loan.id}",
            message = "Are you sure you want to permanently delete Loan ${loan.id} of ₹${loan.loanAmount.toInt()}? This action will be recorded in the audit log.",
            confirmButtonLabel = "Delete Loan",
            isDestructive = true,
            onDismiss = { loanToDelete = null },
            onConfirm = { pin ->
                if (pin.trim() == "admin123" || pin.trim() == "admin") {
                    onDeleteLoan(loan.id, "Admin deleted loan with confirmed PIN")
                }
                loanToDelete = null
            }
        )
    }

    // Modal: Add Refund (Generic or linked to loan)
    if (showNewRefundDialog || refundLoanTarget != null) {
        ManualRefundEntryDialog(
            members = members,
            targetLoan = refundLoanTarget,
            onDismiss = {
                showNewRefundDialog = false
                refundLoanTarget = null
            },
            onSave = { mId, loanId, amt, date, type, mode, rem ->
                onRecordRefund(mId, loanId, amt, date, type, mode, rem)
                showNewRefundDialog = false
                refundLoanTarget = null
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManualLoanEntryDialog(
    members: List<MemberEntity>,
    onDismiss: () -> Unit,
    onSave: (memberId: String, amount: Double, date: Long, rate: Double, tenure: Int, dueDay: Int, remarks: String) -> Unit
) {
    var selectedMemberId by remember { mutableStateOf(members.firstOrNull()?.id ?: "") }
    var amountStr by remember { mutableStateOf("5000") }
    var interestRateStr by remember { mutableStateOf("2") }
    var tenureStr by remember { mutableStateOf("12") }
    var dueDayStr by remember { mutableStateOf("10") }
    var remarks by remember { mutableStateOf("Manual society loan") }

    val amount = amountStr.toDoubleOrNull() ?: 5000.0
    val rate = interestRateStr.toDoubleOrNull() ?: 2.0
    val tenure = tenureStr.toIntOrNull() ?: 12
    val dueDay = dueDayStr.toIntOrNull() ?: 10

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Issue Society Loan", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text("Select Member:", style = MaterialTheme.typography.labelSmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(members) { m ->
                            FilterChip(
                                selected = selectedMemberId == m.id,
                                onClick = { selectedMemberId = m.id },
                                label = { Text("${m.fullName} (${m.id})", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("Loan Amount (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = interestRateStr,
                            onValueChange = { interestRateStr = it },
                            label = { Text("Interest Rate (%/mo)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = tenureStr,
                            onValueChange = { tenureStr = it },
                            label = { Text("Tenure (Months)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = dueDayStr,
                        onValueChange = { dueDayStr = it },
                        label = { Text("Due Date Day (e.g. 10th)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = remarks,
                        onValueChange = { remarks = it },
                        label = { Text("Remarks") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(selectedMemberId, amount, System.currentTimeMillis(), rate, tenure, dueDay, remarks)
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldTertiary)
            ) {
                Text("Issue Loan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditLoanDialog(
    loan: LoanEntity,
    onDismiss: () -> Unit,
    onSave: (newAmount: Double, newDate: Long, newRate: Double, newTenure: Int, newDueDay: Int, reason: String) -> Unit
) {
    var amountStr by remember { mutableStateOf(loan.loanAmount.toInt().toString()) }
    var rateStr by remember { mutableStateOf(loan.interestRateMonthly.toString()) }
    var tenureStr by remember { mutableStateOf(loan.tenureMonths.toString()) }
    var dueDayStr by remember { mutableStateOf(loan.dueDateDay.toString()) }
    var reason by remember { mutableStateOf("") }
    var reasonError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Loan: ${loan.id}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Loan Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = rateStr,
                        onValueChange = { rateStr = it },
                        label = { Text("Rate (%/mo)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = tenureStr,
                        onValueChange = { tenureStr = it },
                        label = { Text("Tenure (Mos)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = dueDayStr,
                    onValueChange = { dueDayStr = it },
                    label = { Text("Due Date Day") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = {
                        reason = it
                        reasonError = false
                    },
                    label = { Text("Reason for Edit (Required for Audit Log) *") },
                    isError = reasonError,
                    supportingText = if (reasonError) { { Text("Please state a reason") } } else null,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (reason.isBlank()) {
                        reasonError = true
                    } else {
                        onSave(
                            amountStr.toDoubleOrNull() ?: loan.loanAmount,
                            loan.loanDate,
                            rateStr.toDoubleOrNull() ?: loan.interestRateMonthly,
                            tenureStr.toIntOrNull() ?: loan.tenureMonths,
                            dueDayStr.toIntOrNull() ?: loan.dueDateDay,
                            reason
                        )
                    }
                }
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManualRefundEntryDialog(
    members: List<MemberEntity>,
    targetLoan: LoanEntity?,
    onDismiss: () -> Unit,
    onSave: (memberId: String, loanId: String?, amount: Double, date: Long, type: String, mode: String, remarks: String) -> Unit
) {
    var selectedMemberId by remember { mutableStateOf(targetLoan?.memberId ?: members.firstOrNull()?.id ?: "") }
    var selectedLoanId by remember { mutableStateOf(targetLoan?.id ?: "") }
    var amountStr by remember { mutableStateOf("1500") }
    var refundType by remember { mutableStateOf("Principal Refund") }
    var paymentMode by remember { mutableStateOf("CASH") }
    var remarks by remember { mutableStateOf("") }

    val refundTypes = listOf("Principal Refund", "Loan Refund", "Other Refund")
    val paymentModes = listOf("CASH", "UPI", "BANK_TRANSFER")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Refund", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (targetLoan == null) {
                    item {
                        Text("Select Member:", style = MaterialTheme.typography.labelSmall)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(members) { m ->
                                FilterChip(
                                    selected = selectedMemberId == m.id,
                                    onClick = { selectedMemberId = m.id },
                                    label = { Text("${m.fullName} (${m.id})", style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                } else {
                    item {
                        Text("Recording refund for Loan ${targetLoan.id} (${targetLoan.memberId})", fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                    }
                }

                item {
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("Refund Amount (₹) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                item {
                    Text("Refund Type:", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        refundTypes.forEach { t ->
                            FilterChip(
                                selected = refundType == t,
                                onClick = { refundType = t },
                                label = { Text(t, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                item {
                    Text("Payment Mode:", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        paymentModes.forEach { m ->
                            FilterChip(
                                selected = paymentMode == m,
                                onClick = { paymentMode = m },
                                label = { Text(m) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = remarks,
                        onValueChange = { remarks = it },
                        label = { Text("Remarks (Optional)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    onSave(selectedMemberId, selectedLoanId.ifBlank { null }, amt, System.currentTimeMillis(), refundType, paymentMode, remarks)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text("Save Refund & Receipt")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.ExitSettlementSummary
import com.example.data.repository.MemberFinancialSummary
import com.example.ui.components.FinancialMetricCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatDate
import com.example.ui.components.formatRupee
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberProfileScreen(
    member: MemberEntity?,
    summary: MemberFinancialSummary?,
    hisabList: List<MonthlyHisabEntity>,
    savingsList: List<SavingsTransactionEntity>,
    loansList: List<LoanEntity>,
    transactionsList: List<TransactionEntity>,
    additionalSharesList: List<AdditionalMembershipEntity>,
    feesList: List<MonthlyFeeEntity>,
    distributionsList: List<InterestDistributionEntity>,
    onBack: () -> Unit,
    onAddSavings: (String, String, Double, String, String) -> Unit, // memberId, type, amount, mode, remarks
    onBuyShares: (String, Int, Double, String, String) -> Unit,
    onApplyNewLoan: (String, Double, Int, Double, String) -> Unit,
    onSignLoanAgreement: (String, String) -> Unit,
    onPayLoanEmi: (Long, String, String) -> Unit,
    onPayMonthlyFee: (Long, String, String) -> Unit,
    onViewReceipt: (ReceiptEntity) -> Unit,
    onProcessExit: (String, String) -> Unit,
    onGetEmisForLoan: suspend (String) -> List<LoanEmiEntity>
) {
    if (member == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select a member")
        }
        return
    }

    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabs = listOf(
        "Overview",
        "Monthly Hisab",
        "Savings",
        "Loans",
        "Transactions",
        "Membership",
        "Statements"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = member.fullName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${member.id} • ${member.membershipNumber}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    StatusBadge(
                        status = if (member.accountStatus == "ACTIVE") {
                            if (member.isTwoYearCompleted) "2-Year Completed" else "Active"
                        } else member.accountStatus
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Scrollable Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                edgePadding = 12.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = EmeraldPrimary
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> OverviewTab(member = member, summary = summary)
                1 -> MonthlyHisabTab(member = member, hisabList = hisabList)
                2 -> SavingsTab(member = member, savingsList = savingsList, summary = summary, onAddSavings = onAddSavings)
                3 -> LoansTab(
                    member = member,
                    loansList = loansList,
                    onApplyNewLoan = onApplyNewLoan,
                    onSignLoanAgreement = onSignLoanAgreement,
                    onPayLoanEmi = onPayLoanEmi,
                    onGetEmisForLoan = onGetEmisForLoan
                )
                4 -> TransactionsTab(transactionsList = transactionsList)
                5 -> MembershipTab(member = member, sharesList = additionalSharesList, onBuyShares = onBuyShares)
                6 -> StatementsTab(
                    member = member,
                    summary = summary,
                    feesList = feesList,
                    loansList = loansList,
                    onProcessExit = onProcessExit
                )
            }
        }
    }
}

// ==========================================
// 1. OVERVIEW TAB
// ==========================================
@Composable
fun OverviewTab(
    member: MemberEntity,
    summary: MemberFinancialSummary?
) {
    val now = System.currentTimeMillis()
    val totalPeriodMillis = (2L * 365 * 24 * 3600 * 1000).toFloat()
    val elapsedMillis = (now - member.joiningDate).toFloat()
    val progress = (elapsedMillis / totalPeriodMillis).coerceIn(0f, 1f)

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 2-Year Milestone Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (member.isTwoYearCompleted) EmeraldContainer else NavyContainer
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "2-Year Membership Cycle",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (member.isTwoYearCompleted) EmeraldOnContainer else NavyOnContainer
                            )
                        )
                        StatusBadge(status = if (member.isTwoYearCompleted) "2-Year Completed" else "In Progress")
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { if (member.isTwoYearCompleted) 1f else progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (member.isTwoYearCompleted) EmeraldPrimary else NavySecondary,
                        trackColor = Color.White.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Joined: ${formatDate(member.joiningDate)}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp)
                        )
                        Text(
                            text = "Target 2-Yr: ${formatDate(member.twoYearCompletionDate)}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        )
                    }
                    if (member.isTwoYearCompleted) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Eligible for equal distribution of society loan interest pool!",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = EmeraldPrimary
                            )
                        )
                    }
                }
            }
        }

        // Financial KPI Cards
        item {
            Text(
                text = "Financial Summary",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FinancialMetricCard(
                    title = "Savings Balance",
                    amount = summary?.currentSavingsBalance ?: 0.0,
                    subtitle = "Deposited: ${formatRupee(summary?.totalSavingsDeposited ?: 0.0)} | Withdrawn: ${formatRupee(summary?.totalSavingsWithdrawn ?: 0.0)}",
                    icon = Icons.Default.Savings,
                    accentColor = EmeraldPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FinancialMetricCard(
                        title = "Outstanding Loan",
                        amount = summary?.outstandingLoan ?: 0.0,
                        subtitle = "Taken: ${formatRupee(summary?.totalLoansTaken ?: 0.0)}",
                        icon = Icons.Default.AccountBalance,
                        accentColor = GoldTertiary,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        title = "Principal Repaid",
                        amount = summary?.totalPrincipalRepaid ?: 0.0,
                        subtitle = "Interest: ${formatRupee(summary?.totalInterestPaid ?: 0.0)}",
                        icon = Icons.Default.Payment,
                        accentColor = NavySecondary,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FinancialMetricCard(
                        title = "Monthly Fees Paid",
                        amount = summary?.totalMonthlyFeesPaid ?: 0.0,
                        subtitle = "Late Fines: ${formatRupee(summary?.totalLateFinesPaid ?: 0.0)}",
                        icon = Icons.Default.CheckCircle,
                        accentColor = EmeraldPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        title = "Interest Benefit",
                        amount = summary?.totalInterestDistributionReceived ?: 0.0,
                        subtitle = "Pool distributions",
                        icon = Icons.Default.VolunteerActivism,
                        accentColor = Color(0xFF7C3AED),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Personal Information
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Personal & Nominee Information",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )
                    DetailRow("Guardian's Name", member.guardianName)
                    DetailRow("Date of Birth", "${member.dob} (${member.gender})")
                    DetailRow("Mobile Number", member.mobileNumber)
                    DetailRow("WhatsApp", member.whatsappNumber)
                    DetailRow("Address", member.address)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    DetailRow("Nominee Name", member.nomineeName)
                    DetailRow("Nominee Relation", "${member.nomineeRelation}, Age: ${member.nomineeAge}")
                    DetailRow("Nominee Mobile", member.nomineeMobile.ifEmpty { "Not specified" })
                }
            }
        }
    }
}

// ==========================================
// 2. MONTHLY HISAB TAB
// ==========================================
@Composable
fun MonthlyHisabTab(
    member: MemberEntity,
    hisabList: List<MonthlyHisabEntity>
) {
    if (hisabList.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Text("No monthly hisab records found for ${member.fullName}")
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(hisabList, key = { it.id }) { hisab ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Month: ${hisab.monthYear}",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            )
                            StatusBadge(status = if (hisab.pendingAmount == 0.0) "CLEARED" else "PENDING")
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                DetailRow("Opening Savings", formatRupee(hisab.openingSavings))
                                DetailRow("Monthly Fee (₹200)", formatRupee(hisab.monthlyMemberFee))
                                DetailRow("Savings Deposit", formatRupee(hisab.savingsDeposit))
                                DetailRow("Savings Withdrawal", formatRupee(hisab.savingsWithdrawal))
                                DetailRow("Additional Share", formatRupee(hisab.additionalMembership))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                DetailRow("Loan Principal Paid", formatRupee(hisab.principalPaid))
                                DetailRow("Normal Interest (2%)", formatRupee(hisab.interestPaid))
                                DetailRow("Late Fine", formatRupee(hisab.lateFine))
                                DetailRow("Total Paid This Mo", formatRupee(hisab.totalPaid))
                                DetailRow("Closing Savings", formatRupee(hisab.closingSavings))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. SAVINGS TAB
// ==========================================
@Composable
fun SavingsTab(
    member: MemberEntity,
    savingsList: List<SavingsTransactionEntity>,
    summary: MemberFinancialSummary?,
    onAddSavings: (String, String, Double, String, String) -> Unit
) {
    var showDepositDialog by remember { mutableStateOf(false) }
    var showWithdrawDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Balance Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = EmeraldPrimary),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("Total Savings Balance", style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f)))
                Text(
                    text = formatRupee(summary?.currentSavingsBalance ?: 0.0),
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = Color.White)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Formula: Opening Savings + Deposits - Withdrawals = Closing Savings",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.75f), fontSize = 10.sp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { showDepositDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Deposit", color = EmeraldPrimary, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    OutlinedButton(
                        onClick = { showWithdrawDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(1.dp, Color.White),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Withdraw", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Savings Transactions", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(8.dp))

        if (savingsList.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No savings transactions recorded", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.outline))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(savingsList) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (item.type == "DEPOSIT") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                contentDescription = null,
                                tint = if (item.type == "DEPOSIT") StatusPaidGreen else StatusOverdueRed
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Savings ${item.type}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                Text("${formatDate(item.date)} • Mode: ${item.paymentMode}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                if (item.remarks.isNotEmpty()) {
                                    Text(item.remarks, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Text(
                                text = "${if (item.type == "DEPOSIT") "+" else "-"} ${formatRupee(item.amount)}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.type == "DEPOSIT") StatusPaidGreen else StatusOverdueRed
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDepositDialog) {
        SavingsActionDialog(
            title = "Deposit to Savings Account",
            isDeposit = true,
            onDismiss = { showDepositDialog = false },
            onConfirm = { amount, mode, remarks ->
                onAddSavings(member.id, "DEPOSIT", amount, mode, remarks)
                showDepositDialog = false
            }
        )
    }

    if (showWithdrawDialog) {
        SavingsActionDialog(
            title = "Withdraw from Savings Account",
            isDeposit = false,
            onDismiss = { showWithdrawDialog = false },
            onConfirm = { amount, mode, remarks ->
                onAddSavings(member.id, "WITHDRAWAL", amount, mode, remarks)
                showWithdrawDialog = false
            }
        )
    }
}

@Composable
fun SavingsActionDialog(
    title: String,
    isDeposit: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Double, String, String) -> Unit
) {
    var amountStr by remember { mutableStateOf("") }
    var paymentMode by remember { mutableStateOf("CASH") }
    var remarks by remember { mutableStateOf("") }
    val modes = listOf("CASH", "UPI", "BANK_TRANSFER")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Payment Mode", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    modes.forEach { m ->
                        FilterChip(
                            selected = paymentMode == m,
                            onClick = { paymentMode = m },
                            label = { Text(m, fontSize = 11.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Remarks") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    if (amt > 0) onConfirm(amt, paymentMode, remarks)
                }
            ) {
                Text("Confirm")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ==========================================
// 4. LOANS TAB
// ==========================================
@Composable
fun LoansTab(
    member: MemberEntity,
    loansList: List<LoanEntity>,
    onApplyNewLoan: (String, Double, Int, Double, String) -> Unit,
    onSignLoanAgreement: (String, String) -> Unit,
    onPayLoanEmi: (Long, String, String) -> Unit,
    onGetEmisForLoan: suspend (String) -> List<LoanEmiEntity>
) {
    var showApplyLoanDialog by remember { mutableStateOf(false) }
    var selectedLoanForEmis by remember { mutableStateOf<LoanEntity?>(loansList.firstOrNull()) }
    var loanEmis by remember { mutableStateOf<List<LoanEmiEntity>>(emptyList()) }
    var showSignAgreementDialog by remember { mutableStateOf<LoanEntity?>(null) }
    var showPayEmiDialog by remember { mutableStateOf<LoanEmiEntity?>(null) }

    LaunchedEffect(selectedLoanForEmis) {
        selectedLoanForEmis?.let { loan ->
            loanEmis = onGetEmisForLoan(loan.id)
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Loan Header with Apply Action
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Member Loans", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Standard ₹5,000 Loan • 12 Months • 2%/Mo", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline))
                }
                Button(
                    onClick = { showApplyLoanDialog = true },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldTertiary)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Apply Loan", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        if (loansList.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("No active or past loans for ${member.fullName}")
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { showApplyLoanDialog = true }) {
                            Text("Disburse ₹5,000 Standard Loan")
                        }
                    }
                }
            }
        } else {
            // Loans Selector
            item {
                Text("Select Loan Account:", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    loansList.forEach { loan ->
                        FilterChip(
                            selected = selectedLoanForEmis?.id == loan.id,
                            onClick = { selectedLoanForEmis = loan },
                            label = { Text("${loan.id} (Yr ${loan.cycleYear})") }
                        )
                    }
                }
            }

            selectedLoanForEmis?.let { loan ->
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(loan.id, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    Text("Cycle Year ${loan.cycleYear} • ₹${loan.loanAmount.toInt()}", style = MaterialTheme.typography.bodySmall.copy(color = EmeraldPrimary, fontWeight = FontWeight.SemiBold))
                                }
                                StatusBadge(status = loan.status)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            DetailRow("Normal Interest", "2% per month (${loan.interestCalculationMethod})")
                            DetailRow("Overdue Interest Rate", "3% per month")
                            DetailRow("Repayment Tenure", "${loan.tenureMonths} Months")

                            if (loan.status == "PENDING_SIGNATURE") {
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { showSignAgreementDialog = loan },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Draw, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Digital Agreement & Signature")
                                }
                            }
                        }
                    }
                }

                item {
                    Text("12-Month EMI Schedule", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                }

                items(loanEmis) { emi ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("EMI #${emi.emiNumber} • Due: ${formatDate(emi.dueDate)}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                StatusBadge(status = emi.status)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Principal: ₹${emi.principalAmount.toInt()}", style = MaterialTheme.typography.labelSmall)
                                Text("Normal Int (2%): ₹${emi.normalInterest.toInt()}", style = MaterialTheme.typography.labelSmall)
                                if (emi.overdueInterest > 0) {
                                    Text("Overdue Int (3%): ₹${emi.overdueInterest.toInt()}", style = MaterialTheme.typography.labelSmall.copy(color = StatusOverdueRed))
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Total EMI: ${formatRupee(emi.totalEmi)}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                if (emi.status != "PAID") {
                                    Button(
                                        onClick = { showPayEmiDialog = emi },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                                    ) {
                                        Text("Pay EMI", style = MaterialTheme.typography.labelSmall)
                                    }
                                } else {
                                    Text("Paid on ${emi.paidDate?.let { formatDate(it) }}", style = MaterialTheme.typography.labelSmall.copy(color = StatusPaidGreen))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Apply Loan Dialog
    if (showApplyLoanDialog) {
        var loanAmtStr by remember { mutableStateOf("5000") }
        var method by remember { mutableStateOf("REDUCING_BALANCE") }

        AlertDialog(
            onDismissRequest = { showApplyLoanDialog = false },
            title = { Text("Apply ₹5,000 Loan") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Eligible society members receive ₹5,000 loan over 12 months with 2% monthly interest.")
                    OutlinedTextField(
                        value = loanAmtStr,
                        onValueChange = { loanAmtStr = it },
                        label = { Text("Loan Amount (₹)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Interest Method:", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = method == "REDUCING_BALANCE",
                            onClick = { method = "REDUCING_BALANCE" },
                            label = { Text("Reducing Balance (2%)") }
                        )
                        FilterChip(
                            selected = method == "FLAT",
                            onClick = { method = "FLAT" },
                            label = { Text("Flat (2%)") }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = loanAmtStr.toDoubleOrNull() ?: 5000.0
                        onApplyNewLoan(member.id, amt, 12, 2.0, method)
                        showApplyLoanDialog = false
                    }
                ) {
                    Text("Submit Application")
                }
            },
            dismissButton = {
                TextButton(onClick = { showApplyLoanDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Digital Agreement Dialog
    showSignAgreementDialog?.let { loan ->
        var signatureName by remember { mutableStateOf(member.fullName) }

        AlertDialog(
            onDismissRequest = { showSignAgreementDialog = null },
            title = { Text("Digital Loan Agreement") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "I, ${member.fullName}, hereby confirm that I accept the terms of Loan ${loan.id} for ₹${loan.loanAmount.toInt()} with 12 monthly EMIs at 2% monthly normal interest, and 3% monthly overdue interest in case of delayed payment.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = signatureName,
                        onValueChange = { signatureName = it },
                        label = { Text("Digital Signature (Full Legal Name)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSignLoanAgreement(loan.id, signatureName)
                        showSignAgreementDialog = null
                    }
                ) {
                    Text("Sign & Disburse Loan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSignAgreementDialog = null }) { Text("Cancel") }
            }
        )
    }

    // Pay EMI Dialog
    showPayEmiDialog?.let { emi ->
        var payMode by remember { mutableStateOf("CASH") }
        var remarks by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showPayEmiDialog = null },
            title = { Text("Pay EMI #${emi.emiNumber}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Principal: ${formatRupee(emi.principalAmount)}")
                    Text("Normal Interest (2%): ${formatRupee(emi.normalInterest)}")
                    if (emi.overdueInterest > 0) {
                        Text("Overdue Interest (3%): ${formatRupee(emi.overdueInterest)}", color = StatusOverdueRed)
                    }
                    Text("Total Due: ${formatRupee(emi.totalEmi)}", fontWeight = FontWeight.Bold)

                    Text("Payment Mode:")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("CASH", "UPI", "BANK_TRANSFER").forEach { m ->
                            FilterChip(
                                selected = payMode == m,
                                onClick = { payMode = m },
                                label = { Text(m) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onPayLoanEmi(emi.id, payMode, remarks)
                        showPayEmiDialog = null
                    }
                ) {
                    Text("Record Payment & Receipt")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPayEmiDialog = null }) { Text("Cancel") }
            }
        )
    }
}

// ==========================================
// 5. TRANSACTIONS TAB
// ==========================================
@Composable
fun TransactionsTab(
    transactionsList: List<TransactionEntity>
) {
    if (transactionsList.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Text("No transactions found")
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(transactionsList) { txn ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(txn.category.replace("_", " "), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            Text("${formatDate(txn.date)} • ${txn.id}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            if (txn.remarks.isNotEmpty()) {
                                Text(txn.remarks, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${if (txn.type == "CREDIT") "+" else "-"} ${formatRupee(txn.amount)}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (txn.type == "CREDIT") StatusPaidGreen else StatusOverdueRed
                                )
                            )
                            txn.receiptNumber?.let { recNo ->
                                Text(recNo, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.primary))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. MEMBERSHIP TAB
// ==========================================
@Composable
fun MembershipTab(
    member: MemberEntity,
    sharesList: List<AdditionalMembershipEntity>,
    onBuyShares: (String, Int, Double, String, String) -> Unit
) {
    var showBuyShareDialog by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // One-time registration card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("One-Time Membership Fee", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        StatusBadge(status = "PAID")
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Amount Paid: ₹500.00", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = EmeraldPrimary))
                    Text("Paid on ${formatDate(member.joiningDate)} upon registration.", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                    Text("Notice: One-time membership fee is non-refundable and separate from Savings.", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline, fontSize = 10.sp))
                }
            }
        }

        // Additional Shares Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Additional Membership / Shares", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Text("Total Shares: ${member.additionalShareCount} (₹500 / share)", style = MaterialTheme.typography.bodySmall.copy(color = EmeraldPrimary))
                        }
                        Button(
                            onClick = { showBuyShareDialog = true },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Text("Buy Shares")
                        }
                    }
                }
            }
        }

        items(sharesList) { share ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("${share.count} Additional Share(s)", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                        Text(formatDate(share.purchaseDate), style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                    }
                    Text(formatRupee(share.totalMembershipValue), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                }
            }
        }
    }

    if (showBuyShareDialog) {
        var countStr by remember { mutableStateOf("1") }
        var payMode by remember { mutableStateOf("CASH") }

        AlertDialog(
            onDismissRequest = { showBuyShareDialog = false },
            title = { Text("Buy Additional Shares") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = countStr,
                        onValueChange = { countStr = it },
                        label = { Text("Number of Shares (@ ₹500 each)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    val cnt = countStr.toIntOrNull() ?: 1
                    Text("Total Price: ${formatRupee(cnt * 500.0)}", fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val count = countStr.toIntOrNull() ?: 1
                        onBuyShares(member.id, count, 500.0, payMode, "Purchased $count shares")
                        showBuyShareDialog = false
                    }
                ) {
                    Text("Confirm Purchase")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBuyShareDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ==========================================
// 7. STATEMENTS TAB (2-Year & Early Exit)
// ==========================================
@Composable
fun StatementsTab(
    member: MemberEntity,
    summary: MemberFinancialSummary?,
    feesList: List<MonthlyFeeEntity>,
    loansList: List<LoanEntity>,
    onProcessExit: (String, String) -> Unit
) {
    var showExitDialog by remember { mutableStateOf(false) }

    val pendingFees = feesList.filter { it.status == "PENDING" || it.status == "OVERDUE" }.sumOf { it.feeAmount + it.lateFine }
    val savingsBal = summary?.currentSavingsBalance ?: 0.0
    val outstandingLoan = summary?.outstandingLoan ?: 0.0
    val netExitRefund = savingsBal - outstandingLoan - pendingFees

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 2-Year Comprehensive Statement Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("2-Year Member Statement", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Cycle: ${formatDate(member.joiningDate)} to ${formatDate(member.twoYearCompletionDate)}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    DetailRow("Opening Savings", "₹0.00")
                    DetailRow("Total Savings Deposits", formatRupee(summary?.totalSavingsDeposited ?: 0.0))
                    DetailRow("Total Savings Withdrawals", formatRupee(summary?.totalSavingsWithdrawn ?: 0.0))
                    DetailRow("Current Savings Balance", formatRupee(summary?.currentSavingsBalance ?: 0.0))
                    DetailRow("One-Time Membership Fee", "₹500.00")
                    DetailRow("Monthly Member Fees Paid (₹200/mo)", formatRupee(summary?.totalMonthlyFeesPaid ?: 0.0))
                    DetailRow("Total Late Fines Paid", formatRupee(summary?.totalLateFinesPaid ?: 0.0))
                    DetailRow("Total Loans Taken", formatRupee(summary?.totalLoansTaken ?: 0.0))
                    DetailRow("Principal Repaid", formatRupee(summary?.totalPrincipalRepaid ?: 0.0))
                    DetailRow("Normal Interest Paid (2%)", formatRupee(summary?.totalInterestPaid ?: 0.0))
                    DetailRow("Overdue Interest Paid (3%)", formatRupee(summary?.totalOverdueInterestPaid ?: 0.0))
                    DetailRow("Outstanding Loan Balance", formatRupee(summary?.outstandingLoan ?: 0.0))
                    DetailRow("Interest Pool Distribution Received", formatRupee(summary?.totalInterestDistributionReceived ?: 0.0))
                }
            }
        }

        // Early Exit Settlement Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Early Exit Settlement Calculator", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "According to SUBIDHA rules: Leaving before 2 years entitles member only to savings balance minus outstanding loans and fines. ₹500 one-time fee and ₹200 monthly fees are non-refundable.",
                        style = MaterialTheme.typography.bodySmall
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    DetailRow("Eligible Savings Refundable", formatRupee(savingsBal))
                    DetailRow("Deduct: Outstanding Loan Principal", "- ${formatRupee(outstandingLoan)}")
                    DetailRow("Deduct: Unpaid Fees & Late Fines", "- ${formatRupee(pendingFees)}")

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Net Settlement Payable to Member", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Text(formatRupee(netExitRefund), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                    }

                    if (member.accountStatus == "ACTIVE") {
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = { showExitDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusOverdueRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Process Early Member Exit")
                        }
                    } else {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Member has already exited society (Account Closed).", style = MaterialTheme.typography.labelSmall.copy(color = StatusOverdueRed, fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    }

    if (showExitDialog) {
        var exitReason by remember { mutableStateOf("Relocation / Personal Request") }

        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text("Confirm Society Exit Settlement") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Member: ${member.fullName} (${member.id})")
                    Text("Net Settlement Amount: ${formatRupee(netExitRefund)}", fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = exitReason,
                        onValueChange = { exitReason = it },
                        label = { Text("Reason for Exit") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onProcessExit(member.id, exitReason)
                        showExitDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusOverdueRed)
                ) {
                    Text("Confirm Settlement & Exit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
        Text(value, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
    }
}

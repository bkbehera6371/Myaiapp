package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.ExitSettlementSummary
import com.example.data.repository.MemberFinancialSummary
import com.example.ui.components.AdminPinConfirmDialog
import com.example.ui.components.FinancialMetricCard
import com.example.ui.components.KmSocietyLogo
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatDate
import com.example.ui.components.formatRupee
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberProfileScreen(
    member: MemberEntity?,
    summary: MemberFinancialSummary?,
    hisabList: List<MonthlyHisabEntity>,
    savingsList: List<SavingsTransactionEntity>,
    loansList: List<LoanEntity>,
    transactionsList: List<TransactionEntity>,
    additionalSharesList: List<AdditionalMembershipEntity>,
    feesList: List<MonthlyFeeEntity>,
    distributionsList: List<InterestDistributionEntity>,
    onBack: () -> Unit,
    onAddSavings: (String, String, Double, String, String) -> Unit, // memberId, type, amount, mode, remarks
    onBuyShares: (String, Int, Double, String, String) -> Unit,
    onApplyNewLoan: (String, Double, Int, Double, String) -> Unit,
    onSignLoanAgreement: (String, String) -> Unit,
    onPayLoanEmi: (Long, String, String) -> Unit,
    onPayMonthlyFee: (Long, String, String) -> Unit,
    onViewReceipt: (ReceiptEntity) -> Unit,
    onProcessExit: (String, String) -> Unit,
    onGetEmisForLoan: suspend (String) -> List<LoanEmiEntity>,
    onDeleteMember: (memberId: String, pin: String, reason: String) -> Unit = { _, _, _ -> },
    onEditMember: (MemberEntity) -> Unit = {},
    onSetManualEligibility: (memberId: String, amount: Double?) -> Unit = { _, _ -> },
    onRecordManualCollection: (
        memberId: String,
        monthYear: String,
        fee: Double,
        savings: Double,
        interest: Double,
        refund: Double,
        fine: Double,
        other: Double,
        date: Long,
        mode: String,
        remarks: String
    ) -> Unit = { _, _, _, _, _, _, _, _, _, _, _ -> },
    onRecordRefund: (
        memberId: String,
        loanId: String?,
        amount: Double,
        date: Long,
        type: String,
        mode: String,
        remarks: String
    ) -> Unit = { _, _, _, _, _, _, _ -> }
) {
    if (member == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select a member")
        }
        return
    }

    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabs = listOf(
        "Overview",
        "Monthly Record",
        "Savings",
        "Loans & Refunds",
        "Transactions",
        "Membership",
        "Statements"
    )

    var showDeleteConfirmPinDialog by remember { mutableStateOf(false) }
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showManualEligibilityDialog by remember { mutableStateOf(false) }
    var showQuickReceiveMoneyDialog by remember { mutableStateOf(false) }
    var showQuickRefundDialog by remember { mutableStateOf(false) }
    var showQuickSavingsDialog by remember { mutableStateOf(false) }
    var showQuickLoanDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        KmSocietyLogo(size = 32.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = member.fullName,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = member.id,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                                    )
                                }
                            }
                            Text(
                                text = "KM STAFF SOCIETY • ${member.membershipNumber}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showEditProfileDialog = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Member", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = { showDeleteConfirmPinDialog = true }) {
                        Icon(Icons.Default.DeleteForever, contentDescription = "Delete Member Profile", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Scrollable Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                edgePadding = 12.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = EmeraldPrimary
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> OverviewTab(
                    member = member,
                    summary = summary,
                    loansList = loansList,
                    onOpenReceiveMoney = { showQuickReceiveMoneyDialog = true },
                    onOpenSavings = { showQuickSavingsDialog = true },
                    onOpenGiveLoan = { showQuickLoanDialog = true },
                    onOpenRefund = { showQuickRefundDialog = true },
                    onOpenEligibilityOverride = { showManualEligibilityDialog = true }
                )
                1 -> MonthlyHisabTab(member = member, hisabList = hisabList)
                2 -> SavingsTab(member = member, savingsList = savingsList, summary = summary, onAddSavings = onAddSavings)
                3 -> MemberLoansRefundsTab(
                    member = member,
                    loansList = loansList,
                    transactionsList = transactionsList,
                    onOpenAddLoan = { showQuickLoanDialog = true },
                    onOpenAddRefund = { showQuickRefundDialog = true }
                )
                4 -> TransactionsTab(transactionsList = transactionsList)
                5 -> MembershipTab(member = member, sharesList = additionalSharesList, onBuyShares = onBuyShares)
                6 -> StatementsTab(
                    member = member,
                    summary = summary,
                    feesList = feesList,
                    loansList = loansList,
                    onProcessExit = onProcessExit
                )
            }
        }
    }

    // Modal: Admin PIN Confirmation for Deleting Member Profile
    if (showDeleteConfirmPinDialog) {
        AdminPinConfirmDialog(
            title = "Permanently Delete Member Profile",
            message = "You are about to delete member ${member.fullName} (${member.id}) and all associated records (fees, savings, loans, receipts). This action CANNOT be undone and will be logged in the society audit trail. Enter Admin PIN to proceed.",
            confirmButtonLabel = "PERMANENTLY DELETE",
            isDestructive = true,
            onDismiss = { showDeleteConfirmPinDialog = false },
            onConfirm = { pin ->
                onDeleteMember(member.id, pin, "Admin permanently deleted member profile for ${member.fullName} (${member.id})")
                showDeleteConfirmPinDialog = false
                onBack()
            }
        )
    }

    // Modal: Edit Member Profile
    if (showEditProfileDialog) {
        EditMemberProfileDialog(
            member = member,
            onDismiss = { showEditProfileDialog = false },
            onSave = { updated ->
                onEditMember(updated)
                showEditProfileDialog = false
            }
        )
    }

    // Modal: Manual Loan Eligibility Override
    if (showManualEligibilityDialog) {
        val totalMemberships = 1 + member.additionalShareCount
        val automaticEligibility = totalMemberships * 5000.0
        ManualEligibilityOverrideDialog(
            member = member,
            automaticEligibility = automaticEligibility,
            onDismiss = { showManualEligibilityDialog = false },
            onSave = { overrideAmount ->
                onSetManualEligibility(member.id, overrideAmount)
                showManualEligibilityDialog = false
            }
        )
    }

    // Modal: Quick Receive Money
    if (showQuickReceiveMoneyDialog) {
        QuickReceiveMoneyDialog(
            member = member,
            onDismiss = { showQuickReceiveMoneyDialog = false },
            onSave = { fee, sav, intr, ref, fine, oth, mode, rem ->
                val monthYear = "2026-09"
                onRecordManualCollection(member.id, monthYear, fee, sav, intr, ref, fine, oth, System.currentTimeMillis(), mode, rem)
                showQuickReceiveMoneyDialog = false
            }
        )
    }

    // Modal: Quick Refund
    if (showQuickRefundDialog) {
        QuickRefundDialog(
            member = member,
            loansList = loansList.filter { it.status == "ACTIVE" || it.status == "OVERDUE" },
            onDismiss = { showQuickRefundDialog = false },
            onSave = { loanId, amt, type, mode, rem ->
                onRecordRefund(member.id, loanId, amt, System.currentTimeMillis(), type, mode, rem)
                showQuickRefundDialog = false
            }
        )
    }

    // Modal: Quick Savings
    if (showQuickSavingsDialog) {
        SavingsActionDialog(
            title = "Add Member Savings",
            isDeposit = true,
            onDismiss = { showQuickSavingsDialog = false },
            onConfirm = { amt, mode, rem ->
                onAddSavings(member.id, "DEPOSIT", amt, mode, rem)
                showQuickSavingsDialog = false
            }
        )
    }

    // Modal: Quick Loan
    if (showQuickLoanDialog) {
        QuickLoanDialog(
            member = member,
            onDismiss = { showQuickLoanDialog = false },
            onSave = { amt, tenure, rate, method ->
                onApplyNewLoan(member.id, amt, tenure, rate, method)
                showQuickLoanDialog = false
            }
        )
    }
}

// ==========================================
// 1. OVERVIEW TAB
// ==========================================
@Composable
fun OverviewTab(
    member: MemberEntity,
    summary: MemberFinancialSummary?,
    loansList: List<LoanEntity>,
    onOpenReceiveMoney: () -> Unit,
    onOpenSavings: () -> Unit,
    onOpenGiveLoan: () -> Unit,
    onOpenRefund: () -> Unit,
    onOpenEligibilityOverride: () -> Unit
) {
    val totalMemberships = 1 + member.additionalShareCount
    val automaticEligibility = totalMemberships * 5000.0

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Quick Actions Row
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Admin Quick Actions",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.outline)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilledTonalButton(
                                onClick = onOpenReceiveMoney,
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = EmeraldPrimary.copy(alpha = 0.15f), contentColor = EmeraldPrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.CurrencyRupee, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Receive Money", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        item {
                            FilledTonalButton(
                                onClick = onOpenSavings,
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = NavySecondary.copy(alpha = 0.15f), contentColor = NavySecondary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Savings, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Savings", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        item {
                            FilledTonalButton(
                                onClick = onOpenRefund,
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = GoldTertiary.copy(alpha = 0.15f), contentColor = GoldTertiary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Refund", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        item {
                            FilledTonalButton(
                                onClick = onOpenGiveLoan,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.AccountBalance, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Give Loan", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        // Loan Eligibility Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, GoldTertiary.copy(alpha = 0.4f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = GoldTertiary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Loan Eligibility Rules", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        }

                        TextButton(onClick = onOpenEligibilityOverride) {
                            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Override", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Text(
                        text = "Default Rule: 1 Membership = ₹5,000 Loan Eligibility ($totalMemberships active memberships)",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Automatic", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            Text(formatRupee(automaticEligibility), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        }
                        Column {
                            Text("Final Eligible Limit", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            Text(
                                formatRupee(automaticEligibility),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = EmeraldPrimary)
                            )
                        }
                    }
                }
            }
        }

        // Financial KPI Cards
        item {
            Text(
                text = "Financial Summary",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FinancialMetricCard(
                    title = "Savings Balance",
                    amount = summary?.currentSavingsBalance ?: 0.0,
                    subtitle = "Deposited: ${formatRupee(summary?.totalSavingsDeposited ?: 0.0)} | Withdrawn: ${formatRupee(summary?.totalSavingsWithdrawn ?: 0.0)}",
                    icon = Icons.Default.Savings,
                    accentColor = EmeraldPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FinancialMetricCard(
                        title = "Outstanding Loan",
                        amount = summary?.outstandingLoan ?: 0.0,
                        subtitle = "Taken: ${formatRupee(summary?.totalLoansTaken ?: 0.0)}",
                        icon = Icons.Default.AccountBalance,
                        accentColor = GoldTertiary,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        title = "Total Refunded",
                        amount = summary?.totalPrincipalRepaid ?: 0.0,
                        subtitle = "Interest: ${formatRupee(summary?.totalInterestPaid ?: 0.0)}",
                        icon = Icons.Default.Payment,
                        accentColor = NavySecondary,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FinancialMetricCard(
                        title = "Monthly Fees Paid",
                        amount = summary?.totalMonthlyFeesPaid ?: 0.0,
                        subtitle = "Fines: ${formatRupee(summary?.totalLateFinesPaid ?: 0.0)}",
                        icon = Icons.Default.CheckCircle,
                        accentColor = EmeraldPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialMetricCard(
                        title = "Interest Pool Benefit",
                        amount = summary?.totalInterestDistributionReceived ?: 0.0,
                        subtitle = "2-Year distribution",
                        icon = Icons.Default.VolunteerActivism,
                        accentColor = Color(0xFF7C3AED),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Personal Information
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Personal & Nominee Information",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )
                    DetailRow("Guardian's Name", member.guardianName)
                    DetailRow("Date of Birth", "${member.dob} (${member.gender})")
                    DetailRow("Mobile Number", member.mobileNumber)
                    DetailRow("WhatsApp", member.whatsappNumber)
                    DetailRow("Address", member.address)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    DetailRow("Nominee Name", member.nomineeName)
                    DetailRow("Nominee Relation", "${member.nomineeRelation}, Age: ${member.nomineeAge}")
                    DetailRow("Nominee Mobile", member.nomineeMobile.ifEmpty { "Not specified" })
                }
            }
        }
    }
}

// ==========================================
// 4. LOANS & REFUNDS TAB (NO EMI)
// ==========================================
@Composable
fun MemberLoansRefundsTab(
    member: MemberEntity,
    loansList: List<LoanEntity>,
    transactionsList: List<TransactionEntity>,
    onOpenAddLoan: () -> Unit,
    onOpenAddRefund: () -> Unit
) {
    val refunds = transactionsList.filter { it.category == "PRINCIPAL_REPAYMENT" || it.remarks.contains("Refund", ignoreCase = true) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Loans & Refunds Register", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Manual principal tracking • No automatic EMI", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onOpenAddRefund,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("Add Refund", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(
                        onClick = onOpenAddLoan,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Give Loan", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // Active Loans Cards
        if (loansList.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No active or past loans for ${member.fullName}")
                    }
                }
            }
        } else {
            items(loansList, key = { it.id }) { loan ->
                val loanRefundTotal = refunds.filter { it.referenceId == loan.id || it.remarks.contains(loan.id) }.sumOf { it.amount }
                val outstandingPrincipal = (loan.loanAmount - loanRefundTotal).coerceAtLeast(0.0)
                val normalInterest = loan.loanAmount * (loan.interestRateMonthly / 100.0)
                val totalOutstanding = outstandingPrincipal + normalInterest

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(loan.id, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                            StatusBadge(status = loan.status)
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Original Loan", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                Text(formatRupee(loan.loanAmount), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Column {
                                Text("Total Refunded", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                Text(formatRupee(loanRefundTotal), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = StatusPaidGreen))
                            }
                            Column {
                                Text("Outst. Principal", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                Text(formatRupee(outstandingPrincipal), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = StatusOverdueRed))
                            }
                            Column {
                                Text("Monthly Interest", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                Text(formatRupee(normalInterest), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Disbursed on ${formatDate(loan.loanDate)}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            Text("Total Outstanding: ${formatRupee(totalOutstanding)}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error))
                        }
                    }
                }
            }
        }

        // Refund History
        item {
            Text("Refund History", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
        }

        if (refunds.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(20.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No refunds recorded yet.")
                    }
                }
            }
        } else {
            items(refunds) { ref ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Payment, contentDescription = null, tint = StatusPaidGreen)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Refund (${ref.paymentMode})", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            Text("${formatDate(ref.date)} • ${ref.remarks.ifEmpty { "Principal Repayment" }}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                        }
                        Text(formatRupee(ref.amount), style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = StatusPaidGreen))
                    }
                }
            }
        }
    }
}

// ==========================================
// 2. MONTHLY HISAB TAB
// ==========================================
@Composable
fun MonthlyHisabTab(
    member: MemberEntity,
    hisabList: List<MonthlyHisabEntity>
) {
    if (hisabList.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Text("No monthly hisab records found for ${member.fullName}")
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(hisabList, key = { it.id }) { hisab ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(hisab.monthYear, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text(
                                "Total Paid: ${formatRupee(hisab.totalPaid)}",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                            )
                        }
                        Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = 0.5.dp)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Monthly Member Fee:", style = MaterialTheme.typography.bodySmall)
                            Text(formatRupee(hisab.monthlyMemberFee), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Savings Contribution:", style = MaterialTheme.typography.bodySmall)
                            Text(formatRupee(hisab.savingsDeposit), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Loan Refund & Interest:", style = MaterialTheme.typography.bodySmall)
                            Text(formatRupee(hisab.principalPaid + hisab.interestPaid), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 3. SAVINGS TAB
// ==========================================
@Composable
fun SavingsTab(
    member: MemberEntity,
    savingsList: List<SavingsTransactionEntity>,
    summary: MemberFinancialSummary?,
    onAddSavings: (String, String, Double, String, String) -> Unit
) {
    var showDepositDialog by remember { mutableStateOf(false) }
    var showWithdrawDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        FinancialMetricCard(
            title = "Net Savings Balance",
            amount = summary?.currentSavingsBalance ?: 0.0,
            subtitle = "Active cooperative savings of ${member.fullName}",
            icon = Icons.Default.Savings,
            accentColor = EmeraldPrimary
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = { showDepositDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Deposit")
            }

            OutlinedButton(
                onClick = { showWithdrawDialog = true },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Withdraw")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Savings Transactions", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
        Spacer(modifier = Modifier.height(8.dp))

        if (savingsList.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No savings transactions recorded", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.outline))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(savingsList) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (item.type == "DEPOSIT") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                contentDescription = null,
                                tint = if (item.type == "DEPOSIT") StatusPaidGreen else StatusOverdueRed
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Savings ${item.type}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                Text("${formatDate(item.date)} • Mode: ${item.paymentMode}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                if (item.remarks.isNotEmpty()) {
                                    Text(item.remarks, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Text(
                                text = "${if (item.type == "DEPOSIT") "+" else "-"} ${formatRupee(item.amount)}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.type == "DEPOSIT") StatusPaidGreen else StatusOverdueRed
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDepositDialog) {
        SavingsActionDialog(
            title = "Deposit to Savings Account",
            isDeposit = true,
            onDismiss = { showDepositDialog = false },
            onConfirm = { amount, mode, remarks ->
                onAddSavings(member.id, "DEPOSIT", amount, mode, remarks)
                showDepositDialog = false
            }
        )
    }

    if (showWithdrawDialog) {
        SavingsActionDialog(
            title = "Withdraw from Savings Account",
            isDeposit = false,
            onDismiss = { showWithdrawDialog = false },
            onConfirm = { amount, mode, remarks ->
                onAddSavings(member.id, "WITHDRAWAL", amount, mode, remarks)
                showWithdrawDialog = false
            }
        )
    }
}

// ==========================================
// 5. TRANSACTIONS TAB
// ==========================================
@Composable
fun TransactionsTab(transactionsList: List<TransactionEntity>) {
    if (transactionsList.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Text("No transactions found.")
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(transactionsList, key = { it.id }) { txn ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (txn.type == "CREDIT") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                            contentDescription = null,
                            tint = if (txn.type == "CREDIT") StatusPaidGreen else StatusOverdueRed
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(txn.category.replace("_", " "), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            Text("${formatDate(txn.date)} • ${txn.paymentMode}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            if (txn.remarks.isNotBlank()) {
                                Text(txn.remarks, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Text(
                            text = "${if (txn.type == "CREDIT") "+" else "-"} ${formatRupee(txn.amount)}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = if (txn.type == "CREDIT") StatusPaidGreen else StatusOverdueRed)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. MEMBERSHIP TAB
// ==========================================
@Composable
fun MembershipTab(
    member: MemberEntity,
    sharesList: List<AdditionalMembershipEntity>,
    onBuyShares: (String, Int, Double, String, String) -> Unit
) {
    var showBuySharesDialog by remember { mutableStateOf(false) }
    val totalMemberships = 1 + member.additionalShareCount
    val totalMembershipVal = totalMemberships * 500.0

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Membership Summary", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(10.dp))
                    DetailRow("Initial Membership", "1 Unit (₹500)")
                    DetailRow("Additional Memberships", "${member.additionalShareCount} Units (₹${member.additionalShareCount * 500})")
                    DetailRow("Total Memberships", "$totalMemberships Units")
                    DetailRow("Total Membership Value", formatRupee(totalMembershipVal))
                    DetailRow("Loan Eligibility (₹5k/unit)", formatRupee(totalMemberships * 5000.0))

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { showBuySharesDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Additional Memberships (₹500/unit)")
                    }
                }
            }
        }

        item {
            Text("Membership History", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
        }

        if (sharesList.isEmpty()) {
            item {
                Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Box(modifier = Modifier.padding(20.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No additional memberships added yet.")
                    }
                }
            }
        } else {
            items(sharesList) { sh ->
                Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${sh.count} Additional Units", fontWeight = FontWeight.Bold)
                            Text("Purchased on ${formatDate(sh.purchaseDate)}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                        }
                        Text(formatRupee(sh.totalMembershipValue), fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                    }
                }
            }
        }
    }

    if (showBuySharesDialog) {
        BuySharesDialog(
            onDismiss = { showBuySharesDialog = false },
            onConfirm = { count, price, mode, remarks ->
                onBuyShares(member.id, count, price, mode, remarks)
                showBuySharesDialog = false
            }
        )
    }
}

// ==========================================
// 7. STATEMENTS TAB
// ==========================================
@Composable
fun StatementsTab(
    member: MemberEntity,
    summary: MemberFinancialSummary?,
    feesList: List<MonthlyFeeEntity>,
    loansList: List<LoanEntity>,
    onProcessExit: (String, String) -> Unit
) {
    val context = LocalContext.current
    var showExitDialog by remember { mutableStateOf(false) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Member Account Ledger", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Official statement of KM STAFF SOCIETY", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline))

                    Spacer(modifier = Modifier.height(12.dp))
                    DetailRow("Member ID", member.id)
                    DetailRow("Full Name", member.fullName)
                    DetailRow("Joining Date", formatDate(member.joiningDate))
                    DetailRow("Current Savings Balance", formatRupee(summary?.currentSavingsBalance ?: 0.0))
                    DetailRow("Outstanding Principal", formatRupee(summary?.outstandingLoan ?: 0.0))
                    DetailRow("Total Fees Paid", formatRupee(summary?.totalMonthlyFeesPaid ?: 0.0))
                    DetailRow("Total Fines Paid", formatRupee(summary?.totalLateFinesPaid ?: 0.0))

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            val text = """
                                SUBIDHA • KM STAFF SOCIETY
                                OFFICIAL MEMBER STATEMENT
                                
                                Member: ${member.fullName} (${member.id})
                                Joined: ${formatDate(member.joiningDate)}
                                Savings Balance: ${formatRupee(summary?.currentSavingsBalance ?: 0.0)}
                                Outstanding Loan: ${formatRupee(summary?.outstandingLoan ?: 0.0)}
                                Monthly Fees Paid: ${formatRupee(summary?.totalMonthlyFeesPaid ?: 0.0)}
                                Fines Paid: ${formatRupee(summary?.totalLateFinesPaid ?: 0.0)}
                            """.trimIndent()
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, text)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share Statement"))
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share Official Statement")
                    }
                }
            }
        }
    }
}

// Helpers & Modals
@Composable
fun SavingsActionDialog(
    title: String,
    isDeposit: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Double, String, String) -> Unit
) {
    var amountStr by remember { mutableStateOf("") }
    var paymentMode by remember { mutableStateOf("CASH") }
    var remarks by remember { mutableStateOf("") }
    val modes = listOf("CASH", "UPI", "BANK_TRANSFER")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Payment Mode", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    modes.forEach { m ->
                        FilterChip(
                            selected = paymentMode == m,
                            onClick = { paymentMode = m },
                            label = { Text(m, fontSize = 11.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Remarks") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    if (amt > 0) onConfirm(amt, paymentMode, remarks)
                }
            ) {
                Text("Confirm")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun BuySharesDialog(
    onDismiss: () -> Unit,
    onConfirm: (Int, Double, String, String) -> Unit
) {
    var countStr by remember { mutableStateOf("1") }
    val pricePerShare = 500.0
    var mode by remember { mutableStateOf("CASH") }
    var remarks by remember { mutableStateOf("") }

    val count = countStr.toIntOrNull() ?: 1
    val total = count * pricePerShare

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Additional Memberships") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = countStr,
                    onValueChange = { countStr = it },
                    label = { Text("Number of Memberships") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Total Value: ${formatRupee(total)}", fontWeight = FontWeight.Bold, color = EmeraldPrimary)
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(count, pricePerShare, mode, remarks) }) {
                Text("Purchase")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditMemberProfileDialog(
    member: MemberEntity,
    onDismiss: () -> Unit,
    onSave: (MemberEntity) -> Unit
) {
    var fullName by remember { mutableStateOf(member.fullName) }
    var mobile by remember { mutableStateOf(member.mobileNumber) }
    var whatsapp by remember { mutableStateOf(member.whatsappNumber) }
    var address by remember { mutableStateOf(member.address) }
    var nomineeName by remember { mutableStateOf(member.nomineeName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Member Profile") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = mobile,
                        onValueChange = { mobile = it },
                        label = { Text("Mobile Number") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = whatsapp,
                        onValueChange = { whatsapp = it },
                        label = { Text("WhatsApp Number") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = nomineeName,
                        onValueChange = { nomineeName = it },
                        label = { Text("Nominee Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        member.copy(
                            fullName = fullName,
                            mobileNumber = mobile,
                            whatsappNumber = whatsapp,
                            address = address,
                            nomineeName = nomineeName
                        )
                    )
                }
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ManualEligibilityOverrideDialog(
    member: MemberEntity,
    automaticEligibility: Double,
    onDismiss: () -> Unit,
    onSave: (Double?) -> Unit
) {
    var manualStr by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Manual Loan Eligibility Override") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Automatic Eligibility: ${formatRupee(automaticEligibility)} (1 membership = ₹5,000)")
                Text("If Manual Eligibility is entered, the society will use the manual value. Leave empty to use Automatic.")
                OutlinedTextField(
                    value = manualStr,
                    onValueChange = { manualStr = it },
                    label = { Text("Manual Eligibility (₹)") },
                    placeholder = { Text("e.g. 50000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(manualStr.toDoubleOrNull())
                }
            ) {
                Text("Save Override")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun QuickReceiveMoneyDialog(
    member: MemberEntity,
    onDismiss: () -> Unit,
    onSave: (fee: Double, sav: Double, intr: Double, ref: Double, fine: Double, oth: Double, mode: String, rem: String) -> Unit
) {
    var feeStr by remember { mutableStateOf("200") }
    var savingsStr by remember { mutableStateOf("1000") }
    var interestStr by remember { mutableStateOf("0") }
    var refundStr by remember { mutableStateOf("0") }
    var fineStr by remember { mutableStateOf("0") }
    var otherStr by remember { mutableStateOf("0") }
    var mode by remember { mutableStateOf("CASH") }
    var remarks by remember { mutableStateOf("") }

    val total = (feeStr.toDoubleOrNull() ?: 0.0) +
            (savingsStr.toDoubleOrNull() ?: 0.0) +
            (interestStr.toDoubleOrNull() ?: 0.0) +
            (refundStr.toDoubleOrNull() ?: 0.0) +
            (fineStr.toDoubleOrNull() ?: 0.0) +
            (otherStr.toDoubleOrNull() ?: 0.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Receive Money from ${member.fullName}") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = feeStr, onValueChange = { feeStr = it }, label = { Text("Monthly Fee") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = savingsStr, onValueChange = { savingsStr = it }, label = { Text("Savings") }, modifier = Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = interestStr, onValueChange = { interestStr = it }, label = { Text("Interest") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = refundStr, onValueChange = { refundStr = it }, label = { Text("Refund") }, modifier = Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = fineStr, onValueChange = { fineStr = it }, label = { Text("Fine") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = otherStr, onValueChange = { otherStr = it }, label = { Text("Other") }, modifier = Modifier.weight(1f))
                    }
                }
                item {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Text("Total: ${formatRupee(total)}", modifier = Modifier.padding(10.dp), fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        feeStr.toDoubleOrNull() ?: 0.0,
                        savingsStr.toDoubleOrNull() ?: 0.0,
                        interestStr.toDoubleOrNull() ?: 0.0,
                        refundStr.toDoubleOrNull() ?: 0.0,
                        fineStr.toDoubleOrNull() ?: 0.0,
                        otherStr.toDoubleOrNull() ?: 0.0,
                        mode,
                        remarks
                    )
                }
            ) {
                Text("Record Receipt")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun QuickRefundDialog(
    member: MemberEntity,
    loansList: List<LoanEntity>,
    onDismiss: () -> Unit,
    onSave: (loanId: String?, amt: Double, type: String, mode: String, rem: String) -> Unit
) {
    var selectedLoanId by remember { mutableStateOf(loansList.firstOrNull()?.id ?: "") }
    var amountStr by remember { mutableStateOf("1500") }
    var refundType by remember { mutableStateOf("Principal Refund") }
    var mode by remember { mutableStateOf("CASH") }
    var remarks by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Refund for ${member.fullName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (loansList.isNotEmpty()) {
                    Text("Select Loan Account:", style = MaterialTheme.typography.labelSmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(loansList) { ln ->
                            FilterChip(
                                selected = selectedLoanId == ln.id,
                                onClick = { selectedLoanId = ln.id },
                                label = { Text(ln.id) }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Refund Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Remarks") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    onSave(selectedLoanId.ifBlank { null }, amt, refundType, mode, remarks)
                }
            ) {
                Text("Confirm Refund")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun QuickLoanDialog(
    member: MemberEntity,
    onDismiss: () -> Unit,
    onSave: (amt: Double, tenure: Int, rate: Double, method: String) -> Unit
) {
    var amountStr by remember { mutableStateOf("5000") }
    var tenureStr by remember { mutableStateOf("12") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Issue Loan to ${member.fullName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text("Loan Amount (₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = tenureStr,
                    onValueChange = { tenureStr = it },
                    label = { Text("Tenure (Months)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Interest Rate: 2% per month (Normal)", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 5000.0
                    val tenure = tenureStr.toIntOrNull() ?: 12
                    onSave(amt, tenure, 2.0, "REDUCING_BALANCE")
                }
            ) {
                Text("Issue Loan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
        )
    }
}

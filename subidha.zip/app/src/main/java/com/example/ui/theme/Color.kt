package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald
val EmeraldPrimary = Color(0xFF0F6E45)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldContainer = Color(0xFFD4F3E2)
val EmeraldOnContainer = Color(0xFF002111)

// Secondary Deep Slate Navy
val NavySecondary = Color(0xFF1E3A5F)
val NavyOnSecondary = Color(0xFFFFFFFF)
val NavyContainer = Color(0xFFD7E3F8)
val NavyOnContainer = Color(0xFF071E36)

// Tertiary Warm Gold (Loans & Member benefits)
val GoldTertiary = Color(0xFFB45309)
val GoldOnTertiary = Color(0xFFFFFFFF)
val GoldContainer = Color(0xFFFEF3C7)
val GoldOnContainer = Color(0xFF381A00)

// Surfaces & Backgrounds
val SurfaceLight = Color(0xFFF9FAF9)
val SurfaceContainerLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF3F5F4)
val SurfaceVariantLight = Color(0xFFE4ECE7)
val OutlineLight = Color(0xFF6F7973)

// Dark Theme Variants
val EmeraldDarkPrimary = Color(0xFF75DAA2)
val EmeraldDarkOnPrimary = Color(0xFF003820)
val EmeraldDarkContainer = Color(0xFF005231)
val EmeraldDarkOnContainer = Color(0xFFD4F3E2)

val NavyDarkSecondary = Color(0xFFAAC7EC)
val NavyDarkOnSecondary = Color(0xFF063255)
val NavyDarkContainer = Color(0xFF22486E)
val NavyDarkOnContainer = Color(0xFFD7E3F8)

val SurfaceDark = Color(0xFF111413)
val BackgroundDark = Color(0xFF111413)

// Status Colors
val StatusPaidGreen = Color(0xFF15803D)
val StatusPendingYellow = Color(0xFFD97706)
val StatusOverdueRed = Color(0xFFDC2626)
val StatusActiveBlue = Color(0xFF2563EB)

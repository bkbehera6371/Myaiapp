package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.SubidhaDatabase
import com.example.data.model.*
import com.example.data.repository.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class SubidhaViewModel(application: Application) : AndroidViewModel(application) {

    private val database = SubidhaDatabase.getDatabase(application)
    val repository = SubidhaRepository(database.subidhaDao())

    // --- Auth State ---
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    // --- Active Selected Month ---
    private val _selectedMonth = MutableStateFlow("2026-09")
    val selectedMonth: StateFlow<String> = _selectedMonth.asStateFlow()

    // --- Dashboard Summary ---
    private val _dashboardSummary = MutableStateFlow<SocietyDashboardSummary?>(null)
    val dashboardSummary: StateFlow<SocietyDashboardSummary?> = _dashboardSummary.asStateFlow()

    // --- Member State ---
    val allMembers: StateFlow<List<MemberEntity>> = repository.getAllMembers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedMemberId = MutableStateFlow<String?>("SUB-001")
    val selectedMemberId: StateFlow<String?> = _selectedMemberId.asStateFlow()

    val selectedMember: StateFlow<MemberEntity?> = _selectedMemberId.flatMapLatest { id ->
        if (id != null) repository.getMemberByIdFlow(id) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _memberSummary = MutableStateFlow<MemberFinancialSummary?>(null)
    val memberSummary: StateFlow<MemberFinancialSummary?> = _memberSummary.asStateFlow()

    val memberFees: StateFlow<List<MonthlyFeeEntity>> = _selectedMemberId.flatMapLatest { id ->
        if (id != null) repository.getFeesForMember(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memberSavings: StateFlow<List<SavingsTransactionEntity>> = _selectedMemberId.flatMapLatest { id ->
        if (id != null) repository.getSavingsForMember(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memberLoans: StateFlow<List<LoanEntity>> = _selectedMemberId.flatMapLatest { id ->
        if (id != null) repository.getLoansForMember(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memberTransactions: StateFlow<List<TransactionEntity>> = _selectedMemberId.flatMapLatest { id ->
        if (id != null) repository.getTransactionsForMember(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memberAdditionalShares: StateFlow<List<AdditionalMembershipEntity>> = _selectedMemberId.flatMapLatest { id ->
        if (id != null) repository.getAdditionalMembershipsForMember(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memberHisab: StateFlow<List<MonthlyHisabEntity>> = _selectedMemberId.flatMapLatest { id ->
        if (id != null) database.subidhaDao().getMonthlyHisabForMemberFlow(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memberDistributions: StateFlow<List<InterestDistributionEntity>> = _selectedMemberId.flatMapLatest { id ->
        if (id != null) repository.getDistributionsForMember(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Society-Wide Collections & Loans ---
    val monthlyFeesForSelectedMonth: StateFlow<List<MonthlyFeeEntity>> = _selectedMonth.flatMapLatest { m ->
        repository.getFeesForMonth(m)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLoans: StateFlow<List<LoanEntity>> = repository.getAllLoans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReceipts: StateFlow<List<ReceiptEntity>> = repository.getAllReceipts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRules: StateFlow<List<SocietyRuleEntity>> = repository.getAllRules()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAuditLogs: StateFlow<List<AuditLogEntity>> = repository.getAllAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDistributions: StateFlow<List<InterestDistributionEntity>> = repository.getAllInterestDistributions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Active Receipt Dialog ---
    private val _activeReceipt = MutableStateFlow<ReceiptEntity?>(null)
    val activeReceipt: StateFlow<ReceiptEntity?> = _activeReceipt.asStateFlow()

    // --- Snackbar / Toast Banner Message ---
    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

    init {
        // Auto-login default admin for instant developer and emulator preview
        login("admin", "admin123")
        refreshDashboard()
    }

    fun setSelectedMonth(monthYear: String) {
        _selectedMonth.value = monthYear
        refreshDashboard()
    }

    fun selectMember(memberId: String) {
        _selectedMemberId.value = memberId
        refreshMemberSummary(memberId)
    }

    fun clearUiMessage() {
        _uiMessage.value = null
    }

    fun showReceipt(receipt: ReceiptEntity) {
        _activeReceipt.value = receipt
    }

    fun dismissReceipt() {
        _activeReceipt.value = null
    }

    // --- Authentication ---
    fun login(usernameOrMobile: String, pass: String) {
        viewModelScope.launch {
            _loginError.value = null
            var user = repository.getUserByUsername(usernameOrMobile.trim())
            if (user == null) {
                user = repository.getUserByMobile(usernameOrMobile.trim())
            }
            if (user != null && user.passwordHash == pass.trim()) {
                _currentUser.value = user
                refreshDashboard()
            } else {
                _loginError.value = "Invalid Username/Mobile or Password"
            }
        }
    }

    fun logout() {
        _currentUser.value = null
    }

    fun refreshDashboard() {
        viewModelScope.launch {
            _dashboardSummary.value = repository.getDashboardSummary(_selectedMonth.value)
            _selectedMemberId.value?.let { refreshMemberSummary(it) }
        }
    }

    fun refreshMemberSummary(memberId: String) {
        viewModelScope.launch {
            _memberSummary.value = repository.getMemberFinancialSummary(memberId)
        }
    }

    // --- Member Registration ---
    fun registerMember(
        fullName: String,
        guardianName: String,
        dob: String,
        gender: String,
        mobileNumber: String,
        whatsappNumber: String,
        address: String,
        nomineeName: String,
        nomineeRelation: String,
        nomineeMobile: String,
        nomineeAge: Int,
        paymentMode: String,
        onSuccess: (MemberEntity) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val member = repository.registerMember(
                    fullName = fullName,
                    guardianName = guardianName,
                    dob = dob,
                    gender = gender,
                    mobileNumber = mobileNumber,
                    whatsappNumber = whatsappNumber,
                    address = address,
                    nomineeName = nomineeName,
                    nomineeRelation = nomineeRelation,
                    nomineeMobile = nomineeMobile,
                    nomineeAge = nomineeAge,
                    paymentMode = paymentMode,
                    createdBy = _currentUser.value?.fullName ?: "Admin"
                )
                refreshDashboard()
                selectMember(member.id)
                _uiMessage.value = "Member registered successfully! ID: ${member.id}"
                onSuccess(member)
            } catch (e: Exception) {
                _uiMessage.value = "Error: ${e.message}"
            }
        }
    }

    // --- Monthly Fees ---
    fun generateMonthlyDues(monthYear: String) {
        viewModelScope.launch {
            val count = repository.generateMonthlyDuesForActiveMembers(
                monthYear = monthYear,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            refreshDashboard()
            _uiMessage.value = "Generated monthly dues for $count active members for $monthYear"
        }
    }

    fun applyLateFines(monthYear: String) {
        viewModelScope.launch {
            val count = repository.applyLateFines(
                monthYear = monthYear,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            refreshDashboard()
            _uiMessage.value = "Applied ₹20 late fine to $count overdue members for $monthYear"
        }
    }

    fun payMonthlyFee(feeId: Long, paymentMode: String, remarks: String) {
        viewModelScope.launch {
            val receipt = repository.payMonthlyMemberFee(
                feeId = feeId,
                paymentMode = paymentMode,
                remarks = remarks,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            if (receipt != null) {
                refreshDashboard()
                _activeReceipt.value = receipt
                _uiMessage.value = "Payment recorded! Receipt: ${receipt.receiptNumber}"
            }
        }
    }

    // --- Savings ---
    fun addSavingsTransaction(memberId: String, type: String, amount: Double, paymentMode: String, remarks: String) {
        viewModelScope.launch {
            val receipt = repository.addSavingsTransaction(
                memberId = memberId,
                type = type,
                amount = amount,
                paymentMode = paymentMode,
                remarks = remarks,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            if (receipt != null) {
                refreshDashboard()
                _activeReceipt.value = receipt
                _uiMessage.value = "Savings $type recorded! Receipt: ${receipt.receiptNumber}"
            }
        }
    }

    // --- Additional Membership / Shares ---
    fun buyAdditionalShares(memberId: String, count: Int, pricePerShare: Double, paymentMode: String, remarks: String) {
        viewModelScope.launch {
            val receipt = repository.buyAdditionalMembership(
                memberId = memberId,
                count = count,
                pricePerMembership = pricePerShare,
                paymentMode = paymentMode,
                remarks = remarks,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            if (receipt != null) {
                refreshDashboard()
                _activeReceipt.value = receipt
                _uiMessage.value = "Purchased $count Additional Share(s)! Receipt: ${receipt.receiptNumber}"
            }
        }
    }

    // --- Loans ---
    fun applyLoan(memberId: String, amount: Double, tenureMonths: Int, interestRate: Double, method: String) {
        viewModelScope.launch {
            val loan = repository.applyLoan(
                memberId = memberId,
                amount = amount,
                tenureMonths = tenureMonths,
                interestRateMonthly = interestRate,
                interestMethod = method,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            if (loan != null) {
                refreshDashboard()
                _uiMessage.value = "Loan ${loan.id} applied! Awaiting digital agreement signature."
            }
        }
    }

    fun signLoanAgreementAndDisburse(loanId: String, signatureData: String) {
        viewModelScope.launch {
            val ok = repository.signLoanAgreementAndDisburse(
                loanId = loanId,
                signatureData = signatureData,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            if (ok) {
                refreshDashboard()
                _uiMessage.value = "Loan $loanId signed & disbursed successfully!"
            }
        }
    }

    fun payLoanEmi(emiId: Long, paymentMode: String, remarks: String) {
        viewModelScope.launch {
            val receipt = repository.payLoanEmi(
                emiId = emiId,
                paymentMode = paymentMode,
                remarks = remarks,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            if (receipt != null) {
                refreshDashboard()
                _activeReceipt.value = receipt
                _uiMessage.value = "EMI repayment recorded! Receipt: ${receipt.receiptNumber}"
            }
        }
    }

    // --- 2-Year Interest Pool Distribution ---
    fun executeInterestDistribution(cycleName: String, poolAmount: Double) {
        viewModelScope.launch {
            val count = repository.executeInterestDistribution(
                cycleName = cycleName,
                distributablePool = poolAmount,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            refreshDashboard()
            if (count > 0) {
                val perMember = poolAmount / count
                _uiMessage.value = "Distributed ₹${poolAmount.toInt()} equally among $count eligible members (₹${perMember.toInt()} each)!"
            } else {
                _uiMessage.value = "No eligible members completed 2 years yet."
            }
        }
    }

    // --- Early Exit Settlement ---
    fun processMemberExit(memberId: String, reason: String) {
        viewModelScope.launch {
            val ok = repository.processMemberExit(
                memberId = memberId,
                reason = reason,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            if (ok) {
                refreshDashboard()
                _uiMessage.value = "Member $memberId exit settlement completed successfully."
            }
        }
    }

    // --- Society Rules Update ---
    fun updateSocietyRule(ruleKey: String, newValue: String, reason: String) {
        viewModelScope.launch {
            repository.updateSocietyRule(
                ruleKey = ruleKey,
                newValue = newValue,
                reason = reason,
                user = _currentUser.value?.fullName ?: "Admin"
            )
            refreshDashboard()
            _uiMessage.value = "Rule updated successfully."
        }
    }
}

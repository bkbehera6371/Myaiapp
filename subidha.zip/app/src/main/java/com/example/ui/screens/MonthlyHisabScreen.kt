package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MonthlyFeeEntity
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatDate
import com.example.ui.components.formatRupee
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.NavySecondary
import com.example.ui.theme.StatusOverdueRed
import com.example.ui.theme.StatusPaidGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlyHisabScreen(
    selectedMonth: String,
    monthlyFees: List<MonthlyFeeEntity>,
    onSelectMonth: (String) -> Unit,
    onGenerateDues: (String) -> Unit,
    onApplyLateFines: (String) -> Unit,
    onPayFee: (Long, String, String) -> Unit
) {
    var filterStatus by remember { mutableStateOf("ALL") }
    var feeToPay by remember { mutableStateOf<MonthlyFeeEntity?>(null) }

    val months = listOf("2026-09", "2026-08", "2026-07", "2026-06", "2026-05")

    val totalDues = monthlyFees.size
    val paidCount = monthlyFees.count { it.status == "PAID" }
    val paidAmount = monthlyFees.filter { it.status == "PAID" }.sumOf { it.feeAmount + it.lateFine }
    val pendingCount = monthlyFees.count { it.status == "PENDING" || it.status == "OVERDUE" }
    val pendingAmount = monthlyFees.filter { it.status == "PENDING" || it.status == "OVERDUE" }.sumOf { it.feeAmount + it.lateFine }

    val filteredList = monthlyFees.filter { fee ->
        when (filterStatus) {
            "PAID" -> fee.status == "PAID"
            "PENDING" -> fee.status == "PENDING"
            "OVERDUE" -> fee.status == "OVERDUE"
            else -> true
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Month Selector & Automation Toolbar
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Monthly Dues & Fee Collection",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Standard ₹200/month collection window (1st - 10th of every month)",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Active Month:", style = MaterialTheme.typography.labelSmall)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        items(months) { m ->
                            FilterChip(
                                selected = selectedMonth == m,
                                onClick = { onSelectMonth(m) },
                                label = { Text(m, fontWeight = if (selectedMonth == m) FontWeight.Bold else FontWeight.Normal) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onGenerateDues(selectedMonth) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Generate Dues", style = MaterialTheme.typography.labelSmall)
                        }

                        OutlinedButton(
                            onClick = { onApplyLateFines(selectedMonth) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Apply ₹20 Fine", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // Summary Counters
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Paid ($paidCount)", style = MaterialTheme.typography.labelSmall.copy(color = StatusPaidGreen))
                        Text(formatRupee(paidAmount), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = StatusPaidGreen))
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Pending ($pendingCount)", style = MaterialTheme.typography.labelSmall.copy(color = StatusOverdueRed))
                        Text(formatRupee(pendingAmount), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = StatusOverdueRed))
                    }
                }
            }
        }

        // Filter tabs
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    Pair("ALL", "All ($totalDues)"),
                    Pair("PENDING", "Pending"),
                    Pair("OVERDUE", "Overdue"),
                    Pair("PAID", "Paid")
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = filterStatus == key,
                        onClick = { filterStatus = key },
                        label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // List of Member Dues
        if (filteredList.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(32.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No records found for selected filter")
                    }
                }
            }
        } else {
            items(filteredList, key = { it.id }) { fee ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(fee.memberId, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                                Spacer(modifier = Modifier.width(6.dp))
                                StatusBadge(status = fee.status)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Base Fee: ${formatRupee(fee.feeAmount)}" + if (fee.lateFine > 0) " + Fine: ${formatRupee(fee.lateFine)}" else "",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                            if (fee.status == "PAID") {
                                Text(
                                    text = "Paid on ${fee.paidDate?.let { formatDate(it) }}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline)
                                )
                            }
                        }

                        val totalPayable = fee.feeAmount + fee.lateFine
                        if (fee.status != "PAID") {
                            Button(
                                onClick = { feeToPay = fee },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Pay ${formatRupee(totalPayable)}", style = MaterialTheme.typography.labelSmall)
                            }
                        } else {
                            Text(
                                text = formatRupee(totalPayable),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = StatusPaidGreen)
                            )
                        }
                    }
                }
            }
        }
    }

    // Quick Pay Fee Dialog
    feeToPay?.let { fee ->
        var payMode by remember { mutableStateOf("CASH") }
        var remarks by remember { mutableStateOf("") }
        val totalDue = fee.feeAmount + fee.lateFine

        AlertDialog(
            onDismissRequest = { feeToPay = null },
            title = { Text("Collect Monthly Member Fee") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Member ID: ${fee.memberId}")
                    Text("Month: ${fee.monthYear}")
                    Text("Monthly Fee: ${formatRupee(fee.feeAmount)}")
                    if (fee.lateFine > 0) {
                        Text("Late Fine: ${formatRupee(fee.lateFine)}", color = StatusOverdueRed, fontWeight = FontWeight.Bold)
                    }
                    Text("Total to Collect: ${formatRupee(totalDue)}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

                    Text("Payment Mode:")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("CASH", "UPI", "BANK_TRANSFER").forEach { m ->
                            FilterChip(
                                selected = payMode == m,
                                onClick = { payMode = m },
                                label = { Text(m) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onPayFee(fee.id, payMode, remarks)
                        feeToPay = null
                    }
                ) {
                    Text("Confirm Payment & Generate Receipt")
                }
            },
            dismissButton = {
                TextButton(onClick = { feeToPay = null }) { Text("Cancel") }
            }
        )
    }
}

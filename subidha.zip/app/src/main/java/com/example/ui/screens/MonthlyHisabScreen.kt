package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.*
import com.example.ui.components.AdminPinConfirmDialog
import com.example.ui.components.KmSocietyLogo
import com.example.ui.components.StatusBadge
import com.example.ui.components.formatDate
import com.example.ui.components.formatRupee
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlyHisabScreen(
    selectedMonth: String,
    monthlyFees: List<MonthlyFeeEntity>,
    members: List<MemberEntity> = emptyList(),
    allLoans: List<LoanEntity> = emptyList(),
    allTransactions: List<TransactionEntity> = emptyList(),
    allRules: List<SocietyRuleEntity> = emptyList(),
    onSelectMonth: (String) -> Unit,
    onGenerateDues: (String) -> Unit,
    onApplyLateFines: (String) -> Unit,
    onPayFee: (Long, String, String) -> Unit,
    onRecordManualCollection: (
        memberId: String,
        monthYear: String,
        fee: Double,
        savings: Double,
        interest: Double,
        refund: Double,
        fine: Double,
        other: Double,
        date: Long,
        mode: String,
        remarks: String
    ) -> Unit = { _, _, _, _, _, _, _, _, _, _, _ -> },
    onCloseMonth: (String) -> Unit = {},
    onReopenMonth: (String, String, String) -> Unit = { _, _, _ -> },
    onDeleteFee: (Long, String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val months = listOf("2026-09", "2026-08", "2026-07", "2026-06", "2026-05")

    val isMonthClosed = allRules.any { it.ruleKey == "month_status_$selectedMonth" && it.ruleValue == "CLOSED" }

    var showManualEntryDialog by remember { mutableStateOf(false) }
    var editingFee by remember { mutableStateOf<MonthlyFeeEntity?>(null) }
    var showCloseMonthDialog by remember { mutableStateOf(false) }
    var showReopenPinDialog by remember { mutableStateOf(false) }
    var feeToDelete by remember { mutableStateOf<MonthlyFeeEntity?>(null) }
    var showPrintReportDialog by remember { mutableStateOf(false) }

    // Map fees by member
    val feeMap = remember(monthlyFees) { monthlyFees.associateBy { it.memberId } }

    // Calculations for the Monthly Record
    val totalActiveMembers = members.filter { it.accountStatus == "ACTIVE" }
    val totalMembershipAmount = totalActiveMembers.sumOf { 500.0 + (it.additionalShareCount * 500.0) }
    val totalMembershipsCount = totalActiveMembers.sumOf { 1 + it.additionalShareCount }

    // Transactions in this month
    val monthTxns = remember(allTransactions, selectedMonth) {
        allTransactions.filter { it.monthYear == selectedMonth }
    }

    val totalMonthlyFeeCollection = monthTxns.filter { it.category == "MONTHLY_MEMBER_FEE" }.sumOf { it.amount }
        .coerceAtLeast(monthlyFees.filter { it.status == "PAID" }.sumOf { it.feeAmount })
    val totalSavingsCollection = monthTxns.filter { it.category == "SAVINGS_DEPOSIT" }.sumOf { it.amount }
    val totalInterestCollection = monthTxns.filter { it.category == "NORMAL_INTEREST" || it.category == "OVERDUE_INTEREST" }.sumOf { it.amount }
    val totalFineCollection = monthTxns.filter { it.category == "LATE_FINE" }.sumOf { it.amount }
        .coerceAtLeast(monthlyFees.filter { it.status == "PAID" }.sumOf { it.lateFine })
    val totalRefundCollection = monthTxns.filter { it.category == "PRINCIPAL_REPAYMENT" }.sumOf { it.amount }
    val totalLoanDistribution = monthTxns.filter { it.category == "LOAN_DISBURSEMENT" }.sumOf { it.amount }
    val totalOtherIncome = monthTxns.filter { it.category == "OTHER_INCOME" }.sumOf { it.amount }
    val totalOtherExpenses = monthTxns.filter { it.category == "OTHER_EXPENSE" }.sumOf { it.amount }

    val grandTotalCollection = totalMonthlyFeeCollection + totalSavingsCollection + totalInterestCollection + totalFineCollection + totalRefundCollection + totalOtherIncome

    // Monthly Balance calculation
    val previousMonthBalance = 150000.0 // Base carry forward balance
    val totalAvailableBalance = previousMonthBalance + grandTotalCollection
    val closingBalance = totalAvailableBalance - totalLoanDistribution - totalOtherExpenses

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header & Month Selector
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                KmSocietyLogo(size = 32.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "MONTHLY RECORD",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "KM STAFF SOCIETY • Manual Member Accounting",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                                    )
                                }
                            }

                        // Month Status Badge
                        Surface(
                            color = if (isMonthClosed) StatusOverdueRed.copy(alpha = 0.15f) else StatusPaidGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = if (isMonthClosed) "STATUS: CLOSED" else "STATUS: OPEN",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isMonthClosed) StatusOverdueRed else StatusPaidGreen
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text("Select Month & Year:", style = MaterialTheme.typography.labelSmall)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        items(months) { m ->
                            FilterChip(
                                selected = selectedMonth == m,
                                onClick = { onSelectMonth(m) },
                                label = { Text(m, fontWeight = if (selectedMonth == m) FontWeight.Bold else FontWeight.Normal) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Action buttons: Add Entry, Close Month, Reopen, Print, Export
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showManualEntryDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1.2f)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Entry", style = MaterialTheme.typography.labelSmall)
                        }

                        if (!isMonthClosed) {
                            FilledTonalButton(
                                onClick = { showCloseMonthDialog = true },
                                colors = ButtonDefaults.filledTonalButtonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1.1f)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Close Month", style = MaterialTheme.typography.labelSmall)
                            }
                        } else {
                            OutlinedButton(
                                onClick = { showReopenPinDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1.1f)
                            ) {
                                Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reopen", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        IconButton(
                            onClick = { showPrintReportDialog = true },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                        ) {
                            Icon(Icons.Default.Print, contentDescription = "Print / PDF", tint = MaterialTheme.colorScheme.primary)
                        }

                        IconButton(
                            onClick = {
                                val reportText = buildMonthlyRecordReportText(
                                    selectedMonth = selectedMonth,
                                    members = totalActiveMembers,
                                    monthlyFees = monthlyFees,
                                    totalCollection = grandTotalCollection,
                                    totalDisbursed = totalLoanDistribution,
                                    closingBalance = closingBalance
                                )
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, reportText)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Export Monthly Record"))
                            },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Export CSV/Text", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }

        // 2. Monthly Record Table Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Member Collection Sheet ($selectedMonth)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${totalActiveMembers.size} Active Members",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                )
            }
        }

        // 3. Member Rows / Table
        if (totalActiveMembers.isEmpty() && monthlyFees.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(32.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No active member records found.")
                    }
                }
            }
        } else {
            items(totalActiveMembers, key = { it.id }) { member ->
                val fee = feeMap[member.id]
                val isPaid = fee?.status == "PAID"
                val feeAmt = fee?.feeAmount ?: 200.0
                val lateFine = fee?.lateFine ?: 0.0
                val totalAmt = if (isPaid) feeAmt + lateFine else 0.0

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = member.fullName,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${member.id} • ${member.membershipNumber}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                                )
                            }

                            Surface(
                                color = if (isPaid) StatusPaidGreen.copy(alpha = 0.15f) else StatusOverdueRed.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = if (isPaid) "PAID" else "NOT PAID / PENDING",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isPaid) StatusPaidGreen else StatusOverdueRed
                                    )
                                )
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 10.dp), thickness = 0.5.dp)

                        // Data grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Memberships", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                Text("${1 + member.additionalShareCount}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Column {
                                Text("Monthly Fee", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                Text(formatRupee(feeAmt), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Column {
                                Text("Late Fine", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                Text(if (lateFine > 0) formatRupee(lateFine) else "₹0", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = if (lateFine > 0) StatusOverdueRed else MaterialTheme.colorScheme.onSurface))
                            }
                            Column {
                                Text("Total Received", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                                Text(
                                    if (isPaid) formatRupee(totalAmt) else "₹0",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isPaid) StatusPaidGreen else MaterialTheme.colorScheme.outline
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Actions for this member
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (fee != null && isPaid) {
                                TextButton(
                                    onClick = { feeToDelete = fee }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Delete", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                                }
                            }

                            FilledTonalButton(
                                onClick = {
                                    editingFee = fee ?: MonthlyFeeEntity(
                                        memberId = member.id,
                                        monthYear = selectedMonth,
                                        feeAmount = 200.0,
                                        dueDate = System.currentTimeMillis()
                                    )
                                },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (isPaid) "Edit Entry" else "Record Payment", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        // 4. Bottom Totals Summary Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Monthly Totals Summary",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    SummaryLineItem("Total Active Members", "${totalActiveMembers.size}")
                    SummaryLineItem("Total Memberships", "$totalMembershipsCount")
                    SummaryLineItem("Total Membership Amount", formatRupee(totalMembershipAmount))
                    SummaryLineItem("Total Monthly Fee Collection", formatRupee(totalMonthlyFeeCollection))
                    SummaryLineItem("Total Savings Collection", formatRupee(totalSavingsCollection))
                    SummaryLineItem("Total Loan Interest Collection", formatRupee(totalInterestCollection))
                    SummaryLineItem("Total Fines Collected", formatRupee(totalFineCollection))
                    SummaryLineItem("Total Refunds Received", formatRupee(totalRefundCollection))
                    SummaryLineItem("Total Loan Distribution", formatRupee(totalLoanDistribution))

                    Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = 1.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Grand Total Received", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Text(formatRupee(grandTotalCollection), style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = StatusPaidGreen))
                    }
                }
            }
        }

        // 5. Monthly Balance Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("MONTHLY BALANCE SHEET", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                    Text("Society fund inflows, disbursements & carry forward balance", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline))

                    Spacer(modifier = Modifier.height(14.dp))

                    SummaryLineItem("Previous Month Closing Balance", formatRupee(previousMonthBalance))
                    SummaryLineItem("+ Current Month Collection", formatRupee(totalMonthlyFeeCollection + totalSavingsCollection + totalRefundCollection + totalFineCollection))
                    SummaryLineItem("+ Current Month Interest", formatRupee(totalInterestCollection))
                    SummaryLineItem("+ Other Income", formatRupee(totalOtherIncome))

                    Divider(modifier = Modifier.padding(vertical = 6.dp))
                    SummaryLineItem("= Total Available Balance", formatRupee(totalAvailableBalance), isBold = true)
                    Divider(modifier = Modifier.padding(vertical = 6.dp))

                    SummaryLineItem("Less: Loan Distribution", formatRupee(totalLoanDistribution), isNegative = true)
                    SummaryLineItem("Less: Other Expenses", formatRupee(totalOtherExpenses), isNegative = true)

                    Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = 1.5.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Closing Balance", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text(formatRupee(closingBalance), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                    }
                }
            }
        }
    }

    // Modal: Manual Member Collection Entry
    if (showManualEntryDialog || editingFee != null) {
        ManualCollectionEntryDialog(
            members = totalActiveMembers,
            initialFee = editingFee,
            selectedMonth = selectedMonth,
            onDismiss = {
                showManualEntryDialog = false
                editingFee = null
            },
            onSave = { mId, fee, sav, intr, ref, fine, oth, date, mode, rem ->
                onRecordManualCollection(mId, selectedMonth, fee, sav, intr, ref, fine, oth, date, mode, rem)
                showManualEntryDialog = false
                editingFee = null
            }
        )
    }

    // Modal: Close Month Confirmation
    if (showCloseMonthDialog) {
        AlertDialog(
            onDismissRequest = { showCloseMonthDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = EmeraldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Close Month: $selectedMonth", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Please confirm the month's accounting totals before closing:")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("• Total Collection: ${formatRupee(grandTotalCollection)}", fontWeight = FontWeight.SemiBold)
                    Text("• Total Interest: ${formatRupee(totalInterestCollection)}", fontWeight = FontWeight.SemiBold)
                    Text("• Total Refund: ${formatRupee(totalRefundCollection)}", fontWeight = FontWeight.SemiBold)
                    Text("• Total Loan Distribution: ${formatRupee(totalLoanDistribution)}", fontWeight = FontWeight.SemiBold)
                    Text("• Closing Balance: ${formatRupee(closingBalance)}", fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "After closing, MONTH STATUS will be set to CLOSED. Any edits will require Admin PIN confirmation.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCloseMonth(selectedMonth)
                        showCloseMonthDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("Confirm Month Close")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCloseMonthDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Modal: Reopen Month PIN Dialog
    if (showReopenPinDialog) {
        AdminPinConfirmDialog(
            title = "Reopen Closed Month",
            message = "Editing or adding transactions to a closed month requires Admin confirmation. Please enter the Admin PIN to reopen $selectedMonth.",
            confirmButtonLabel = "Reopen Month",
            isDestructive = false,
            onDismiss = { showReopenPinDialog = false },
            onConfirm = { pin ->
                onReopenMonth(selectedMonth, pin, "Admin reopened month for adjustments")
                showReopenPinDialog = false
            }
        )
    }

    // Modal: Delete Fee Entry Confirmation
    feeToDelete?.let { fee ->
        AdminPinConfirmDialog(
            title = "Delete Monthly Record Entry",
            message = "Are you sure you want to delete this payment record for member ${fee.memberId} ($selectedMonth)? This action will be logged in the society audit trail.",
            confirmButtonLabel = "Delete Entry",
            isDestructive = true,
            onDismiss = { feeToDelete = null },
            onConfirm = {
                onDeleteFee(fee.id, "Admin deleted entry for ${fee.memberId} in $selectedMonth")
                feeToDelete = null
            }
        )
    }

    // Modal: Print / PDF Report Preview
    if (showPrintReportDialog) {
        val reportText = buildMonthlyRecordReportText(
            selectedMonth = selectedMonth,
            members = totalActiveMembers,
            monthlyFees = monthlyFees,
            totalCollection = grandTotalCollection,
            totalDisbursed = totalLoanDistribution,
            closingBalance = closingBalance
        )
        AlertDialog(
            onDismissRequest = { showPrintReportDialog = false },
            title = { Text("Monthly Record Report Preview") },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                    item {
                        Text(reportText, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, reportText)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Print / Share Monthly Record"))
                        showPrintReportDialog = false
                    }
                ) {
                    Text("Print / Share")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPrintReportDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManualCollectionEntryDialog(
    members: List<MemberEntity>,
    initialFee: MonthlyFeeEntity?,
    selectedMonth: String,
    onDismiss: () -> Unit,
    onSave: (
        memberId: String,
        fee: Double,
        savings: Double,
        interest: Double,
        refund: Double,
        fine: Double,
        other: Double,
        date: Long,
        mode: String,
        remarks: String
    ) -> Unit
) {
    var selectedMemberId by remember { mutableStateOf(initialFee?.memberId ?: members.firstOrNull()?.id ?: "") }
    var feeStr by remember { mutableStateOf(initialFee?.feeAmount?.toInt()?.toString() ?: "200") }
    var savingsStr by remember { mutableStateOf("1000") }
    var interestStr by remember { mutableStateOf("0") }
    var refundStr by remember { mutableStateOf("0") }
    var fineStr by remember { mutableStateOf(initialFee?.lateFine?.toInt()?.toString() ?: "0") }
    var otherStr by remember { mutableStateOf("0") }
    var paymentMode by remember { mutableStateOf("CASH") }
    var remarks by remember { mutableStateOf("") }

    val fee = feeStr.toDoubleOrNull() ?: 0.0
    val savings = savingsStr.toDoubleOrNull() ?: 0.0
    val interest = interestStr.toDoubleOrNull() ?: 0.0
    val refund = refundStr.toDoubleOrNull() ?: 0.0
    val fine = fineStr.toDoubleOrNull() ?: 0.0
    val other = otherStr.toDoubleOrNull() ?: 0.0
    val totalAmount = fee + savings + interest + refund + fine + other

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Record Member Collection ($selectedMonth)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 450.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Member Selector
                item {
                    Text("Select Member:", style = MaterialTheme.typography.labelSmall)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(members) { m ->
                            FilterChip(
                                selected = selectedMemberId == m.id,
                                onClick = { selectedMemberId = m.id },
                                label = { Text("${m.fullName} (${m.id})", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = feeStr,
                            onValueChange = { feeStr = it },
                            label = { Text("Monthly Fee (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = savingsStr,
                            onValueChange = { savingsStr = it },
                            label = { Text("Savings (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = interestStr,
                            onValueChange = { interestStr = it },
                            label = { Text("Loan Interest (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = refundStr,
                            onValueChange = { refundStr = it },
                            label = { Text("Refund (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = fineStr,
                            onValueChange = { fineStr = it },
                            label = { Text("Fine (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = otherStr,
                            onValueChange = { otherStr = it },
                            label = { Text("Other Payment (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                // Live Total
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Amount Received:", fontWeight = FontWeight.Bold)
                            Text(
                                text = formatRupee(totalAmount),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, color = EmeraldPrimary)
                            )
                        }
                    }
                }

                item {
                    Text("Payment Mode:", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("CASH", "UPI", "BANK_TRANSFER").forEach { mode ->
                            FilterChip(
                                selected = paymentMode == mode,
                                onClick = { paymentMode = mode },
                                label = { Text(mode) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = remarks,
                        onValueChange = { remarks = it },
                        label = { Text("Remarks (Optional)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        selectedMemberId,
                        fee,
                        savings,
                        interest,
                        refund,
                        fine,
                        other,
                        System.currentTimeMillis(),
                        paymentMode,
                        remarks
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text("Save Collection Entry")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SummaryLineItem(label: String, value: String, isBold: Boolean = false, isNegative: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = if (isBold) MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold) else MaterialTheme.typography.bodySmall
        )
        Text(
            text = value,
            style = if (isBold) MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
            else MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.SemiBold,
                color = if (isNegative) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
            )
        )
    }
}

fun buildMonthlyRecordReportText(
    selectedMonth: String,
    members: List<MemberEntity>,
    monthlyFees: List<MonthlyFeeEntity>,
    totalCollection: Double,
    totalDisbursed: Double,
    closingBalance: Double
): String {
    val feeMap = monthlyFees.associateBy { it.memberId }
    val sb = StringBuilder()
    sb.appendLine("==========================================")
    sb.appendLine("SUBIDHA • KM STAFF SOCIETY")
    sb.appendLine("MONTHLY RECORD REPORT — $selectedMonth")
    sb.appendLine("==========================================")
    sb.appendLine()
    sb.appendLine(String.format("%-10s %-20s %-10s %-10s", "ID", "Name", "Status", "Amount"))
    sb.appendLine("------------------------------------------")
    members.forEach { m ->
        val fee = feeMap[m.id]
        val status = fee?.status ?: "PENDING"
        val amt = if (status == "PAID") (fee?.feeAmount ?: 0.0) + (fee?.lateFine ?: 0.0) else 0.0
        sb.appendLine(String.format("%-10s %-20s %-10s ₹%-9.0f", m.id, m.fullName.take(18), status, amt))
    }
    sb.appendLine("------------------------------------------")
    sb.appendLine("Total Collection: ₹${totalCollection.toInt()}")
    sb.appendLine("Total Disbursed:  ₹${totalDisbursed.toInt()}")
    sb.appendLine("Closing Balance:  ₹${closingBalance.toInt()}")
    sb.appendLine("==========================================")
    return sb.toString()
}

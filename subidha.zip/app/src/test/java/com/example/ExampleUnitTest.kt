package com.example

import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testMonthlyFeeAndLateFineCalculation() {
        val baseFee = 200.0
        val lateFine = 20.0
        val totalPayableIfLate = baseFee + lateFine

        assertEquals(200.0, baseFee, 0.001)
        assertEquals(20.0, lateFine, 0.001)
        assertEquals(220.0, totalPayableIfLate, 0.001)
    }

    @Test
    fun testTwoYearInterestEqualDistributionFormula() {
        val totalDistributablePool = 48000.0
        val eligibleMemberCount = 12
        val sharePerMember = totalDistributablePool / eligibleMemberCount

        assertEquals(4000.0, sharePerMember, 0.001)
    }

    @Test
    fun testReducingBalanceInterestCalculation() {
        val principal = 5000.0
        val monthlyRatePercent = 2.0
        val month1Interest = principal * (monthlyRatePercent / 100.0)
        assertEquals(100.0, month1Interest, 0.001)

        val principalRepaidMonth1 = 5000.0 / 12.0
        val remainingPrincipal = principal - principalRepaidMonth1
        val month2Interest = remainingPrincipal * (monthlyRatePercent / 100.0)
        assertTrue(month2Interest < month1Interest)
    }
}

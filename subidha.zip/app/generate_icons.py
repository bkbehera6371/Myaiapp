import os
import subprocess

densities = {
    "mdpi": 48,
    "hdpi": 72,
    "xhdpi": 96,
    "xxhdpi": 144,
    "xxxhdpi": 192
}

base_res = "app/src/main/res"

for name, size in densities.items():
    dir_path = os.path.join(base_res, f"mipmap-{name}")
    os.makedirs(dir_path, exist_ok=True)
    
    # Remove webp templates
    for old_file in ["ic_launcher.webp", "ic_launcher_round.webp"]:
        f = os.path.join(dir_path, old_file)
        if os.path.exists(f):
            os.remove(f)

    # Scale factors relative to 192px base
    s = size / 192.0
    c = size / 2.0
    r_outer = int(c - 2)
    r_inner1 = int(c - 5)
    r_inner2 = int(c * 0.72)
    shield_top = int(c * 0.6)
    shield_bottom = int(c * 1.5)
    shield_w = int(c * 0.45)
    star_y = int(c * 0.42)
    
    # Construct ImageMagick command for square launcher icon with rounded navy background
    cmd_square = [
        "convert", "-size", f"{size}x{size}", "xc:#0B1D3A",
        "-stroke", "#E5A93C", "-strokewidth", str(max(1, int(3 * s))), "-fill", "none",
        "-draw", f"circle {c},{c} {c},{c - r_outer}",
        "-stroke", "#D4AF37", "-strokewidth", str(max(1, int(1.5 * s))), "-fill", "none",
        "-draw", f"circle {c},{c} {c},{c - r_inner1}",
        "-stroke", "#E5A93C", "-strokewidth", str(max(1, int(2 * s))), "-fill", "none",
        "-draw", f"circle {c},{c} {c},{c - r_inner2}",
        # Star on top
        "-stroke", "none", "-fill", "#FFD54F",
        "-draw", f"circle {c},{star_y} {c},{star_y - int(4 * s)}",
        # Shield
        "-stroke", "#E5A93C", "-strokewidth", str(max(1, int(2 * s))), "-fill", "#0D2240",
        "-draw", f"polygon {c - shield_w},{shield_top} {c + shield_w},{shield_top} {c},{shield_bottom}",
        # Text KM in center
        "-fill", "#FFD54F", "-pointsize", str(int(28 * s)), "-gravity", "Center",
        "-draw", "text 0,2 'KM'",
        f"PNG32:{dir_path}/ic_launcher.png"
    ]
    subprocess.run(cmd_square, check=True)

    # Now create round launcher icon: circular crop
    radius = int(size / 2)
    cmd_round = [
        "convert", f"{dir_path}/ic_launcher.png",
        "(", "-size", f"{size}x{size}", "xc:none", "-fill", "white",
        "-draw", f"circle {radius},{radius} {radius},0", ")",
        "-alpha", "set", "-compose", "DstIn", "-composite",
        f"PNG32:{dir_path}/ic_launcher_round.png"
    ]
    subprocess.run(cmd_round, check=True)

print("Launcher icons generated successfully.")

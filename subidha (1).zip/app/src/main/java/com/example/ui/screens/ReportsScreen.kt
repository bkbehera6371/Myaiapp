package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.DetailRow
import com.example.ui.components.formatDate
import com.example.ui.components.formatRupee
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.NavySecondary
import com.example.ui.theme.StatusOverdueRed
import com.example.ui.theme.StatusPaidGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    members: List<MemberEntity>,
    transactions: List<TransactionEntity>,
    fees: List<MonthlyFeeEntity>,
    loans: List<LoanEntity>,
    savings: List<SavingsTransactionEntity>,
    receipts: List<ReceiptEntity>
) {
    val context = LocalContext.current
    var selectedReportType by remember { mutableStateOf("SUMMARY") }

    val reportTypes = listOf(
        Pair("SUMMARY", "Society Summary"),
        Pair("COLLECTION", "Monthly Collection"),
        Pair("SAVINGS", "Savings Ledger"),
        Pair("LOANS", "Loan Register"),
        Pair("OVERDUE", "Overdue Defaulters"),
        Pair("CASHBOOK", "Cash & Bank Book")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Selector Bar
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Financial Reports & Export", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        IconButton(
                            onClick = {
                                exportReportText(context, selectedReportType, members, transactions, fees, loans, savings)
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share Report", tint = EmeraldPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(reportTypes) { (key, label) ->
                            FilterChip(
                                selected = selectedReportType == key,
                                onClick = { selectedReportType = key },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }

        // Report Content
        when (selectedReportType) {
            "SUMMARY" -> {
                item {
                    val totalMembers = members.size
                    val activeMembers = members.count { it.accountStatus == "ACTIVE" }
                    val completed2Yrs = members.count { it.isTwoYearCompleted }
                    val totalSavings = savings.filter { it.type == "DEPOSIT" }.sumOf { it.amount } - savings.filter { it.type == "WITHDRAWAL" }.sumOf { it.amount }
                    val totalDisbursed = loans.sumOf { it.loanAmount }
                    val totalFees = fees.filter { it.status == "PAID" }.sumOf { it.feeAmount + it.lateFine }

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("SUBIDHA General Society Ledger Summary", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                            HorizontalDivider()
                            DetailRow("Total Registered Members", "$totalMembers")
                            DetailRow("Active Members", "$activeMembers")
                            DetailRow("2-Year Completed Members", "$completed2Yrs")
                            DetailRow("Net Society Savings Pool", formatRupee(totalSavings))
                            DetailRow("Total Loan Capital Disbursed", formatRupee(totalDisbursed))
                            DetailRow("Total Monthly Member Fees Collected", formatRupee(totalFees))
                            DetailRow("Total Audit Transactions Logged", "${transactions.size}")
                        }
                    }
                }
            }

            "COLLECTION" -> {
                items(fees.take(30)) { fee ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("${fee.memberId} • Month: ${fee.monthYear}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                Text("Fee: ₹${fee.feeAmount.toInt()} | Fine: ₹${fee.lateFine.toInt()}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            }
                            Text(
                                text = if (fee.status == "PAID") "PAID ${formatRupee(fee.feeAmount + fee.lateFine)}" else fee.status,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (fee.status == "PAID") StatusPaidGreen else StatusOverdueRed
                                )
                            )
                        }
                    }
                }
            }

            "SAVINGS" -> {
                items(savings.take(30)) { s ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("${s.memberId} • ${s.type}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                Text("${formatDate(s.date)} • Mode: ${s.paymentMode}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            }
                            Text(
                                text = "${if (s.type == "DEPOSIT") "+" else "-"} ${formatRupee(s.amount)}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (s.type == "DEPOSIT") StatusPaidGreen else StatusOverdueRed
                                )
                            )
                        }
                    }
                }
            }

            "LOANS" -> {
                items(loans) { l ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${l.id} • ${l.memberId}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                Text(l.status, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldPrimary))
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            DetailRow("Disbursed Amount", formatRupee(l.loanAmount))
                            DetailRow("Tenure / Rate", "${l.tenureMonths} Months @ 2%/mo")
                        }
                    }
                }
            }

            "OVERDUE" -> {
                val overdueFees = fees.filter { it.status == "OVERDUE" }
                val overdueLoans = loans.filter { it.status == "OVERDUE" }

                if (overdueFees.isEmpty() && overdueLoans.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(modifier = Modifier.padding(24.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text("No overdue fees or loans! All member accounts in good standing.")
                            }
                        }
                    }
                } else {
                    items(overdueFees) { fee ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("OVERDUE FEE: ${fee.memberId}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = StatusOverdueRed))
                                    Text("Month: ${fee.monthYear} (Due 10th)", style = MaterialTheme.typography.labelSmall)
                                }
                                Text(formatRupee(fee.feeAmount + fee.lateFine), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = StatusOverdueRed))
                            }
                        }
                    }
                }
            }

            "CASHBOOK" -> {
                items(transactions.take(40)) { txn ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(txn.category.replace("_", " "), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                Text("${formatDate(txn.date)} • Mode: ${txn.paymentMode} • ${txn.memberId ?: "General"}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.outline))
                            }
                            Text(
                                text = "${if (txn.type == "CREDIT") "+" else "-"} ${formatRupee(txn.amount)}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (txn.type == "CREDIT") StatusPaidGreen else StatusOverdueRed
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

fun exportReportText(
    context: Context,
    reportType: String,
    members: List<MemberEntity>,
    transactions: List<TransactionEntity>,
    fees: List<MonthlyFeeEntity>,
    loans: List<LoanEntity>,
    savings: List<SavingsTransactionEntity>
) {
    val reportText = buildString {
        appendLine("*SUBIDHA • KM STAFF SOCIETY FINANCIAL REPORT*")
        appendLine("Report Type: $reportType")
        appendLine("Generated: ${formatDate(System.currentTimeMillis())}")
        appendLine("------------------------------------")
        appendLine("Total Members: ${members.size}")
        appendLine("Active Members: ${members.count { it.accountStatus == "ACTIVE" }}")
        appendLine("2-Year Completed: ${members.count { it.isTwoYearCompleted }}")
        appendLine("Net Society Savings: ${formatRupee(savings.filter { it.type == "DEPOSIT" }.sumOf { it.amount } - savings.filter { it.type == "WITHDRAWAL" }.sumOf { it.amount })}")
        appendLine("Total Loans Disbursed: ${formatRupee(loans.sumOf { it.loanAmount })}")
        appendLine("------------------------------------")
        appendLine("SUBIDHA • KM STAFF SOCIETY — Simple Society Accounting & Member Management")
    }


    val intent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, reportText)
        type = "text/plain"
    }
    context.startActivity(Intent.createChooser(intent, "Share Society Report"))
}
